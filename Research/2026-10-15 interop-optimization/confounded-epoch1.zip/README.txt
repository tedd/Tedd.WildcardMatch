Confounded timing evidence; not usable for adoption.
Catalog is an official verified SQLite backup. Extract artifacts beside catalog.sqlite to inspect offline. Re-executions require new plans and grants.
