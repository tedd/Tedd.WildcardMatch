import pathlib,sys,shutil,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch2');REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch');sys.path.insert(0,str(R));from rpc import *
rig=R/'trial-anchor';shutil.copytree(R/'rig',rig,ignore=shutil.ignore_patterns('bin','obj'),dirs_exist_ok=True)
for arm,ns in [('baseline','Control'),('candidate','Tedd')]:
 folder=rig/arm
 for p in folder.glob('*.cs'):p.unlink()
 for p in (REPO/'src/Tedd.WildcardMatch').glob('*.cs'):
  text=p.read_text(encoding='utf-8-sig').replace('namespace Tedd;','namespace '+ns+';')
  if arm=='baseline':text=text.replace('[assembly: CLSCompliant(true)]','')
  (folder/p.name).write_text(text,encoding='utf-8')
p=rig/'candidate/CompiledSegments.cs';text=p.read_text(encoding='utf-8')
helper=r"""    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private bool MatchesOutsideAnchor(ReadOnlySpan<char> input, in Segment segment, int position)
    {
        // IndexOf already proved the complete literal anchor. Prefix/suffix
        // positions outside it still require wildcard and newline checks.
        for (int i = 0; i < segment.Anchor; i++)
        {
            char token = _pattern[segment.Offset + i], value = input[position + i];
            if (token == '?' ? !_singleline && value == '\n' : token != value) return false;
        }
        for (int i = segment.Anchor + segment.AnchorLength; i < segment.Length; i++)
        {
            char token = _pattern[segment.Offset + i], value = input[position + i];
            if (token == '?' ? !_singleline && value == '\n' : token != value) return false;
        }
        return true;
    }

"""
text=text.replace('    private bool Window(ReadOnlySpan<char> input)',helper+'    private bool Window(ReadOnlySpan<char> input)')
old='Matches(input, in segment, candidate)'
if text.count(old)!=1:raise RuntimeError('Unexpected anchor verification sites')
text=text.replace(old,'(segment.Anchor < 0 ? Matches(input, in segment, candidate) : MatchesOutsideAnchor(input, in segment, candidate))')
p.write_text(text,encoding='utf-8')
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence/anchor-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Ordinal trial build failed')
i=launch(rig,'anchor');g=grant(i,'execute_registered_scenario',120,'anchor',1200);s=Session('anchor');summary=[]
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'anchor-scenarios')['scenarios']
 s.call('lab.discover',{'action':'compatibility','target_id':i['id']},'anchor-compatibility')
 s.call('lab.experiment',{'action':'create_hypothesis','mechanism':'IndexOf proves a complete literal anchor even when questions or other literals surround it; verify only the remaining positions after a successful search. Prefix/suffix matches still verify everything.','prediction':'Reduce dense-anchor work while preserving all wildcard/newline outcomes; ten fixed paired descriptive blocks on six scenarios.','evidence_ids':[]},'anchor-hypothesis')
 for shape in ['Dense4096','Dense16384','LongText','Diverse','MultiStar','Newline']:
  desc=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,desc,'anchor-'+shape,512 if shape.startswith('Dense') else 1000 if shape=='Newline' else 30000 if shape=='LongText' else 300000)
  ex,c=execute(s,i,p,g,'anchor-'+shape);summary.append({'shape':shape,'execution_id':ex,'comparison':c});(R/'evidence/anchor-summary.json').write_text(json.dumps(summary,indent=2))
finally:s.close();(R/'stop-target-ordinal').touch()
