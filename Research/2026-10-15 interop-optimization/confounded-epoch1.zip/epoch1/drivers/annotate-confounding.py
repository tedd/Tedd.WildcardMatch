import pathlib,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');O=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch\Research\2026-10-15 interop-optimization')
p=O/'candidates.md';raw=p.read_bytes()
try:text=raw.decode('utf-8')
except UnicodeDecodeError:text=raw.decode('cp1252')
text=text.replace('# Candidate ledger\n\n','# Candidate ledger\n\nAll timings in this ledger belong to **confounded epoch 1**, when unrelated benchmarks were running concurrently. The ratios cannot establish performance or justify rejection/adoption. Dispositions record historical screening decisions only. Epoch 2 independently rechecks the provisional selected source against the original implementation.\n\n')
p.write_text(text,encoding='utf-8')
p=O/'candidates.json';rows=json.loads(p.read_text());[x.update(timing_validity='epoch1_confounded_external_parallel_benchmarks') for x in rows];p.write_text(json.dumps(rows,indent=2),encoding='utf-8')
for p in [R/'epoch2/aggregate-final.py',R/'confirmation-report.py']:
 text=p.read_text(encoding='utf-8');text=text.replace("write_text('\\n'.join(lines)+'\\n')","write_text('\\n'.join(lines)+'\\n',encoding='utf-8')");p.write_text(text,encoding='utf-8')
