import pathlib,json,hashlib,shutil
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');R=P/'epoch3';O=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch\Research\2026-10-15 interop-optimization');REPO=O.parent.parent
for n in [105,106,107,108,109]:
 if json.loads((P/'jobs'/f'{n:03}.done').read_text()).get('exit_code')!=0:raise RuntimeError('Final prerequisite failed '+str(n))
rows=json.loads((O/'confirmation-results.json').read_text());best=json.loads((O/'best-comparison.json').read_text());matching=json.loads((O/'matching-summary.json').read_text())
if len(rows)!=17 or len(matching)!=100:raise RuntimeError('Incomplete final result matrix')
checks={'portfolio_benefit':next(x for x in rows if x['scenario']=='interop-reused-Portfolio')['promotion_eligible'],'targeted_multistar_benefit':next(x for x in rows if x['scenario']=='interop-reused-MultiStar')['promotion_eligible'],'all_17_noninferiority_guards':all(x['non_inferiority_passed'] for x in rows),'all_sessions_correct_quiescent':all(x['correct_and_quiescent'] for x in rows),'zero_measured_managed_allocation':all(x['zero_measured_allocation'] for x in rows),'all_four_mean_margins_at_least_20_percent':all(x['meets_20_percent_mean_target'] for x in best)}
checks['source_adoption_eligible']=all(v for k,v in checks.items() if k!='all_four_mean_margins_at_least_20_percent')
frozen=json.loads((R/'evidence/source-freeze.json').read_text())
for name,digest in frozen['files'].items():
 if hashlib.sha256((REPO/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('Frozen source drift '+name)
manifest={str(p.relative_to(REPO)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in (REPO/'src').rglob('*') if p.is_file() and p.suffix in ['.cs','.csproj','.cpp','.ps1','.props','.targets'] and not {'bin','obj'}.intersection(p.parts)}
for name in ['global.json','Directory.Build.props','Directory.Build.targets']:
 p=REPO/name
 if p.exists():manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(O/'delivery-source-hashes.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');(R/'evidence/adoption-assessment.json').write_text(json.dumps(checks,indent=2));(O/'adoption-assessment.json').write_text(json.dumps(checks,indent=2))
for src,dst in [('native/native-sources.json','native-sources.json'),('evidence/final-validation-packages.json','validation.json'),('evidence/final-validation-native.json','native-validation.json')]:shutil.copy2(R/src,O/dst)
lines=['# Post-restart candidate experiments','','All rows use the uncontended post-restart catalog. Ratios are descriptive paired candidate/control estimates from ten blocks, with two warmups and fixed seed 20261015. The two-namespace screening caller does not establish independent source promotion; final adoption uses separate normal builds with identical callers.','','| Candidate | Control | Literal | Simple | MultiStar | Diverse | LongText | Dense4096 | Dense16384 | Newline | Disposition |','| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |']
notes={'ordinal':'Not selected: no useful long-text benefit.','swar':'Not selected: no useful short-star benefit.','anchor':'Selected for new source confirmation: omit rechecks of the proven anchor, retain surrounding validation.','packedfirst':'Not selected: weak short-star benefit with worse common-path costs.','minimum':'Not selected: no useful caller benefit.'}
ledger=[]
for name,note in notes.items():
 data=json.loads((P/'epoch2/evidence'/f'{name}-summary.json').read_text());effects={x['shape']:x['comparison'][0]['effects_without_run_ids'][0]['effect'] for x in data};parent='anchor-improved source' if name=='minimum' else 'provisional packed source'
 lines.append('| '+name+' | '+parent+' | '+' | '.join(f'{effects[k]:.4f}' if k in effects else '-' for k in ['Literal','Simple','MultiStar','Diverse','LongText','Dense4096','Dense16384','Newline'])+' | '+note+' |');ledger.append({'candidate':name,'parent':parent,'ratios':effects,'disposition':note,'execution_ids':[x['execution_id'] for x in data]})
(O/'post-restart-candidates.md').write_text('\n'.join(lines)+'\n',encoding='utf-8');(O/'post-restart-candidates.json').write_text(json.dumps(ledger,indent=2),encoding='utf-8')
print(json.dumps(checks,indent=2),flush=True)
