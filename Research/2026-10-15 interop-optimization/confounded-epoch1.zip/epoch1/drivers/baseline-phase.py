import pathlib,sys,json,time
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');sys.path.insert(0,str(R));from rpc import *
(R/'stop-target-initial').touch();time.sleep(.5)
i=launch(R/'rig','baseline');g=grant(i,'execute_registered_scenario',100,'baseline');o=grant(i,'observe',4,'baseline')
s=Session('baseline')
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'baseline-scenarios')['scenarios']
 s.call('lab.discover',{'action':'capabilities','target_id':i['id']},'baseline-capabilities');s.call('lab.discover',{'action':'compatibility','target_id':i['id']},'baseline-compatibility')
 target=next(x for x in sc if x['id']=='interop-reused-MultiStar')
 p=plan(s,target,'baseline-aa-valid');execute(s,i,p,g,'baseline-aa-valid')
 p=plan(s,target,'baseline-diagnostic',2000000,'cpu-diagnostic');ex,comp=execute(s,i,p,g,'baseline-diagnostic',o)
 print('Diagnostic execution',ex,flush=True)
finally:s.close()
