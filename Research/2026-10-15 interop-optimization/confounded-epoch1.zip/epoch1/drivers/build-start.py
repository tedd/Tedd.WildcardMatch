import sys,subprocess,pathlib,os,json,time
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');sys.path.insert(0,str(R))
from experiment import lab
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=R/'rig',capture_output=True,text=True)
(R/'evidence/rig-build-initial-2.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Build failed')
env=os.environ.copy();env['DOTNET_TieredCompilation']='0'
with (R/'target-initial.txt').open('w') as out:
 p=subprocess.Popen([r'D:\Workspaces\AI\dotnetlab-runtime\dotnet.exe',str(R/'rig/bin/Release/net10.0/WildcardInteropRig.dll'),'--listen',str(R/'catalog'),str(R/'stop-target-initial')],stdout=out,stderr=subprocess.STDOUT,env=env)
(R/'target-initial.pid').write_text(str(p.pid));time.sleep(1)
print(lab('lab.discover',{'action':'targets'},'targets-initial'))
