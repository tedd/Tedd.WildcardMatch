import pathlib,json,subprocess,os,hashlib
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');R=P/'epoch5';probe=R/'caller-probe';probe.mkdir(exist_ok=True)
(probe/'Probe.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net10.0</TargetFramework><RuntimeFrameworkVersion>10.0.12</RuntimeFrameworkVersion><RollForward>Disable</RollForward><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><UseAppHost>false</UseAppHost><EnableNETAnalyzers>false</EnableNETAnalyzers></PropertyGroup></Project>')
(probe/'global.json').write_text('{"sdk":{"version":"10.0.402","rollForward":"disable"}}')
(probe/'Program.cs').write_text(r'''using System.Diagnostics;
using System.Reflection;
using System.Runtime.Loader;
Process.GetCurrentProcess().ProcessorAffinity=new IntPtr(1L<<30);
Process.GetCurrentProcess().PriorityClass=ProcessPriorityClass.High;
string file=Path.GetFullPath(args[0]),folder=Path.GetDirectoryName(file)!;
AssemblyLoadContext.Default.Resolving+=(context,name)=>{string path=Path.Combine(folder,name.Name+".dll");return File.Exists(path)?context.LoadFromAssemblyPath(path):null;};
var assembly=AssemblyLoadContext.Default.LoadFromAssemblyPath(file);
var type=assembly.GetType("MatchScenario",true)!;
foreach(bool reuse in new[]{false,true}){
 object scenario=Activator.CreateInstance(type,BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic,null,new object[]{"LongText",reuse},null)!;
 object? count=type.GetMethod("ExecuteBatch")!.Invoke(scenario,new object[]{4096});
 Console.WriteLine($"Caller invoked: reuse={reuse}, count={count}; result={type.GetMethod("Validate")!.Invoke(scenario,null)}");
}
''',encoding='utf-8')
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Probe.csproj','-c','Release'],cwd=probe,capture_output=True,text=True);(R/'evidence/caller-probe-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Caller probe build failed')
for arm in ['baseline','candidate']:
 entry=R/('normal-'+arm)/'bin/Release/net10.0/WildcardInteropRig.dll';env=os.environ.copy();env.update(DOTNET_TieredCompilation='0',DOTNET_JitDisasm='MatchScenario:ExecuteBatch MatchScenario:*b__*',DOTNET_JitStdOutFile=str(R/'evidence'/('delegate-caller-'+arm+'.asm')))
 p=subprocess.run([r'D:\Workspaces\AI\dotnetlab-runtime\dotnet.exe',str(probe/'bin/Release/net10.0/Probe.dll'),str(entry)],env=env,capture_output=True,text=True);(R/'evidence'/('caller-probe-'+arm+'.txt')).write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError('Caller probe failed '+arm)
print('Exact retained normal entries invoked outside timing; no experiment samples added',flush=True)
