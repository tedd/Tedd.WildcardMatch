import pathlib,subprocess,os,shutil,json,hashlib
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch')
p=R/'final/src/Tedd.WildcardMatch.Benchmark/Program.cs';shutil.copy2(p,R/'evidence/measured-benchmark-program.cs');shutil.copy2(REPO/'src/Tedd.WildcardMatch.Benchmark/Program.cs',p)
cmd=[r'C:\Program Files\dotnet\dotnet.exe','build','src/Tedd.WildcardMatch.Benchmark','-c','Release']
x=subprocess.run(cmd,cwd=R/'final',capture_output=True,text=True);(R/'evidence/final-discovery-build.txt').write_text(x.stdout+x.stderr)
if x.returncode:raise RuntimeError('Discovery build failed')
for native in [False,True]:
 env=os.environ.copy();env.pop('WILDCARD_NATIVE_LIBRARY',None)
 if native:env['WILDCARD_NATIVE_LIBRARY']=str(R/'final/native-build/wildcard_native.dll')
 x=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','run','--project','src/Tedd.WildcardMatch.Benchmark','-c','Release','--no-build','--','--list','flat'],cwd=R/'final',env=env,capture_output=True,text=True)
 text=x.stdout+x.stderr;(R/'evidence'/('benchmark-discovery-native.txt' if native else 'benchmark-discovery-managed.txt')).write_text(text)
 if x.returncode or ('InteropControlBenchmarks.Normal' in text)!=native:raise RuntimeError('Incorrect optional native discovery')
manifest={str(p.relative_to(REPO)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['Tedd.WildcardMatch','Tedd.WildcardMatch.Benchmark','Tedd.WildcardMatch.Tests'] for p in (REPO/'src'/folder).rglob('*') if p.is_file() and p.suffix in ['.cs','.csproj','.cpp','.ps1'] and not {'bin','obj'}.intersection(p.parts)}
(R/'evidence/delivery-source-hashes.json').write_text(json.dumps(manifest,indent=2))
print('Optional-native discovery verified; timed bodies and production treatment unchanged',flush=True)
