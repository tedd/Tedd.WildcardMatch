import pathlib,sys,json,subprocess
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');sys.path.insert(0,str(R));from rpc import *
plans=json.loads((R/'evidence/confirmation-plan-index.json').read_text())
for item in plans:
 status=R/'evidence'/('confirm-'+item['scenario']+'-status.json')
 if status.exists():
  value=json.loads(status.read_text())['data']
  if value['state']!='completed':raise RuntimeError('Accepted operation requires inspection before recovery '+str(value))
 else:
  p=subprocess.run([D,HOST,'grant-confirmation',str(R/'catalog'),item['id'],'1800','20'],capture_output=True,text=True)
  (R/'evidence'/('confirmation-renewed-grant-'+item['scenario']+'.json')).write_text(p.stdout)
  if p.returncode:raise RuntimeError(p.stdout+p.stderr)
  item['grant_id']=json.loads(p.stdout)['id']
s=Session('confirmation-resumed');summary=[]
try:
 for item in plans:
  label='confirm-'+item['scenario'];status=R/'evidence'/(label+'-status.json')
  if status.exists():end=json.loads(status.read_text())['data']
  else:
   op=s.call('lab.run',{'action':'start_confirmation','plan_id':item['id'],'grant_id':item['grant_id'],'idempotency_key':label},label+'-accepted');end=s.wait(op,label)
  s.call('lab.inspect',{'action':'record','id':end['result_id']},label+'-execution')
  comparison=s.call('lab.compare',{'execution_id':end['result_id'],'normal_build_confirmation':True},label+'-comparison')
  summary.append({'scenario':item['scenario'],'execution_id':end['result_id'],'comparison':comparison});(R/'evidence/confirmation-summary.json').write_text(json.dumps(summary,indent=2));print(label,'completed',flush=True)
finally:s.close()
