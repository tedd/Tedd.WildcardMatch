import pathlib,subprocess,shutil,os
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');src=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch');dst=R/'cross-baseline';dst.mkdir(exist_ok=True)
shutil.copytree(src/'src',dst/'src',dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','obj'))
for n in ['global.json','LICENSE','README.md']:shutil.copy2(src/n,dst/n)
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','src/Tedd.WildcardMatch.Benchmark','-c','Release'],cwd=dst,capture_output=True,text=True)
(R/'evidence/cross-baseline-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Build failed')
env=os.environ.copy();env['WILDCARD_NATIVE_LIBRARY']=str(R/'native/native-build/wildcard_native.dll')
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','run','--project','src/Tedd.WildcardMatch.Benchmark','-c','Release','--no-build','--','--validate-native',str(R/'evidence/native-validation-interop.json')],cwd=dst,env=env,capture_output=True,text=True)
(R/'evidence/cross-baseline-validation.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Native validation failed')
with (R/'evidence/cross-baseline-benchmark.txt').open('w') as out:
 p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','run','--project','src/Tedd.WildcardMatch.Benchmark','-c','Release','--no-build','--','--filter','*Interop*','*NativeMatching*','--launchCount','3','--warmupCount','3','--iterationCount','10','--iterationTime','100','--affinity','1073741824','--artifacts',str(R/'cross-baseline-artifacts')],cwd=dst,env=env,stdout=out,stderr=subprocess.STDOUT)
if p.returncode:raise RuntimeError('Native benchmark failed')
