import pathlib,sys,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');sys.path.insert(0,str(R));from rpc import *
e=json.loads(json.loads((R/'evidence/baseline-diagnostic-execution.json').read_text())['data']['json'])
s=Session('diagnostic-analysis')
try:
 s.call('lab.query',{'view':'available_evidence','capture_id':e['capture_id']},'baseline-available-evidence')
 op=s.call('lab.run',{'action':'analyze_stacks','capture_id':e['capture_id'],'idempotency_key':'analyze-baseline-multistar'},'baseline-stack-analysis-accepted')
 end=s.wait(op,'baseline-stack-analysis')
 for ranking in ['self','inclusive']:
  h=s.call('lab.query',{'view':'hotspots','result_id':end['result_id'],'ranking':ranking,'limit':20},'baseline-hotspots-'+ranking)
  print(ranking,json.dumps(h)[:2000],flush=True)
finally:s.close()
