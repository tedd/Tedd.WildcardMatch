import pathlib,shutil,sys,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');name=sys.argv[1];rig=R/('trial-'+name);shutil.copytree(R/'trial-hybrid',rig,dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','obj'))
p=rig/'candidate/WildcardMatch.cs';text=p.read_text().replace('private readonly FixedPattern? _fixed;','private readonly ShortPattern? _packed;\n    private readonly FixedPattern? _fixed;')
text=text.replace('        _stringMatch =','        _packed = _short != null && _short.IsPacked ? _short : null;\n        _stringMatch =')
text=text.replace('if (_fixed != null) return _fixed.IsMatch(input.AsSpan());','if (_fixed != null) return _fixed.IsMatch(input.AsSpan());\n            if (input.Length <= 32 && _packed != null) return _packed.MatchPacked(input.AsSpan());');p.write_text(text)
if name=='directsplit':
 p=rig/'candidate/FixedPattern.cs';text=p.read_text();start=text.index('            // H-035: fuse literal mismatch',text.index('if (Vector256.IsHardwareAccelerated && _blocks != null)'));end=text.index('        if (Vector128.IsHardwareAccelerated',start)
 body=text[start:end];assert body.rstrip().endswith('}')
 code=body[:body.rfind('        }')]
 text=text[:start]+'            return MatchBlocks(input);\n        }\n'+text[end:]
 at=text.rfind('\n}')
 text=text[:at]+r'''
#if NET10_0_OR_GREATER
    [MethodImpl(MethodImplOptions.NoInlining)]
    private bool MatchBlocks(ReadOnlySpan<char> input)
    {
        int length = _pattern.Length;
'''+code+r'''    }
#endif
'''+text[at:];p.write_text(text)
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence'/f'{name}-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Build failed '+name)
sys.path.insert(0,str(R));from rpc import *
i=launch(rig,name);g=grant(i,'execute_registered_scenario',120,name);s=Session(name)
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},name+'-scenarios')['scenarios'];out=[]
 for shape in ['Literal','Simple','MultiStar','LongText','Diverse']:
  a=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,a,name+'-'+shape,30000 if shape=='LongText' else 300000);ex,c=execute(s,i,p,g,name+'-'+shape);out.append({'shape':shape,'execution_id':ex,'comparison':c})
 (R/'evidence'/f'{name}-summary.json').write_text(json.dumps(out,indent=2))
finally:s.close();(R/f'stop-target-{name}').touch()
