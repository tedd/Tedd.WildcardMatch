import sys,pathlib,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');sys.path.insert(0,str(R))
from experiment import lab
identity=json.loads((R/'target-initial.txt').read_text().splitlines()[0]);target=identity['id']
for action in ['capabilities','compatibility','scenarios']:
 data=lab('lab.discover',{'action':action,'target_id':target},action+'-initial')
 print(action,json.dumps(data)[:1600])
