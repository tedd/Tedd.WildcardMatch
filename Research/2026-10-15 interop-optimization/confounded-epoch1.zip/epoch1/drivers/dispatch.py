import pathlib,shutil,sys,subprocess,json,os
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');rig=R/'trial-dispatch';shutil.copytree(R/'trial-combined',rig,dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','obj'))
p=rig/'candidate/WildcardMatch.cs';text=p.read_text().replace('private readonly FixedPattern? _fixed;','private readonly byte _strategy;\n    private readonly FixedPattern? _fixed;')
needle='    }\n\n    /// <summary>Matches using call-local state;'
replacement='        _strategy = !_fast ? (byte)0 : _literal ? (byte)1 : _fixed != null ? (byte)2 : _short != null ? (_short.IsPacked ? (byte)3 : (byte)4) : _segments != null ? (byte)5 : (byte)6;\n    }\n\n    /// <summary>Matches using call-local state;'
assert needle in text;text=text.replace(needle,replacement)
start=text.index('        bool singleline = (_options & WildcardOptions.Singleline) != 0;',text.index('private bool MatchFast'))
text=text[:start]+r'''        bool singleline = (_options & WildcardOptions.Singleline) != 0;
        switch (_strategy)
        {
            case 1: return DefaultWildcardEngine.IsMatch(input, _matchPattern.AsSpan(), singleline, true);
            case 2: return _fixed!.IsMatch(input);
            case 3: return input.Length <= 32 ? _short!.MatchPacked(input) : _segments!.IsMatch(input);
            case 4:
                if (input.Length <= 32) return _short!.IsMatch(input);
                if (_segments != null) return _segments.IsMatch(input);
                break;
            case 5: return _segments!.IsMatch(input);
        }
        return DefaultWildcardEngine.IsMatch(input, _matchPattern.AsSpan(), singleline, false, _prefix, _suffix);
    }
}
''';p.write_text(text)
p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text().replace('unsafe bool MatchPacked','internal unsafe bool MatchPacked').replace(' readonly ulong _packedValue',' internal bool IsPacked => _packedLength != 0;\n readonly ulong _packedValue');p.write_text(text)
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence/dispatch-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Dispatch build failed')
sys.path.insert(0,str(R));from rpc import *
i=launch(rig,'dispatch');g=grant(i,'execute_registered_scenario',120,'dispatch');s=Session('dispatch')
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'dispatch-scenarios')['scenarios'];out=[]
 for shape in ['Literal','Simple','MultiStar','LongText','Diverse']:
  a=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,a,'dispatch-'+shape,30000 if shape=='LongText' else 300000);ex,c=execute(s,i,p,g,'dispatch-'+shape);out.append({'shape':shape,'execution_id':ex,'comparison':c})
 (R/'evidence/dispatch-summary.json').write_text(json.dumps(out,indent=2))
finally:s.close();(R/'stop-target-dispatch').touch()
