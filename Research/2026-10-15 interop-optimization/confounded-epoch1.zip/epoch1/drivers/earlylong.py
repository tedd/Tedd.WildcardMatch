import pathlib,shutil,sys,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');rig=R/'trial-earlylong';shutil.copytree(R/'trial-hybriddirect',rig,dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','obj'))
p=rig/'candidate/WildcardMatch.cs';text=p.read_text().replace('if (input is null) throw new ArgumentNullException(nameof(input));\n        if (_fast)','if (input is null) throw new ArgumentNullException(nameof(input));\n        if (input.Length > 32 && _segments != null) return MatchSegmentsString(this, input);\n        if (_fast)');p.write_text(text)
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence/earlylong-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Build failed earlylong')
sys.path.insert(0,str(R));from rpc import *
i=launch(rig,'earlylong');g=grant(i,'execute_registered_scenario',120,'earlylong');s=Session('earlylong')
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'earlylong-scenarios')['scenarios'];out=[]
 for shape in ['Literal','Simple','MultiStar','LongText','Diverse']:
  a=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,a,'earlylong-'+shape,30000 if shape=='LongText' else 300000);ex,c=execute(s,i,p,g,'earlylong-'+shape);out.append({'shape':shape,'execution_id':ex,'comparison':c})
 (R/'evidence/earlylong-summary.json').write_text(json.dumps(out,indent=2))
finally:s.close();(R/'stop-target-earlylong').touch()
