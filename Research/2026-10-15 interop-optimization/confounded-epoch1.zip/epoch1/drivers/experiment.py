import pathlib,json,subprocess,os,sys,shutil,time
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization'); REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch')
D=r'D:\Workspaces\AI\dotnetlab-runtime\dotnet.exe'; HOST=r'D:\Workspaces\AI\dotnetlab-implementation\bin\DotNetLab.Host\Release\net10.0\DotNetLab.Host.dll'
def lab(tool,payload,name):
 p=subprocess.run([D,HOST,'call',str(R/'catalog'),tool],input=json.dumps(payload),capture_output=True,text=True,timeout=180)
 (R/'evidence'/f'{name}.json').write_text(p.stdout)
 x=json.loads(p.stdout)
 if x.get('status')!='ok':raise RuntimeError(x)
 return x['data']
def job(num,spec):
 path=R/'jobs'/f'{num:03}.json'; path.write_text(json.dumps(spec))
if len(sys.argv)>1 and sys.argv[1]=='setup':
 rig=R/'rig';rig.mkdir(exist_ok=True)
 for arm,namespace in [('baseline','Control'),('candidate','Tedd')]:
  dst=rig/arm;dst.mkdir(exist_ok=True)
  for src in (REPO/'src/Tedd.WildcardMatch').glob('*.cs'):
   (dst/src.name).write_text(src.read_text(encoding='utf-8-sig').replace('namespace Tedd;','namespace '+namespace+';'))
 hostdir=pathlib.Path(HOST).parent
 refs=''.join(f'<Reference Include="{n}"><HintPath>{hostdir}/{n}.dll</HintPath></Reference>' for n in ['DotNetLab.Harness','DotNetLab.Contracts','DotNetLab.Transport.Local'])
 (rig/'Rig.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net10.0</TargetFramework><RuntimeFrameworkVersion>10.0.12</RuntimeFrameworkVersion><RollForward>Disable</RollForward><AssemblyName>WildcardInteropRig</AssemblyName><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><AllowUnsafeBlocks>true</AllowUnsafeBlocks><EnableNETAnalyzers>false</EnableNETAnalyzers><UseAppHost>false</UseAppHost></PropertyGroup><ItemGroup>'+refs+'</ItemGroup></Project>')
 (rig/'global.json').write_text('{"sdk":{"version":"10.0.402","rollForward":"disable"}}')
 (rig/'Program.cs').write_text(r'''
using DotNetLab.Contracts;
using DotNetLab.Harness;
using System.Diagnostics;
Process.GetCurrentProcess().ProcessorAffinity = new IntPtr(1L << 30);
var registry = new ScenarioRegistry();
foreach (var shape in new[]{"Literal","Simple","MultiStar","LongText","Dense4096","Dense16384","Newline","Diverse"})
 foreach (bool reuse in new[]{true,false}) registry.Register(new MatchScenario(shape,reuse));
var host = new HarnessHost(registry,args[1]);
if(args[0]=="--harness") {await host.RunOwnedAsync();return;}
using var cancel = new CancellationTokenSource();
var listener=host.ListenAsync(cancel.Token);
Console.WriteLine(Wire.Serialize(host.Target));Console.Out.Flush();
while(!File.Exists(args[2]))await Task.Delay(200);
cancel.Cancel();await listener;
sealed class MatchScenario : ISynchronousScenario {
 readonly string shape; readonly bool reuse; readonly string pattern; readonly string[] inputs;readonly bool[] expected;
 readonly Tedd.WildcardMatch candidate;readonly Control.WildcardMatch control;
 string variant="baseline";long checksum,expectedChecksum;CancellationToken cancel;
 public MatchScenario(string shape,bool reuse){this.shape=shape;this.reuse=reuse;
 pattern=shape switch{"Literal"=>"report-2026.txt","Simple"=>"report-??.txt","MultiStar"=>"*a?c*e*","LongText"=>"*alpha*beta??*omega*","Diverse"=>"*a?c*e*",_=>"*"+new string('a',70)+"?b*"};
 int n=shape=="Dense16384"?16384:4096;
 inputs=shape switch{
 "Literal"=>["report-2026.txt","report-2025.txt","xreport-2026.txt","report-2026.txtx"],
 "Simple"=>["report-01.txt","report-aa.txt","report-1.txt","report-001.txt"],
 "MultiStar"=>["xabcyef","abce","abcd","ababcd","aZc-long-e-tail","acex"],
 "LongText"=>[new string('x',512)+"alpha-middle-beta42-tail-omega"+new string('z',512),new string('x',512)+"alpha-middle-beta42-tail-delta"+new string('z',512),new string('x',512)+"alpha-beta12-omega"+new string('z',512),new string('x',512)+"alpha-beta1-omega"+new string('z',512)],
 "Newline"=>["\n"+new string('a',n),new string('a',n)+"\n",new string('a',70)+"\nb",new string('a',70)+"zb\n"],
 "Diverse"=>Enumerable.Range(0,256).Select(i=>new string('x',i%64)+(i%4==0?"aZce":i%4==1?"a\nce":i%4==2?"aZcxe\n":"aZcxx")+new string('z',i%17)).ToArray(),
 _=>[new string('a',n),new string('a',n)+"zb",new string('a',n)+"zc",new string('a',n)+"zb\n"]};
 expected=inputs.Select(s=>Oracle(s,pattern)).ToArray();candidate=new(pattern);control=new(pattern);
 }
 static bool Oracle(string s,string p){bool Full(int end){var a=new bool[end+1];a[0]=true;foreach(char c in p){var b=new bool[end+1];b[0]=c=='*'&&a[0];for(int i=1;i<=end;i++)b[i]=c=='*'?a[i]||(b[i-1]&&s[i-1]!='\n'):a[i-1]&&(c=='?'?s[i-1]!='\n':c==s[i-1]);a=b;}return a[end];}return Full(s.Length)||(s.EndsWith('\n')&&Full(s.Length-1));}
 public ScenarioDescriptor Describe()=>new("interop-"+(reuse?"reused-":"static-")+shape,"1",Wire.Hash(new{pattern,inputs,expected}),ResetLevel.LogicalState,ThreadAffinity.Any,false,"One public direct match, corpus cycled; checksum observable",["baseline","candidate"]);
 public void Prepare(ScenarioContext context){variant=context.Variant;cancel=context.Cancellation;for(int i=0;i<inputs.Length;i++)if(candidate.IsMatch(inputs[i])!=expected[i]||control.IsMatch(inputs[i])!=expected[i]||Tedd.WildcardMatch.IsMatch(inputs[i],pattern)!=expected[i]||Control.WildcardMatch.IsMatch(inputs[i],pattern)!=expected[i])throw new Exception("Oracle mismatch");}
 public void Reset(ResetContext context){checksum=expectedChecksum=0;}
 public long ExecuteBatch(int count){if(reuse){if(variant=="baseline")for(int i=0;i<count;i++){if((i&4095)==0)cancel.ThrowIfCancellationRequested();int j=i%inputs.Length;checksum+=control.IsMatch(inputs[j])?1:0;expectedChecksum+=expected[j]?1:0;}else for(int i=0;i<count;i++){if((i&4095)==0)cancel.ThrowIfCancellationRequested();int j=i%inputs.Length;checksum+=candidate.IsMatch(inputs[j])?1:0;expectedChecksum+=expected[j]?1:0;}}else{if(variant=="baseline")for(int i=0;i<count;i++){if((i&4095)==0)cancel.ThrowIfCancellationRequested();int j=i%inputs.Length;checksum+=Control.WildcardMatch.IsMatch(inputs[j],pattern)?1:0;expectedChecksum+=expected[j]?1:0;}else for(int i=0;i<count;i++){if((i&4095)==0)cancel.ThrowIfCancellationRequested();int j=i%inputs.Length;checksum+=Tedd.WildcardMatch.IsMatch(inputs[j],pattern)?1:0;expectedChecksum+=expected[j]?1:0;}}return count;}
 public ValidationResult Validate()=>new(checksum==expectedChecksum);public void Cleanup(){}
}
''')
 p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True)
 (R/'evidence/rig-build-initial.txt').write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError('Build failed')
 stop=R/'stop-target-initial';env=os.environ.copy();env['DOTNET_TieredCompilation']='0'
 with (R/'target-initial.txt').open('w') as out:
  p=subprocess.Popen([D,str(rig/'bin/Release/net10.0/WildcardInteropRig.dll'),'--listen',str(R/'catalog'),str(stop)],stdout=out,stderr=subprocess.STDOUT,env=env)
 (R/'target-initial.pid').write_text(str(p.pid));print('Target',p.pid,flush=True)
 time.sleep(1)
 print(lab('lab.discover',{'action':'targets'},'targets-initial'))

