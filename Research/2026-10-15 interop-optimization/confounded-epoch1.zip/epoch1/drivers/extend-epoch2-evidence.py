import pathlib
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch2')
p=R/'details-final.py';text=p.read_text();text+=r'''
env.update(WILDCARD_NATIVE_LIBRARY=str(R/'final/native-build/wildcard_native.dll'),DOTNET_JitDisasm='Tedd.WildcardMatchBenchmark.NativeMatcher:MatchEach*',DOTNET_JitStdOutFile=str(R/'evidence/final-interop-jit.asm'))
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe',str(assembly),'--validate-native'],env=env,cwd=R/'final',capture_output=True,text=True);(R/'evidence/final-interop-jit-validation.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Interop generated-code validation failed')
''';p.write_text(text)
p=R/'aggregate-final.py';text=p.read_text().replace("('evidence/final-jit.asm','final-jit.asm'),","('evidence/final-jit.asm','final-jit.asm'),('evidence/final-interop-jit.asm','final-interop-jit.asm'),");p.write_text(text)
