import pathlib
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');R=P/'epoch4';p=R/'assess-final.py';text=p.read_text(encoding='utf-8');text+=r'''
import re
prior=[]
for epoch in ['epoch2','epoch3']:
 for group in ['NativeMatching','Interop']:
  file=P/epoch/'final-artifacts/results'/f'Tedd.WildcardMatchBenchmark.{group}Benchmarks-report-full.json'
  for x in json.loads(file.read_text())['Benchmarks']:
   shape,library=re.search(r'Case: ([^,)]+)',x['FullName']).group(1).split('/')
   prior.append({'epoch':epoch,'workload':shape,'library':library,'method':x['Method'],'full_name':x['FullName'],'mean_ns':x['Statistics']['Mean']})
references=[]
for x in best:
 control=min((y for y in prior if y['workload']==x['workload']),key=lambda y:y['mean_ns'])
 references.append({'workload':x['workload'],'final_tedd_ns':x['tedd_ns'],'earlier_control':control,'cost_reduction_percent':100*(1-x['tedd_ns']/control['mean_ns']),'meets_20_percent_mean_target':x['tedd_ns']<=.8*control['mean_ns']})
checks['all_four_conservative_prior_native_margins_at_least_20_percent']=all(x['meets_20_percent_mean_target'] for x in references)
(O/'prior-native-reference.json').write_text(json.dumps(references,indent=2),encoding='utf-8')
for target in [R/'evidence/adoption-assessment.json',O/'adoption-assessment.json']:target.write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps({'final_checks':checks,'separate_prior_native_references':references},indent=2),flush=True)
''';p.write_text(text,encoding='utf-8')
p=R/'write-final-report.py';text=p.read_text(encoding='utf-8');text+=r'''
refs=json.loads((O/'prior-native-reference.json').read_text());extra=['','## Earlier native-build reference','','The adapter rebuild changed observed native costs, particularly on MultiStar. The following conservative reference retains the lowest earlier unconfounded native mean. These are separately identified cross-build/epoch comparisons; their samples are not pooled with the final experiment and they do not supply a combined confidence interval. No hardware cause is inferred.','','| Workload | Earlier native mean ns | Final Tedd mean ns | Lower mean cost |','| --- | ---: | ---: | ---: |']
for x in refs:extra.append(f"| {x['workload']} | {x['earlier_control']['mean_ns']:.3f} ({x['earlier_control']['library']}, {x['earlier_control']['epoch']}) | {x['final_tedd_ns']:.3f} | {x['cost_reduction_percent']:.2f}% |")
extra+=['','Unrounded source identities are in [prior-native-reference.json](prior-native-reference.json). The earlier normal-priority confirmation families remain inconclusive on one guard each; the final LF-improved source uses a separately frozen twenty-block, High-priority regime. This is not extra sampling of, or replacement for, those earlier plans.']
with (O/'README.md').open('a',encoding='utf-8') as f:f.write('\n'.join(extra)+'\n')
''';p.write_text(text,encoding='utf-8')
text=(P/'preserve-final.py').read_text(encoding='utf-8').replace("R=P/'epoch3'","R=P/'epoch4'").replace("('epoch3',R)","('epoch3',P/'epoch3'),('epoch4',R)").replace('epoch 3 contains the final anchor-proof change','epoch 3 contains the anchor-proof change; epoch 4 contains deferred LF validation and the final twenty-block regime');(R/'preserve-final.py').write_text(text,encoding='utf-8')
