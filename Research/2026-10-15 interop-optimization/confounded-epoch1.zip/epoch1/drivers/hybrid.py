import pathlib,shutil,sys,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');rig=R/'trial-hybrid';shutil.copytree(R/'trial-taildispatch',rig,dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','obj'))
p=rig/'candidate/WildcardMatch.cs';text=p.read_text();text=text.replace('return _stringMatch(this, input);',r'''if (_fast)
        {
            if (_literal) return DefaultWildcardEngine.IsMatch(input.AsSpan(), _matchPattern.AsSpan(), false, true);
            if (_fixed != null) return _fixed.IsMatch(input.AsSpan());
        }
        return _stringMatch(this, input);''')
text=text.replace(': matcher._segments!.IsMatch(input.AsSpan());',': MatchSegmentsString(matcher, input);');text=text.replace('    private static bool MatchSegmentsString','    [MethodImpl(MethodImplOptions.NoInlining)]\n    private static bool MatchSegmentsString');p.write_text(text)
p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text();needle='  if(length<=_packedLength)return false; int tail=input.Slice(0,length).LastIndexOf(_packedTail); int last=tail-_packedLength;if(last<0)return false;';assert needle in text;text=text.replace(needle,r'''  return MatchPackedScalar(input,length);
 }
 [MethodImpl(MethodImplOptions.NoInlining)]
 bool MatchPackedScalar(ReadOnlySpan<char> input,int length){
  if(length<=_packedLength)return false; int tail=input.Slice(0,length).LastIndexOf(_packedTail); int last=tail-_packedLength;if(last<0)return false;''');p.write_text(text)
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence/hybrid-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Hybrid build failed')
sys.path.insert(0,str(R));from rpc import *
i=launch(rig,'hybrid');g=grant(i,'execute_registered_scenario',120,'hybrid');s=Session('hybrid')
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'hybrid-scenarios')['scenarios'];out=[]
 for shape in ['Literal','Simple','MultiStar','LongText','Diverse']:
  a=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,a,'hybrid-'+shape,30000 if shape=='LongText' else 300000);ex,c=execute(s,i,p,g,'hybrid-'+shape);out.append({'shape':shape,'execution_id':ex,'comparison':c})
 (R/'evidence/hybrid-summary.json').write_text(json.dumps(out,indent=2))
finally:s.close();(R/'stop-target-hybrid').touch()
