import pathlib,subprocess,os
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization')
for label,project in [('baseline','cross-baseline'),('simd','pilot'),('dispatch','pilot-dispatch'),('packedtail','pilot-packedtail')]:
 env=os.environ.copy();env.update(DOTNET_TieredCompilation='0',DOTNET_JitDisasm='Tedd.WildcardMatch:IsMatch Tedd.ShortPattern:MatchPacked',DOTNET_JitStdOutFile=str(R/'evidence'/f'{label}-jit.asm'))
 assembly=R/project/'src/Tedd.WildcardMatch.Benchmark/bin/Release/net10.0/Tedd.WildcardMatch.Benchmark.dll'
 p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe',str(assembly),'--validate-packages'],env=env,cwd=R/project,capture_output=True,text=True)
 (R/'evidence'/f'{label}-jit-validation.txt').write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError('JIT validation failed '+label)
 print(label,'JIT evidence retained',flush=True)
