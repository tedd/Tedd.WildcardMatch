import pathlib,shutil,sys,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');rig=R/'trial-literalhot';shutil.copytree(R/'trial-directsplit',rig,dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','obj'))
p=rig/'candidate/WildcardMatch.cs';text=p.read_text();start=text.index('        if (_fast)\n        {',text.index('public bool IsMatch(string input)'));end=text.index('        return _stringMatch(this, input);',start);text=text[:start]+'        if (_fast && _literal) return DefaultWildcardEngine.IsMatch(input.AsSpan(), _matchPattern.AsSpan(), false, true);\n'+text[end:];text=text.replace('    private readonly ShortPattern? _packed;\n','').replace('        _packed = _short != null && _short.IsPacked ? _short : null;\n','');p.write_text(text)
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence/literalhot-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Build failed literalhot')
sys.path.insert(0,str(R));from rpc import *
i=launch(rig,'literalhot');g=grant(i,'execute_registered_scenario',120,'literalhot');s=Session('literalhot')
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'literalhot-scenarios')['scenarios'];out=[]
 for shape in ['Literal','Simple','MultiStar','LongText','Diverse']:
  a=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,a,'literalhot-'+shape,30000 if shape=='LongText' else 300000);ex,c=execute(s,i,p,g,'literalhot-'+shape);out.append({'shape':shape,'execution_id':ex,'comparison':c})
 (R/'evidence/literalhot-summary.json').write_text(json.dumps(out,indent=2))
finally:s.close();(R/'stop-target-literalhot').touch()
