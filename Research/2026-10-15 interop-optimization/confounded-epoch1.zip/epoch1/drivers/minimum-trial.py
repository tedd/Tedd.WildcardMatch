import pathlib,sys,shutil,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch2');REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch');sys.path.insert(0,str(R));from rpc import *
rig=R/'trial-minimum';shutil.copytree(R/'rig',rig,ignore=shutil.ignore_patterns('bin','obj'),dirs_exist_ok=True)
for arm,ns in [('baseline','Control'),('candidate','Tedd')]:
 folder=rig/arm
 for p in folder.glob('*.cs'):p.unlink()
 for p in (REPO/'src/Tedd.WildcardMatch').glob('*.cs'):
  text=p.read_text(encoding='utf-8-sig').replace('namespace Tedd;','namespace '+ns+';')
  if arm=='baseline':text=text.replace('[assembly: CLSCompliant(true)]','')
  (folder/p.name).write_text(text,encoding='utf-8')
p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text(encoding='utf-8')
start=text.index('#if NET10_0_OR_GREATER',text.index('internal bool MatchPacked'))
shortcut=r"""        // At the minimum length every star consumes zero characters.
        // Width 3–4 plus the tail proves that the four-unit read is in bounds.
        if (length == _packedLength + 1)
            return (ReadWord(input, 0) & _packedMask) == _packedValue
                && input[_packedLength] == _packedTail
                && (_singleline || input.Slice(0, _packedLength).IndexOf('\n') < 0);
"""
text=text[:start]+shortcut+text[start:];p.write_text(text,encoding='utf-8')
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence/minimum-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Ordinal trial build failed')
i=launch(rig,'minimum');g=grant(i,'execute_registered_scenario',100,'minimum',1200);s=Session('minimum');summary=[]
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'minimum-scenarios')['scenarios']
 s.call('lab.discover',{'action':'compatibility','target_id':i['id']},'minimum-compatibility')
 s.call('lab.experiment',{'action':'create_hypothesis','mechanism':'At the compiled minimum input length all stars consume zero characters. Compare the masked first segment and literal tail directly, retaining question-mark LF checks.','prediction':'Avoid tail-search setup on minimal inputs. Five scenarios, ten paired descriptive blocks each; no sample expansion or exclusions.','evidence_ids':[]},'minimum-hypothesis')
 for shape in ['Literal','Simple','MultiStar','Diverse','LongText']:
  desc=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,desc,'minimum-'+shape,512 if shape.startswith('Dense') else 30000 if shape=='LongText' else 300000)
  ex,c=execute(s,i,p,g,'minimum-'+shape);summary.append({'shape':shape,'execution_id':ex,'comparison':c});(R/'evidence/minimum-summary.json').write_text(json.dumps(summary,indent=2))
finally:s.close();(R/'stop-target-ordinal').touch()
