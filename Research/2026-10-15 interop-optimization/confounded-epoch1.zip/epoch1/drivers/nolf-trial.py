import pathlib,sys,shutil,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch2');REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch');sys.path.insert(0,str(R));from rpc import *
rig=R/'trial-nolf';shutil.copytree(R/'rig',rig,ignore=shutil.ignore_patterns('bin','obj'),dirs_exist_ok=True)
for arm,ns in [('baseline','Control'),('candidate','Tedd')]:
 folder=rig/arm
 for p in folder.glob('*.cs'):p.unlink()
 for p in (REPO/'src/Tedd.WildcardMatch').glob('*.cs'):
  text=p.read_text(encoding='utf-8-sig').replace('namespace Tedd;','namespace '+ns+';')
  if arm=='baseline':text=text.replace('[assembly: CLSCompliant(true)]','')
  (folder/p.name).write_text(text,encoding='utf-8')
p=rig/'candidate/ShortPattern.cs';text=p.read_text(encoding='utf-8')
text=text.replace('private readonly bool _singleline;','private readonly bool _singleline, _containsLf;')
text=text.replace('ulong accept, bool singleline)','ulong accept, bool singleline, bool containsLf)').replace('_singleline = singleline; }','_singleline = singleline; _containsLf = containsLf; }')
text=text.replace('bool previousStar = false;','bool previousStar = false, containsLf = false;').replace('            if (token == \'*\' && previousStar)',"            if (token == '\\n') containsLf = true;\n            if (token == '*' && previousStar)")
text=text.replace('1UL << tokenIndex, singleline);','1UL << tokenIndex, singleline, containsLf);')
needle='        if (_packedLength != 0) return MatchPacked(input);'
extra=r"""
        if (!_singleline && !_containsLf)
        {
            if (input.Length > 0 && input[input.Length - 1] == '\n') input = input.Slice(0, input.Length - 1);
            return MatchWithoutLineChecks(input) && input.IndexOf('\n') < 0;
        }
"""
text=text.replace(needle,needle+extra)
helper=r"""
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private bool MatchWithoutLineChecks(ReadOnlySpan<char> input)
    {
        ulong active = 1 | ((1 & _stars) << 1);
        for (int i = 0; i < input.Length; i++)
        {
            char value = input[i];
            ref readonly Entry entry = ref _literals[value & (_literals.Length - 1)];
            ulong literals = entry.Code == value ? entry.Mask : 0;
            active = ((active & (literals | _questions)) << 1) | (active & _stars);
            active |= (active & _stars) << 1;
            if (active == 0) return false;
        }
        return (active & _accept) != 0;
    }
"""
pos=text.rfind('\n}');text=text[:pos]+helper+text[pos:];p.write_text(text,encoding='utf-8')
p=rig/'Program.cs';text=p.read_text(encoding='utf-8').replace('"Newline","Diverse"','"Newline","Diverse","GeneralShort"').replace('"Diverse"=>"*a?c*e*",_=>','"Diverse"=>"*a?c*e*","GeneralShort"=>"*a*b*c*",_=>')
text=text.replace(' "Diverse"=>Enumerable.Range', ''' "GeneralShort"=>["abcdef","abc","def","ac","xaxbxc","abbbc","a\\nbc","abcdef\\n",new string('x',32)+"abc"],
 "Diverse"=>Enumerable.Range''');p.write_text(text,encoding='utf-8')
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence/nolf-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Ordinal trial build failed')
i=launch(rig,'nolf');g=grant(i,'execute_registered_scenario',120,'nolf',1200);s=Session('nolf');summary=[]
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'nolf-scenarios')['scenarios']
 s.call('lab.discover',{'action':'compatibility','target_id':i['id']},'nolf-compatibility')
 s.call('lab.experiment',{'action':'create_hypothesis','mechanism':'For default non-Singleline patterns without literal LF, trim the optional final LF and defer interior-LF rejection until bitmap acceptance. Remove per-character line gating from this proven regime.','prediction':'Reduce generic short bitmap cost while retaining literal-LF and Singleline fallback semantics. Six fixed scenarios, ten paired descriptive blocks each.','evidence_ids':[]},'nolf-hypothesis')
 for shape in ['GeneralShort','Literal','Simple','MultiStar','Diverse','LongText']:
  desc=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,desc,'nolf-'+shape,512 if shape.startswith('Dense') else 30000 if shape=='LongText' else 300000)
  ex,c=execute(s,i,p,g,'nolf-'+shape);summary.append({'shape':shape,'execution_id':ex,'comparison':c});(R/'evidence/nolf-summary.json').write_text(json.dumps(summary,indent=2))
finally:s.close();(R/'stop-target-ordinal').touch()
