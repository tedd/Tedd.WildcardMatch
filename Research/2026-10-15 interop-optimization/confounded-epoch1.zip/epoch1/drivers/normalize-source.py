import pathlib,subprocess
root=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch')
for name in ['CompiledSegments.cs','ShortPattern.cs','WildcardMatch.cs']:
 path=root/'src/Tedd.WildcardMatch'/name
 old=subprocess.check_output(['git','show','7574a36:src/Tedd.WildcardMatch/'+name],cwd=root)
 text=path.read_text(encoding='utf-8-sig');newline='\r\n' if b'\r\n' in old else '\n'
 path.write_bytes((b'\xef\xbb\xbf' if old.startswith(b'\xef\xbb\xbf') else b'')+text.replace('\r\n','\n').replace('\n',newline).encode())
print('Original source encodings and line endings preserved')
