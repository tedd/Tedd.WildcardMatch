import pathlib,sys,shutil,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch2');REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch');sys.path.insert(0,str(R));from rpc import *
rig=R/'trial-ordinal';shutil.copytree(R/'rig',rig,ignore=shutil.ignore_patterns('bin','obj'),dirs_exist_ok=True)
for arm,ns in [('baseline','Control'),('candidate','Tedd')]:
 folder=rig/arm
 for p in folder.glob('*.cs'):p.unlink()
 for p in (REPO/'src/Tedd.WildcardMatch').glob('*.cs'):
  text=p.read_text(encoding='utf-8-sig').replace('namespace Tedd;','namespace '+ns+';')
  if arm=='baseline':text=text.replace('[assembly: CLSCompliant(true)]','')
  (folder/p.name).write_text(text,encoding='utf-8')
p=rig/'candidate/CompiledSegments.cs';text=p.read_text(encoding='utf-8');old='_pattern.AsSpan(segment.Offset + segment.Anchor, segment.AnchorLength))';new='_pattern.AsSpan(segment.Offset + segment.Anchor, segment.AnchorLength), StringComparison.Ordinal)'
if text.count(old)!=2:raise RuntimeError('Expected two ordinal-search changes')
p.write_text(text.replace(old,new),encoding='utf-8')
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence/ordinal-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Ordinal trial build failed')
i=launch(rig,'ordinal');g=grant(i,'execute_registered_scenario',100,'ordinal',1200);s=Session('ordinal');summary=[]
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'ordinal-scenarios')['scenarios']
 s.call('lab.discover',{'action':'compatibility','target_id':i['id']},'ordinal-compatibility')
 s.call('lab.experiment',{'action':'create_hypothesis','mechanism':'Use the ordinal character-span IndexOf overload for literal anchors rather than generic span equality search. Both preserve ordinal UTF-16 equality; generated-code selection may differ.','prediction':'Improve long-text literal searches without regressions on dense anchors or short packed matching. Ten paired descriptive blocks, no exclusions or sample expansion.','evidence_ids':[]},'ordinal-hypothesis')
 for shape in ['LongText','Diverse','MultiStar','Dense4096','Dense16384']:
  desc=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,desc,'ordinal-'+shape,512 if shape.startswith('Dense') else 30000 if shape=='LongText' else 300000)
  ex,c=execute(s,i,p,g,'ordinal-'+shape);summary.append({'shape':shape,'execution_id':ex,'comparison':c});(R/'evidence/ordinal-summary.json').write_text(json.dumps(summary,indent=2))
finally:s.close();(R/'stop-target-ordinal').touch()
