import pathlib,sys,shutil,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch2');REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch');sys.path.insert(0,str(R));from rpc import *
rig=R/'trial-packedfirst';shutil.copytree(R/'rig',rig,ignore=shutil.ignore_patterns('bin','obj'),dirs_exist_ok=True)
for arm,ns in [('baseline','Control'),('candidate','Tedd')]:
 folder=rig/arm
 for p in folder.glob('*.cs'):p.unlink()
 for p in (REPO/'src/Tedd.WildcardMatch').glob('*.cs'):
  text=p.read_text(encoding='utf-8-sig').replace('namespace Tedd;','namespace '+ns+';')
  if arm=='baseline':text=text.replace('[assembly: CLSCompliant(true)]','')
  (folder/p.name).write_text(text,encoding='utf-8')
p=rig/'candidate/WildcardMatch.cs';text=p.read_text(encoding='utf-8')
old='            if (input.Length <= 32 && _packed != null) return _packed.MatchPacked(input.AsSpan());\n'
if text.count(old)!=1:raise RuntimeError('Unexpected packed shortcut')
text=text.replace(old,'');needle='        if (_fast)\n        {'
if text.count(needle)!=1:raise RuntimeError('Unexpected direct dispatcher')
text=text.replace(needle,'        if (input.Length <= 32 && _packed != null) return _packed.MatchPacked(input.AsSpan());\n'+needle)
p.write_text(text,encoding='utf-8')
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence/packedfirst-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Ordinal trial build failed')
i=launch(rig,'packedfirst');g=grant(i,'execute_registered_scenario',100,'packedfirst',1200);s=Session('packedfirst');summary=[]
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'packedfirst-scenarios')['scenarios']
 s.call('lab.discover',{'action':'compatibility','target_id':i['id']},'packedfirst-compatibility')
 s.call('lab.experiment',{'action':'create_hypothesis','mechanism':'A prepared packed plan implies the ordinal infinite-timeout fast case. Test that proven shortcut before the generic literal/fixed route guards.','prediction':'Reduce short-star dispatch cost with at most five percent regression against the original source on all mandatory guards; ten fixed paired descriptive blocks on five scenarios.','evidence_ids':[]},'packedfirst-hypothesis')
 for shape in ['Literal','Simple','MultiStar','Diverse','LongText']:
  desc=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,desc,'packedfirst-'+shape,512 if shape.startswith('Dense') else 1000 if shape=='Newline' else 30000 if shape=='LongText' else 300000)
  ex,c=execute(s,i,p,g,'packedfirst-'+shape);summary.append({'shape':shape,'execution_id':ex,'comparison':c});(R/'evidence/packedfirst-summary.json').write_text(json.dumps(summary,indent=2))
finally:s.close();(R/'stop-target-ordinal').touch()
