import pathlib,shutil,subprocess,os
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');dst=R/'pilot-dispatch';shutil.copytree(R/'pilot',dst,dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','obj'))
for src in (R/'trial-dispatch/candidate').glob('*.cs'):shutil.copy2(src,dst/'src/Tedd.WildcardMatch'/src.name)
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','src/Tedd.WildcardMatch.Benchmark','-c','Release'],cwd=dst,capture_output=True,text=True);(R/'evidence/pilot-dispatch-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Build failed')
env=os.environ.copy();env['WILDCARD_NATIVE_LIBRARY']=str(R/'native/native-build/wildcard_native.dll')
with (R/'evidence/pilot-dispatch-benchmark.txt').open('w') as out:
 p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','run','--project','src/Tedd.WildcardMatch.Benchmark','-c','Release','--no-build','--','--filter','*MatchingBenchmarks*MultiStar/TeddDirectReused*','*MatchingBenchmarks*Literal/TeddDirectReused*','*MatchingBenchmarks*Simple/TeddDirectReused*','*MatchingBenchmarks*LongText/TeddDirectReused*','--launchCount','1','--warmupCount','3','--iterationCount','10','--iterationTime','100','--affinity','1073741824','--artifacts',str(R/'pilot-dispatch-artifacts')],cwd=dst,env=env,stdout=out,stderr=subprocess.STDOUT)
if p.returncode:raise RuntimeError('Pilot failed')
