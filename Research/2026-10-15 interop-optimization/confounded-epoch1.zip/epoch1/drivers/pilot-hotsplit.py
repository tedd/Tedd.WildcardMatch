import pathlib,sys,json,shutil,subprocess,os
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch');dst=R/'pilot-hotsplit';dst.mkdir(exist_ok=True)
shutil.copytree(REPO/'src',dst/'src',dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','obj'))
for n in ['global.json','LICENSE','README.md']:shutil.copy2(REPO/n,dst/n)
for n in ['ShortPattern.cs','ShortPattern.Packed.cs','WildcardMatch.cs']:shutil.copy2(R/'trial-hotsplit/candidate'/n,dst/'src/Tedd.WildcardMatch'/n)
shutil.copy2(R/'trial-knownanchor/candidate/CompiledSegments.cs',dst/'src/Tedd.WildcardMatch/CompiledSegments.cs')
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','src/Tedd.WildcardMatch.Benchmark','-c','Release'],cwd=dst,capture_output=True,text=True);(R/'evidence/pilot-hotsplit-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Pilot build failed')
env=os.environ.copy();env['WILDCARD_NATIVE_LIBRARY']=str(R/'native/native-build/wildcard_native.dll')
with (R/'evidence/pilot-hotsplit-benchmark.txt').open('w') as out:
 p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','run','--project','src/Tedd.WildcardMatch.Benchmark','-c','Release','--no-build','--','--filter','*MatchingBenchmarks*MultiStar/TeddDirectReused*','*MatchingBenchmarks*LongText/TeddDirectReused*','--launchCount','1','--warmupCount','3','--iterationCount','10','--iterationTime','100','--affinity','1073741824','--artifacts',str(R/'pilot-hotsplit-artifacts')],cwd=dst,env=env,stdout=out,stderr=subprocess.STDOUT)
if p.returncode:raise RuntimeError('Pilot benchmark failed')

