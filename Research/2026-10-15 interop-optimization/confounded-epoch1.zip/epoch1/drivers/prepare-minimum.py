import pathlib,json
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');text=(P/'ordinal-trial.py').read_text(encoding='utf-8')
text=text.replace('trial-ordinal','trial-minimum').replace("'ordinal'","'minimum'").replace('ordinal-','minimum-').replace('ordinal-summary','minimum-summary')
start=text.index("p=rig/'candidate/CompiledSegments.cs'");end=text.index('p=subprocess.run(',start)
change=r'''p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text(encoding='utf-8')
start=text.index('#if NET10_0_OR_GREATER',text.index('internal bool MatchPacked'))
shortcut=r"""        // At the minimum length every star consumes zero characters.
        // Width 3–4 plus the tail proves that the four-unit read is in bounds.
        if (length == _packedLength + 1)
            return (ReadWord(input, 0) & _packedMask) == _packedValue
                && input[_packedLength] == _packedTail
                && (_singleline || input.Slice(0, _packedLength).IndexOf('\n') < 0);
"""
text=text[:start]+shortcut+text[start:];p.write_text(text,encoding='utf-8')
'''
text=text[:start]+change+text[end:]
a=text.index(" s.call('lab.experiment'");b=text.index(' for shape in',a)
text=text[:a]+" s.call('lab.experiment',{'action':'create_hypothesis','mechanism':'At the compiled minimum input length all stars consume zero characters. Compare the masked first segment and literal tail directly, retaining question-mark LF checks.','prediction':'Avoid tail-search setup on minimal inputs. Five scenarios, ten paired descriptive blocks each; no sample expansion or exclusions.','evidence_ids':[]},'minimum-hypothesis')\n"+text[b:]
text=text.replace("['LongText','Diverse','MultiStar','Dense4096','Dense16384']","['Literal','Simple','MultiStar','Diverse','LongText']")
(P/'minimum-trial.py').write_text(text,encoding='utf-8')
(P/'jobs/099.json').write_text(json.dumps({'args':[r'C:\Python314\python.exe','-u',str(P/'minimum-trial.py')],'output':'epoch2/evidence/minimum-phase.txt','timeout':1800}))
