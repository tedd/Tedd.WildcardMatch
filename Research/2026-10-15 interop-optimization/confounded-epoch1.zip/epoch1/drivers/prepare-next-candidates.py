import pathlib,json
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');base=(P/'ordinal-trial.py').read_text(encoding='utf-8')
for name in ['anchor','packedfirst']:
 text=base.replace('trial-ordinal','trial-'+name).replace("'ordinal'","'"+name+"'").replace('ordinal-',name+'-').replace('ordinal-summary',name+'-summary')
 start=text.index("p=rig/'candidate/CompiledSegments.cs'");end=text.index('p=subprocess.run(',start)
 if name=='anchor':
  change=r'''p=rig/'candidate/CompiledSegments.cs';text=p.read_text(encoding='utf-8')
helper=r"""    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private bool MatchesOutsideAnchor(ReadOnlySpan<char> input, in Segment segment, int position)
    {
        // IndexOf already proved the complete literal anchor. Prefix/suffix
        // positions outside it still require wildcard and newline checks.
        for (int i = 0; i < segment.Anchor; i++)
        {
            char token = _pattern[segment.Offset + i], value = input[position + i];
            if (token == '?' ? !_singleline && value == '\n' : token != value) return false;
        }
        for (int i = segment.Anchor + segment.AnchorLength; i < segment.Length; i++)
        {
            char token = _pattern[segment.Offset + i], value = input[position + i];
            if (token == '?' ? !_singleline && value == '\n' : token != value) return false;
        }
        return true;
    }

"""
text=text.replace('    private bool Window(ReadOnlySpan<char> input)',helper+'    private bool Window(ReadOnlySpan<char> input)')
old='Matches(input, in segment, candidate)'
if text.count(old)!=1:raise RuntimeError('Unexpected anchor verification sites')
text=text.replace(old,'(segment.Anchor < 0 ? Matches(input, in segment, candidate) : MatchesOutsideAnchor(input, in segment, candidate))')
p.write_text(text,encoding='utf-8')
'''
  shapes="['Dense4096','Dense16384','LongText','Diverse','MultiStar','Newline']";mechanism='IndexOf proves a complete literal anchor even when questions or other literals surround it; verify only the remaining positions after a successful search. Prefix/suffix matches still verify everything.';prediction='Reduce dense-anchor work while preserving all wildcard/newline outcomes; ten fixed paired descriptive blocks on six scenarios.';ops='120'
 else:
  change=r'''p=rig/'candidate/WildcardMatch.cs';text=p.read_text(encoding='utf-8')
old='            if (input.Length <= 32 && _packed != null) return _packed.MatchPacked(input.AsSpan());\n'
if text.count(old)!=1:raise RuntimeError('Unexpected packed shortcut')
text=text.replace(old,'');needle='        if (_fast)\n        {'
if text.count(needle)!=1:raise RuntimeError('Unexpected direct dispatcher')
text=text.replace(needle,'        if (input.Length <= 32 && _packed != null) return _packed.MatchPacked(input.AsSpan());\n'+needle)
p.write_text(text,encoding='utf-8')
'''
  shapes="['Literal','Simple','MultiStar','Diverse','LongText']";mechanism='A prepared packed plan implies the ordinal infinite-timeout fast case. Test that proven shortcut before the generic literal/fixed route guards.';prediction='Reduce short-star dispatch cost with at most five percent regression against the original source on all mandatory guards; ten fixed paired descriptive blocks on five scenarios.';ops='100'
 text=text[:start]+change+text[end:]
 a=text.index(" s.call('lab.experiment'");b=text.index(' for shape in',a)
 text=text[:a]+f" s.call('lab.experiment',{{'action':'create_hypothesis','mechanism':{mechanism!r},'prediction':{prediction!r},'evidence_ids':[]}},'{name}-hypothesis')\n"+text[b:]
 text=text.replace("['LongText','Diverse','MultiStar','Dense4096','Dense16384']",shapes).replace("',100,'","',"+ops+",'")
 text=text.replace("else 30000 if shape=='LongText' else 300000","else 1000 if shape=='Newline' else 30000 if shape=='LongText' else 300000")
 (P/(name+'-trial.py')).write_text(text,encoding='utf-8')
for n,name in [(97,'anchor'),(98,'packedfirst')]:
 (P/'jobs'/f'{n:03}.json').write_text(json.dumps({'args':[r'C:\Python314\python.exe','-u',str(P/(name+'-trial.py'))],'output':'epoch2/evidence/'+name+'-phase.txt','timeout':1800}))
