import pathlib,json
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');base=(P/'sequence-trial.py').read_text(encoding='utf-8');text=base.replace('trial-sequence','trial-nolf').replace("'sequence'","'nolf'").replace('sequence-','nolf-').replace('sequence-summary','nolf-summary')
start=text.index("p=rig/'candidate/ShortPattern.cs'");end=text.index("p=rig/'Program.cs'",start)
change=r'''p=rig/'candidate/ShortPattern.cs';text=p.read_text(encoding='utf-8')
text=text.replace('private readonly bool _singleline;','private readonly bool _singleline, _containsLf;')
text=text.replace('ulong accept, bool singleline)','ulong accept, bool singleline, bool containsLf)').replace('_singleline = singleline; }','_singleline = singleline; _containsLf = containsLf; }')
text=text.replace('bool previousStar = false;','bool previousStar = false, containsLf = false;').replace('            if (token == \'*\' && previousStar)',"            if (token == '\\n') containsLf = true;\n            if (token == '*' && previousStar)")
text=text.replace('1UL << tokenIndex, singleline);','1UL << tokenIndex, singleline, containsLf);')
needle='        if (_packedLength != 0) return MatchPacked(input);'
extra=r"""
        if (!_singleline && !_containsLf)
        {
            if (input.Length > 0 && input[input.Length - 1] == '\n') input = input.Slice(0, input.Length - 1);
            return MatchWithoutLineChecks(input) && input.IndexOf('\n') < 0;
        }
"""
text=text.replace(needle,needle+extra)
helper=r"""
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private bool MatchWithoutLineChecks(ReadOnlySpan<char> input)
    {
        ulong active = 1 | ((1 & _stars) << 1);
        for (int i = 0; i < input.Length; i++)
        {
            char value = input[i];
            ref readonly Entry entry = ref _literals[value & (_literals.Length - 1)];
            ulong literals = entry.Code == value ? entry.Mask : 0;
            active = ((active & (literals | _questions)) << 1) | (active & _stars);
            active |= (active & _stars) << 1;
            if (active == 0) return false;
        }
        return (active & _accept) != 0;
    }
"""
pos=text.rfind('\n}');text=text[:pos]+helper+text[pos:];p.write_text(text,encoding='utf-8')
'''
text=text[:start]+change+text[end:]
a=text.index(" s.call('lab.experiment'");b=text.index(' for shape in',a)
text=text[:a]+" s.call('lab.experiment',{'action':'create_hypothesis','mechanism':'For default non-Singleline patterns without literal LF, trim the optional final LF and defer interior-LF rejection until bitmap acceptance. Remove per-character line gating from this proven regime.','prediction':'Reduce generic short bitmap cost while retaining literal-LF and Singleline fallback semantics. Six fixed scenarios, ten paired descriptive blocks each.','evidence_ids':[]},'nolf-hypothesis')\n"+text[b:]
(P/'nolf-trial.py').write_text(text,encoding='utf-8');(P/'jobs/113.json').write_text(json.dumps({'args':[r'C:\Python314\python.exe','-u',str(P/'nolf-trial.py')],'output':'epoch2/evidence/nolf-phase.txt','timeout':1800}))
