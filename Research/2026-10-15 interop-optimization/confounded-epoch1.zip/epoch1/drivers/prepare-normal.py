import pathlib,sys,shutil,subprocess,json,hashlib,os
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch')
program=(R/'rig/Program.cs').read_text().replace('Control.WildcardMatch','Tedd.WildcardMatch')
program=program.replace('"Newline","Diverse"','"Newline","Diverse","GeneralShort","FixedMedium","FixedLong","LiteralLong"')
program=program.replace('var host = new HarnessHost(registry,args[1]);','registry.Register(new PortfolioScenario());\nvar host = new HarnessHost(registry,args[1]);')
program=program.replace('"Diverse"=>"*a?c*e*",_=>','"Diverse"=>"*a?c*e*","GeneralShort"=>"*a*b*c*","FixedMedium"=>"abcdefghijklmnop?","FixedLong"=>new string(\'a\',512)+"?z","LiteralLong"=>new string(\'a\',512)+"z",_=>')
program=program.replace(' "Diverse"=>Enumerable.Range',r''' "GeneralShort"=>["abcdef","abc","def","ac","xaxbxc","abbbc","a\nbc","abcdef\n",new string('x',32)+"abc"],
 "FixedMedium"=>["abcdefghijklmnopX","abcdefghijklmnop\n","abcdefghijklmnopX\n","xbcdefghijklmnopY","abcdefghijklmnop"],
 "FixedLong"=>[new string('a',512)+"Qz",new string('a',512)+"Qy",new string('a',512)+"\nz",new string('a',512)+"Qz\n"],
 "LiteralLong"=>[new string('a',512)+"z",new string('a',512)+"y","x"+new string('a',512)+"z",new string('a',512)+"z\n"],
 "Diverse"=>Enumerable.Range''')
start=program.index(' public long ExecuteBatch(int count)');end=program.index(' public ValidationResult Validate()',start)
program=program[:start]+r''' public long ExecuteBatch(int count){
  if(reuse)for(int i=0;i<count;i++){if((i&4095)==0)cancel.ThrowIfCancellationRequested();int j=i%inputs.Length;checksum+=candidate.IsMatch(inputs[j])?1:0;expectedChecksum+=expected[j]?1:0;}
  else for(int i=0;i<count;i++){if((i&4095)==0)cancel.ThrowIfCancellationRequested();int j=i%inputs.Length;checksum+=Tedd.WildcardMatch.IsMatch(inputs[j],pattern)?1:0;expectedChecksum+=expected[j]?1:0;}
  return count;
 }
'''+program[end:]
program=program.replace(' static bool Oracle(',' internal static bool Oracle(')
program=program.replace(' public ScenarioDescriptor Describe()=>',' internal string Pattern => pattern; internal string[] Inputs => inputs;\n public ScenarioDescriptor Describe()=>')
program+=r'''
sealed class PortfolioScenario : ISynchronousScenario {
 readonly string[] patterns;readonly string[] inputs=new string[1024];readonly bool[] expected=new bool[1024];readonly Tedd.WildcardMatch[] matchers=new Tedd.WildcardMatch[1024];long checksum,expectedChecksum;CancellationToken cancel;
 public PortfolioScenario(){var shapes=new[]{"Literal","Simple","MultiStar","LongText"};patterns=new string[4];for(int k=0;k<4;k++){var fixture=new MatchScenario(shapes[k],true);patterns[k]=fixture.Pattern;var matcher=new Tedd.WildcardMatch(patterns[k]);for(int j=0;j<256;j++){int index=k*256+j;inputs[index]=fixture.Inputs[j%fixture.Inputs.Length];expected[index]=MatchScenario.Oracle(inputs[index],patterns[k]);matchers[index]=matcher;}}}
 public ScenarioDescriptor Describe()=>new("interop-reused-Portfolio","1",Wire.Hash(new{patterns,inputs,expected}),ResetLevel.LogicalState,ThreadAffinity.Any,false,"One public reused match; each original fixture occupies 256 rows in a fixed 1024-row portfolio",["baseline","candidate"]);
 public void Prepare(ScenarioContext context){cancel=context.Cancellation;for(int i=0;i<1024;i++)if(matchers[i].IsMatch(inputs[i])!=expected[i]||matchers[i].IsMatch(inputs[i].AsSpan())!=expected[i])throw new Exception("Portfolio oracle mismatch");}
 public void Reset(ResetContext context){checksum=expectedChecksum=0;}
 public long ExecuteBatch(int count){for(int i=0;i<count;i++){if((i&4095)==0)cancel.ThrowIfCancellationRequested();int j=i&1023;checksum+=matchers[j].IsMatch(inputs[j])?1:0;expectedChecksum+=expected[j]?1:0;}return count;}
 public ValidationResult Validate()=>new(checksum==expectedChecksum);public void Cleanup(){}
}
'''
(R/'normal-program.cs').write_text(program)
baseproj=(R/'rig/Rig.csproj').read_text().replace('<UseAppHost>false</UseAppHost>','<UseAppHost>false</UseAppHost><TieredCompilation>false</TieredCompilation>')
for arm in ['baseline','candidate']:
 dst=R/('normal-'+arm);dst.mkdir(exist_ok=True);source=(R/'cross-baseline/src/Tedd.WildcardMatch') if arm=='baseline' else REPO/'src/Tedd.WildcardMatch'
 for src in source.glob('*.cs'):shutil.copy2(src,dst/src.name)
 (dst/'Program.cs').write_text(program);(dst/'Rig.csproj').write_text(baseproj);shutil.copy2(R/'rig/global.json',dst/'global.json')
 p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=dst,capture_output=True,text=True);(R/'evidence'/f'normal-{arm}-build.txt').write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError('Normal build failed '+arm)
print('Normal builds prepared with identical callers and dependency/runtime configuration',flush=True)
