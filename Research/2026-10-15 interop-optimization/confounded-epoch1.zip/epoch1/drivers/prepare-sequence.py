import pathlib,json
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');text=(P/'ordinal-trial.py').read_text(encoding='utf-8')
text=text.replace('trial-ordinal','trial-sequence').replace("'ordinal'","'sequence'").replace('ordinal-','sequence-').replace('ordinal-summary','sequence-summary')
start=text.index("p=rig/'candidate/CompiledSegments.cs'");end=text.index('p=subprocess.run(',start)
change=r'''p=rig/'candidate/ShortPattern.cs';text=p.read_text(encoding='utf-8');text=text.replace('        var packed = CreatePacked(pattern, singleline);','        var sequence = CreateSequence(pattern, singleline);\n        if (sequence != null) return sequence;\n        var packed = CreatePacked(pattern, singleline);');text=text.replace('if (_packedLength != 0) return MatchPacked(input);','if (_packedLength != 0) return _packedLength > 0 ? MatchPacked(input) : MatchSequence(input);');p.write_text(text,encoding='utf-8')
p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text(encoding='utf-8').replace('internal bool IsPacked => _packedLength != 0;','internal bool IsPacked => _packedLength > 0;');p.write_text(text,encoding='utf-8')
(rig/'candidate/ShortPattern.Sequence.cs').write_text(r"""using System;
using System.Runtime.CompilerServices;
namespace Tedd;
internal sealed partial class ShortPattern
{
    private static ShortPattern? CreateSequence(string pattern, bool singleline)
    {
        if (pattern[0] != '*' || pattern[pattern.Length - 1] != '*') return null;
        ulong sequence = 0;
        int count = 0;
        bool star = true;
        foreach (char token in pattern)
        {
            if (token == '*') { star = true; continue; }
            if (!star || token == '?' || token == '\n' || count == 4) return null;
            sequence |= (ulong)token << (16 * count++);
            star = false;
        }
        return count >= 2 ? new ShortPattern(sequence, 0, -count, default, singleline) : null;
    }
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private bool MatchSequence(ReadOnlySpan<char> input)
    {
        if (!_singleline && input.Length > 0 && input[input.Length - 1] == '\n') input = input.Slice(0, input.Length - 1);
        ulong sequence = _packedValue;
        int position = 0;
        for (int i = 0; i < -_packedLength; i++)
        {
            int found = input.Slice(position).IndexOf((char)sequence);
            if (found < 0) return false;
            position += found + 1;
            sequence >>= 16;
        }
        return _singleline || input.IndexOf('\n') < 0;
    }
}
""",encoding='utf-8')
p=rig/'Program.cs';text=p.read_text(encoding='utf-8').replace('"Newline","Diverse"','"Newline","Diverse","GeneralShort"').replace('"Diverse"=>"*a?c*e*",_=>','"Diverse"=>"*a?c*e*","GeneralShort"=>"*a*b*c*",_=>');text=text.replace(' "Diverse"=>Enumerable.Range',r' "GeneralShort"=>["abcdef","abc","def","ac","xaxbxc","abbbc","a\nbc","abcdef\n",new string(\'x\',32)+"abc"],\n "Diverse"=>Enumerable.Range'.replace("\\'","'").replace('],\\n','],\n'));p.write_text(text,encoding='utf-8')
'''
# Use a normal escaped Python literal for the scenario insertion.
change=change[:change.index("p=rig/'Program.cs'")]+"p=rig/'Program.cs';text=p.read_text(encoding='utf-8').replace('\"Newline\",\"Diverse\"','\"Newline\",\"Diverse\",\"GeneralShort\"').replace('\"Diverse\"=>\"*a?c*e*\",_=>','\"Diverse\"=>\"*a?c*e*\",\"GeneralShort\"=>\"*a*b*c*\",_=>')\ntext=text.replace(' \"Diverse\"=>Enumerable.Range', ''' \"GeneralShort\"=>[\"abcdef\",\"abc\",\"def\",\"ac\",\"xaxbxc\",\"abbbc\",\"a\\\\nbc\",\"abcdef\\\\n\",new string('x',32)+\"abc\"],\n \"Diverse\"=>Enumerable.Range''');p.write_text(text,encoding='utf-8')\n"
text=text[:start]+change+text[end:]
a=text.index(" s.call('lab.experiment'");b=text.index(' for shape in',a)
text=text[:a]+" s.call('lab.experiment',{'action':'create_hypothesis','mechanism':'Star-separated sequences of two to four single literal UTF-16 units are subsequence searches. Reuse the existing packed fields with a negative strategy tag; reject unsupported shapes and retain final-LF semantics.','prediction':'Reduce the broad short-pattern cost without affecting packed shapes; six fixed scenarios, ten paired descriptive blocks each.','evidence_ids':[]},'sequence-hypothesis')\n"+text[b:]
text=text.replace("['LongText','Diverse','MultiStar','Dense4096','Dense16384']","['GeneralShort','Literal','Simple','MultiStar','Diverse','LongText']").replace("',100,'","',120,'")
(P/'sequence-trial.py').write_text(text,encoding='utf-8');(P/'jobs/112.json').write_text(json.dumps({'args':[r'C:\Python314\python.exe','-u',str(P/'sequence-trial.py')],'output':'epoch2/evidence/sequence-phase.txt','timeout':1800}))
