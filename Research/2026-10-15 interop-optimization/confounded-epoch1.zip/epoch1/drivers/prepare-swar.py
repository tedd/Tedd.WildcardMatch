import pathlib
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');text=(P/'ordinal-trial.py').read_text(encoding='utf-8')
text=text.replace("trial-ordinal","trial-swar").replace("'ordinal'","'swar'").replace('ordinal-','swar-').replace('ordinal-summary','swar-summary')
start=text.index("p=rig/'candidate/CompiledSegments.cs'");end=text.index("p=subprocess.run(",start)
change=r'''p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text(encoding='utf-8')
text=text.replace('private readonly char _packedTail;','private readonly char _packedTail;\n#if NET10_0_OR_GREATER\n    private readonly ulong _packedTailWord;\n#endif')
text=text.replace('_packedTail = tail;','_packedTail = tail;\n#if NET10_0_OR_GREATER\n        _packedTailWord = (ulong)tail * 0x0001000100010001UL;\n#endif')
start=text.index('#if NET10_0_OR_GREATER',text.index('internal bool MatchPacked'))
end=text.index('#endif',start)+len('#endif')
text=text[:start]+r"""#if NET10_0_OR_GREATER
        if ((uint)(length - 4) < 4)
        {
            ulong a = ReadWord(input, 0), b = ReadWord(input, length - 4);
            ulong last = EqualLanes(b, _packedTailWord);
            int tail;
            if (last != 0) tail = ((63 - BitOperations.LeadingZeroCount(last)) >> 4) + length - 4;
            else
            {
                ulong first = EqualLanes(a, _packedTailWord);
                if (first == 0) return false;
                tail = (63 - BitOperations.LeadingZeroCount(first)) >> 4;
            }
            int bound = tail - _packedLength;
            for (int i = 0; i <= bound; i++)
                if ((ReadWord(input, i) & _packedMask) == _packedValue)
                    return _singleline || (EqualLanes(a, 0x000a000a000a000aUL) | EqualLanes(b, 0x000a000a000a000aUL)) == 0;
            return false;
        }
#endif"""+text[end:]
pos=text.index('    [MethodImpl(MethodImplOptions.NoInlining)]')
text=text[:pos]+r"""#if NET10_0_OR_GREATER
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static ulong EqualLanes(ulong word, ulong value)
    {
        ulong x = word ^ value;
        const ulong low = 0x7fff7fff7fff7fffUL;
        return ~(((x & low) + low) | x | low);
    }
#endif

"""+text[pos:]
p.write_text(text,encoding='utf-8')
'''
text=text[:start]+change+text[end:]
a=text.index(" s.call('lab.experiment'");b=text.index(' for shape in',a)
text=text[:a]+" s.call('lab.experiment',{'action':'create_hypothesis','mechanism':'Replace bounded vector tail lookup with exact 16-bit lane-zero masks in two safe 64-bit words. Precompute repeated tail value; avoid cross-lane borrow false positives.','prediction':'Reduce short-input setup cost and preserve UTF-16/newline semantics. Three scenarios, ten fixed paired descriptive blocks each; no posthoc exclusions.','evidence_ids':[]},'swar-hypothesis')\n"+text[b:]
text=text.replace("['LongText','Diverse','MultiStar','Dense4096','Dense16384']","['MultiStar','Diverse','LongText']")
(P/'swar-trial.py').write_text(text,encoding='utf-8')
