import sys,pathlib,json,subprocess,time,uuid
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');sys.path.insert(0,str(R));from experiment import lab,D,HOST
identity=json.loads((R/'target-initial.txt').read_text().splitlines()[0]);tid=identity['id']
for perm,budget in [('execute_registered_scenario',100),('observe',4)]:
 p=subprocess.run([D,HOST,'grant',str(R/'catalog'),str(identity['process_id']),perm,'600',str(budget)],capture_output=True,text=True)
 (R/'evidence'/('grant-'+perm+'.json')).write_text(p.stdout);print(p.stdout,flush=True)
sc=json.loads((R/'evidence/scenarios-initial.json').read_text())['data']['scenarios'];s=next(s for s in sc if s['id']=='interop-reused-MultiStar')
h=lab('lab.experiment',{'action':'create_hypothesis','mechanism':'Short-pattern bitmap recurrence processes every character; scalar/segment paths may avoid redundant state work.','prediction':'A simpler short-star strategy lowers complete public-call cost without changing string/span and newline results.','evidence_ids':[]},'hypothesis-short-star')
print('hypothesis',json.dumps(h)[:300],flush=True)
plan=lab('lab.experiment',{'action':'create_plan','scenario_id':s['id'],'scenario_version':s['version'],'input_hash':s['input_hash'],'variants':['baseline','candidate'],'blocks':10,'operations_per_run':300000,'warmup_batches':2,'seed':'20261015','profile':'quiet-validation','independent_blocks':False,'confirmatory':False,'maximum_duration_seconds':60,'analysis':{'alpha_family':.05,'family_size':4,'equivalence_lower_ratio':.95,'equivalence_upper_ratio':1.05,'useful_improvement_ratio':.8,'meaningful_regression_ratio':1.05,'minimum_blocks':10}},'plan-baseline-aa')
print('plan',json.dumps(plan)[:600],flush=True)
