import pathlib,sys,json,subprocess,hashlib,zipfile,shutil
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');R=P/'epoch3';O=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch\Research\2026-10-15 interop-optimization');sys.path.insert(0,str(R));from rpc import Session,D,HOST
assessment=json.loads((R/'evidence/adoption-assessment.json').read_text());rows=json.loads((O/'confirmation-results.json').read_text());portfolio=next(x for x in rows if x['scenario']=='interop-reused-Portfolio')
s=Session('final-decision')
try:
 rationale='Source review uses only epoch 3 fresh normal-build confirmation. Useful portfolio and multi-star benefit, all seventeen predefined five-percent noninferiority guards, correct joined sessions and zero measured allocation: '+str(assessment['source_adoption_eligible'])+'. External mean target across all native storage/interop modes: '+str(assessment['all_four_mean_margins_at_least_20_percent'])+'. All individual comparison IDs: '+', '.join(x['comparison_id'] for x in rows)+'. Earlier epochs are retained separately and are not pooled.'
 s.call('lab.experiment',{'action':'record_decision','comparison_id':portfolio['comparison_id'],'decision':'adopt' if assessment['source_adoption_eligible'] else 'defer','rationale':rationale},'final-source-decision')
finally:s.close()
backups={}
for label,root in [('confounded-epoch1',P),('post-restart',P/'epoch2')]:
 p=subprocess.run([D,HOST,'backup',str(root/'catalog')],capture_output=True,text=True)
 (R/'evidence'/('backup-'+label+'.json')).write_text(p.stdout,encoding='utf-8')
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 info=json.loads(p.stdout);path=(root/'catalog'/info['relative_path']).resolve()
 if not path.is_relative_to((root/'catalog').resolve()) or hashlib.sha256(path.read_bytes()).hexdigest()!=info['hash']:raise RuntimeError('Backup verification failed')
 backups[label]=(path,info)

def add_tree(z,folder,prefix,source_only=False):
 if not folder.exists():return
 for p in sorted(folder.rglob('*')):
  if not p.is_file() or {'bin','obj','.git','__pycache__'}.intersection(p.relative_to(folder).parts):continue
  if source_only and p.suffix not in ['.cs','.csproj','.json','.py','.ps1','.cpp','.h','.hpp','.txt']:continue
  z.write(p,prefix+'/'+p.relative_to(folder).as_posix())
def archive(label,roots,catalog_root):
 out=O/(label+'.zip');backup,info=backups[label if label=='confounded-epoch1' else 'post-restart']
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  z.writestr('README.txt',('Confounded timing evidence; not usable for adoption.\n' if label=='confounded-epoch1' else 'Unpooled post-restart evidence. Epoch 2 is the first selected source; epoch 3 contains the final anchor-proof change and both native storage modes.\n')+'Catalog is an official verified SQLite backup. Extract artifacts beside catalog.sqlite to inspect offline. Re-executions require new plans and grants.\n')
  z.write(backup,'catalog/catalog.sqlite');z.writestr('catalog/backup-metadata.json',json.dumps(info,indent=2));add_tree(z,catalog_root/'artifacts','catalog/artifacts')
  for tag,root in roots:
   add_tree(z,root/'evidence',tag+'/evidence')
   for p in sorted(root.glob('*.py')):z.write(p,tag+'/drivers/'+p.name)
   for folder in ['rig','normal-baseline','normal-candidate']:
    add_tree(z,root/folder,tag+'/sources/'+folder,True)
   for trial in sorted(root.glob('trial-*')):
    if trial.is_dir():add_tree(z,trial,tag+'/sources/'+trial.name,True)
   for artifacts in sorted(root.glob('*artifacts')):
    if artifacts.is_dir():add_tree(z,artifacts,tag+'/'+artifacts.name)
   if (root/'final/src').exists():add_tree(z,root/'final/src',tag+'/sources/final/src',True)
  for p in P.glob('*.py'):z.write(p,'parent-drivers/'+p.name)
  for p in (P/'jobs').glob('*.json'):z.write(p,'jobs/'+p.name)
  for name in ['CMakeCache.txt','CMakeFiles/wildcard_native.dir/flags.make','CMakeFiles/wildcard_native.dir/link.txt']:
   p=P/'native/native-build'/name
   if p.exists():z.write(p,'native-build/'+name)
 with zipfile.ZipFile(out) as z:
  if z.testzip():raise RuntimeError('Archive integrity failure')
 return {'file':out.name,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size}
archives=[archive('confounded-epoch1',[('epoch1',P)],P/'catalog'),archive('post-restart',[('epoch2',P/'epoch2'),('epoch3',R)],P/'epoch2/catalog')]
(O/'evidence-archives.json').write_text(json.dumps(archives,indent=2),encoding='utf-8')
for src in ['final-source-decision.json','backup-confounded-epoch1.json','backup-post-restart.json']:shutil.copy2(R/'evidence'/src,O/src)
print(json.dumps({'assessment':assessment,'archives':archives},indent=2),flush=True)
