import pathlib,json,shutil
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');R=P/'epoch2'
for name in ['screening-rpc.jsonl','screening-controller.txt','normal-registration-rpc.jsonl','normal-registration-controller.txt']:
 p=R/'evidence'/name
 if p.exists():shutil.copy2(p,p.with_name(name+'.failed-setup'))
p=R/'screening.py';t=p.read_text(encoding='utf-8').replace(",'state':'planned'",'').replace("'screening');g=grant","'screening2');g=grant").replace("stop-target-screening'","stop-target-screening2'");p.write_text(t,encoding='utf-8')
p=R/'register-normal.py';t=p.read_text(encoding='utf-8').replace('normal-discovery4','normal-discovery5');p.write_text(t,encoding='utf-8')
p=R/'confirm.py';t=p.read_text(encoding='utf-8').replace("['078','081','082']","['078','081','089']");p.write_text(t,encoding='utf-8')
p=R/'details-final.py';t=p.read_text(encoding='utf-8').replace("jobs/083.done","jobs/090.done");p.write_text(t,encoding='utf-8')
p=P/'confirmation-report.py';t=p.read_text(encoding='utf-8').replace("jobs/084.done","jobs/091.done");p.write_text(t,encoding='utf-8')
for n,name,root in [(88,'screening.py',R),(89,'register-normal.py',R),(90,'confirm.py',R),(91,'details-final.py',R),(92,'aggregate-final.py',R),(93,'confirmation-report.py',P)]:
 (P/'jobs'/f'{n:03}.json').write_text(json.dumps({'args':[r'C:\Python314\python.exe','-u',str(root/name)],'cwd':str(R),'env':{'TEMP':str(R/'tmp'),'TMP':str(R/'tmp')},'output':'epoch2/evidence/recovered-phase-'+name+'.txt','timeout':10800}))
p=P/'make-ledger.py';t=p.read_text(encoding='utf-8');t=t.replace("'Ratios are candidate/control", "'All timing ratios and historical dispositions below belong to confounded epoch 1 and cannot support adoption or rejection. Epoch 2 independently checks the provisional selected source.','', 'Ratios are candidate/control");t=t.replace("write_text('\\n'.join(lines)+'\\n')","write_text('\\n'.join(lines)+'\\n',encoding='utf-8')");p.write_text(t,encoding='utf-8')
