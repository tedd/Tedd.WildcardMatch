import sys,pathlib,json,uuid,time
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');sys.path.insert(0,str(R));from experiment import lab
p=json.loads((R/'evidence/plan-baseline-aa.json').read_text())['data'];i=json.loads((R/'target-initial.txt').read_text().splitlines()[0]);g=json.loads((R/'evidence/grant-execute_registered_scenario.json').read_text())
x=lab('lab.run',{'action':'start','target_id':i['id'],'expected_target_epoch':'0','plan_id':p['id'],'grant_id':g['id'],'idempotency_key':'baseline-aa-20261015'},'start-baseline-aa');print(json.dumps(x),flush=True)
