import subprocess,json,pathlib
root=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization')
p=subprocess.Popen([r'D:\Workspaces\AI\dotnetlab-runtime\dotnet.exe',r'D:\Workspaces\AI\dotnetlab-implementation\bin\DotNetLab.Host\Release\net10.0\DotNetLab.Host.dll','serve',str(root/'catalog')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
def send(x): p.stdin.write(json.dumps(x)+'\n');p.stdin.flush()
def receive(i):
 while True:
  line=p.stdout.readline()
  if not line: raise RuntimeError(p.stderr.read())
  msg=json.loads(line)
  if msg.get('id')==i:return msg
send({'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'wildcard-optimization','version':'1'}}})
(root/'evidence/initialize.json').write_text(json.dumps(receive(1),indent=2))
send({'jsonrpc':'2.0','method':'notifications/initialized'})
send({'jsonrpc':'2.0','id':2,'method':'tools/list','params':{}})
(root/'evidence/schemas-current.json').write_text(json.dumps(receive(2),indent=2))
p.stdin.close();p.wait(timeout=30)
print('Advertised schemas retained')
