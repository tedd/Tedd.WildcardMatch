import sys,pathlib,json,statistics
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');sys.path.insert(0,str(R));from rpc import *
s=Session('screen-detail')
try:
 for name in ['greedy','early','segments','packed','packedlate','lfscan','packedwords','packedtail','knownanchor']:
  f=R/'evidence'/f'{name}-summary.json'
  if not f.exists():continue
  summary=json.loads(f.read_text());out=[]
  for row in summary:
   e=s.call('lab.inspect',{'action':'record','id':row['execution_id']},name+'-'+row['shape']+'-execution-detail');ex=json.loads(e['json']);costs={'baseline':[],'candidate':[]}
   for rid in ex['run_ids']:
    data=s.call('lab.inspect',{'action':'record','id':rid},'run-'+rid);rec=json.loads(data['json']);m=rec['measurement'];costs[m['variant']].append(float(m['nanoseconds_per_operation']))
   result={'trial':name,'shape':row['shape'],'means':{a:statistics.mean(v) for a,v in costs.items()},'all_samples':costs};out.append(result);print(json.dumps(result)[:250],flush=True)
  (R/'evidence'/f'{name}-costs.json').write_text(json.dumps(out,indent=2))
finally:s.close()
