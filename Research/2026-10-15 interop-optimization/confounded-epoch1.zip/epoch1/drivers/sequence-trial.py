import pathlib,sys,shutil,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch2');REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch');sys.path.insert(0,str(R));from rpc import *
rig=R/'trial-sequence';shutil.copytree(R/'rig',rig,ignore=shutil.ignore_patterns('bin','obj'),dirs_exist_ok=True)
for arm,ns in [('baseline','Control'),('candidate','Tedd')]:
 folder=rig/arm
 for p in folder.glob('*.cs'):p.unlink()
 for p in (REPO/'src/Tedd.WildcardMatch').glob('*.cs'):
  text=p.read_text(encoding='utf-8-sig').replace('namespace Tedd;','namespace '+ns+';')
  if arm=='baseline':text=text.replace('[assembly: CLSCompliant(true)]','')
  (folder/p.name).write_text(text,encoding='utf-8')
p=rig/'candidate/ShortPattern.cs';text=p.read_text(encoding='utf-8');text=text.replace('        var packed = CreatePacked(pattern, singleline);','        var sequence = CreateSequence(pattern, singleline);\n        if (sequence != null) return sequence;\n        var packed = CreatePacked(pattern, singleline);');text=text.replace('if (_packedLength != 0) return MatchPacked(input);','if (_packedLength != 0) return _packedLength > 0 ? MatchPacked(input) : MatchSequence(input);');p.write_text(text,encoding='utf-8')
p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text(encoding='utf-8').replace('internal bool IsPacked => _packedLength != 0;','internal bool IsPacked => _packedLength > 0;');p.write_text(text,encoding='utf-8')
(rig/'candidate/ShortPattern.Sequence.cs').write_text(r"""using System;
using System.Runtime.CompilerServices;
namespace Tedd;
internal sealed partial class ShortPattern
{
    private static ShortPattern? CreateSequence(string pattern, bool singleline)
    {
        if (pattern[0] != '*' || pattern[pattern.Length - 1] != '*') return null;
        ulong sequence = 0;
        int count = 0;
        bool star = true;
        foreach (char token in pattern)
        {
            if (token == '*') { star = true; continue; }
            if (!star || token == '?' || token == '\n' || count == 4) return null;
            sequence |= (ulong)token << (16 * count++);
            star = false;
        }
        return count >= 2 ? new ShortPattern(sequence, 0, -count, default, singleline) : null;
    }
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private bool MatchSequence(ReadOnlySpan<char> input)
    {
        if (!_singleline && input.Length > 0 && input[input.Length - 1] == '\n') input = input.Slice(0, input.Length - 1);
        ulong sequence = _packedValue;
        int position = 0;
        for (int i = 0; i < -_packedLength; i++)
        {
            int found = input.Slice(position).IndexOf((char)sequence);
            if (found < 0) return false;
            position += found + 1;
            sequence >>= 16;
        }
        return _singleline || input.IndexOf('\n') < 0;
    }
}
""",encoding='utf-8')
p=rig/'Program.cs';text=p.read_text(encoding='utf-8').replace('"Newline","Diverse"','"Newline","Diverse","GeneralShort"').replace('"Diverse"=>"*a?c*e*",_=>','"Diverse"=>"*a?c*e*","GeneralShort"=>"*a*b*c*",_=>')
text=text.replace(' "Diverse"=>Enumerable.Range', ''' "GeneralShort"=>["abcdef","abc","def","ac","xaxbxc","abbbc","a\\nbc","abcdef\\n",new string('x',32)+"abc"],
 "Diverse"=>Enumerable.Range''');p.write_text(text,encoding='utf-8')
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence/sequence-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Ordinal trial build failed')
i=launch(rig,'sequence');g=grant(i,'execute_registered_scenario',120,'sequence',1200);s=Session('sequence');summary=[]
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'sequence-scenarios')['scenarios']
 s.call('lab.discover',{'action':'compatibility','target_id':i['id']},'sequence-compatibility')
 s.call('lab.experiment',{'action':'create_hypothesis','mechanism':'Star-separated sequences of two to four single literal UTF-16 units are subsequence searches. Reuse the existing packed fields with a negative strategy tag; reject unsupported shapes and retain final-LF semantics.','prediction':'Reduce the broad short-pattern cost without affecting packed shapes; six fixed scenarios, ten paired descriptive blocks each.','evidence_ids':[]},'sequence-hypothesis')
 for shape in ['GeneralShort','Literal','Simple','MultiStar','Diverse','LongText']:
  desc=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,desc,'sequence-'+shape,512 if shape.startswith('Dense') else 30000 if shape=='LongText' else 300000)
  ex,c=execute(s,i,p,g,'sequence-'+shape);summary.append({'shape':shape,'execution_id':ex,'comparison':c});(R/'evidence/sequence-summary.json').write_text(json.dumps(summary,indent=2))
finally:s.close();(R/'stop-target-ordinal').touch()
