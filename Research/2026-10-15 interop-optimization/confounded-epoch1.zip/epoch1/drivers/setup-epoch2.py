import pathlib,shutil,json
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');R=P/'epoch2';R.mkdir(exist_ok=True);(R/'evidence').mkdir(exist_ok=True);(R/'tmp').mkdir(exist_ok=True)
for name in ['rpc.py','experiment.py','validate-final.py','prepare-normal.py','register-normal.py','details-final.py','aggregate-final.py']:
 text=(P/name).read_text().replace(str(P),str(R))
 if name=='register-normal.py':
  start=text.index(' exploratory=[]');end=text.index(' shapes=',start)
  text=text[:start]+" exploratory=[x['execution_id'] for x in json.loads((R/'evidence/screening-summary.json').read_text())]\n"+text[end:]
  text=text.replace('  exp=', "  if not shape.startswith('Dense') and shape != 'Newline':ops *= 10\n  exp=")
 if name=='details-final.py':text=text.replace("(R/'jobs/072.done')","(R.parent/'jobs/083.done')")
 if name=='aggregate-final.py':text=text.replace("(R/'jobs/071.done')","(R.parent/'jobs/079.done')")
 (R/name).write_text(text)
shutil.copytree(P/'rig',R/'rig',ignore=shutil.ignore_patterns('bin','obj'),dirs_exist_ok=True)
for path in pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch\src\Tedd.WildcardMatch').glob('*.cs'):shutil.copy2(path,R/'rig/candidate'/path.name)
shutil.copytree(P/'cross-baseline/src/Tedd.WildcardMatch',R/'cross-baseline/src/Tedd.WildcardMatch',ignore=shutil.ignore_patterns('bin','obj'),dirs_exist_ok=True)
(R/'native/native-build').mkdir(parents=True,exist_ok=True)
for path in (P/'native/native-build').iterdir():
 if path.is_file() and (path.suffix in ['.dll','.json','.txt']):shutil.copy2(path,R/'native/native-build'/path.name)
from subprocess import run
D=r'D:\Workspaces\AI\dotnetlab-runtime\dotnet.exe';HOST=r'D:\Workspaces\AI\dotnetlab-implementation\bin\DotNetLab.Host\Release\net10.0\DotNetLab.Host.dll'
p=run([D,HOST,'init',str(R/'catalog')],capture_output=True,text=True);(R/'evidence/catalog-init.json').write_text(p.stdout)
if p.returncode:raise RuntimeError(p.stdout+p.stderr)
screen=r'''
import pathlib,sys,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch2');sys.path.insert(0,str(R));from rpc import *
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=R/'rig',capture_output=True,text=True);(R/'evidence/screening-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Screening build failed')
i=launch(R/'rig','screening');g=grant(i,'execute_registered_scenario',160,'screening',1200);s=Session('screening');summary=[]
try:
 s.rpc('tools/list',{})
 s.call('lab.discover',{'action':'workspace'},'workspace')
 s.call('lab.discover',{'action':'profiles'},'profiles')
 s.call('lab.discover',{'action':'compatibility','target_id':i['id']},'screening-compatibility')
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'screening-scenarios')['scenarios']
 for shape in ['Literal','Simple','MultiStar','LongText','Diverse','Dense4096','Dense16384','Newline']:
  desc=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,desc,'screening-'+shape,512 if shape.startswith('Dense') else 1000 if shape=='Newline' else 30000 if shape=='LongText' else 300000)
  ex,c=execute(s,i,p,g,'screening-'+shape);summary.append({'shape':shape,'execution_id':ex,'comparison':c});(R/'evidence/screening-summary.json').write_text(json.dumps(summary,indent=2))
finally:s.close();(R/'stop-target-screening').touch()
'''
(R/'screening.py').write_text(screen)
bench=(P/'benchmark-final.py').read_text().replace(str(P),str(R));start=bench.index("for n in [");end=bench.index('frozen=',start);bench=bench[:start]+"if json.loads((R.parent/'jobs/078.done').read_text()).get('exit_code')!=0:raise RuntimeError('Epoch 2 validation incomplete')\n"+bench[end:];(R/'benchmark-final.py').write_text(bench)
confirm=(P/'confirm.py').read_text().replace(str(P),str(R)).replace(",'include_objectives':True",'');start=confirm.index("for n in [");end=confirm.index('plans=',start);confirm=confirm[:start]+"for n in ['078','081','082']:\n if json.loads((R.parent/'jobs'/f'{n}.done').read_text()).get('exit_code')!=0:raise RuntimeError('Epoch 2 prerequisite failed '+n)\n"+confirm[end:];(R/'confirm.py').write_text(confirm)
for num,name in [(78,'validate-final.py'),(79,'benchmark-final.py'),(80,'screening.py'),(81,'prepare-normal.py'),(82,'register-normal.py'),(83,'confirm.py'),(84,'details-final.py'),(86,'aggregate-final.py')]:
 job={'args':[r'C:\Python314\python.exe','-u',str(R/name)],'cwd':str(R),'env':{'TEMP':str(R/'tmp'),'TMP':str(R/'tmp')},'output':'epoch2/evidence/phase-'+name+'.txt','timeout':10800}
 (P/'jobs'/f'{num:03}.json').write_text(json.dumps(job))
print('Epoch 2 fresh catalog and serial measurement jobs prepared',flush=True)
