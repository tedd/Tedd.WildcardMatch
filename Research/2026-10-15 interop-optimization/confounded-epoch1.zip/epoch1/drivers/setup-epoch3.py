import pathlib,json,shutil
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');S=P/'epoch2';R=P/'epoch3';R.mkdir(exist_ok=True);(R/'evidence').mkdir(exist_ok=True);(R/'tmp').mkdir(exist_ok=True)
if json.loads((P/'jobs/100.done').read_text()).get('exit_code')!=0:raise RuntimeError('Shared native rebuild failed')
for root in [P,S]:
 for path in root.glob('target-*.txt'):(root/('stop-target-'+path.stem[len('target-'):])).touch()
for name in ['rpc.py','validate-final.py','prepare-normal.py','register-normal.py','confirm.py','details-final.py','aggregate-final.py']:
 text=(S/name).read_text(encoding='utf-8').replace(str(S),str(R)).replace("str(R/'catalog')","str(R.parent/'epoch2/catalog')")
 if name=='validate-final.py':text=text.replace('FullyQualifiedName~ShortStarBoundaryTest','FullyQualifiedName~ShortStarBoundaryTest|FullyQualifiedName~SegmentAnchorVerificationTest')
 if name=='register-normal.py':
  text=text.replace("exploratory=[x['execution_id'] for x in json.loads((R/'evidence/screening-summary.json').read_text())]","exploratory=[x['execution_id'] for file in ['screening-summary.json','anchor-summary.json'] for x in json.loads((R.parent/'epoch2/evidence'/file).read_text())]")
  text=text.replace('Prepared packed short-star matching with bounded reads and selected managed strategy','Packed short-star matching and proof-based anchor verification')
  text=text.replace('A completed literal anchor is not re-compared after IndexOf.','After IndexOf proves a literal anchor, only positions outside it are rechecked; prefix/suffix comparisons without that proof remain complete.')
 if name=='confirm.py':text=text.replace("['078','081','089']","['102','103','104']")
 if name=='details-final.py':text=text.replace('jobs/090.done','jobs/105.done')
 if name=='aggregate-final.py':
  text=text.replace('jobs/079.done','jobs/106.done')
  text=text.replace("case=re.search(r'Case: (.*)\\)$',x['FullName']).group(1)","case=re.search(r'Case: ([^,)]+)',x['FullName']).group(1)")
  old="mode='managed' if group=='Matching' else 'batch' if group=='NativeMatching' else x['Method'].lower()"
  new=old+";mode += '' if group=='Matching' else '_shared' if re.search(r'ShareInputs:\\s*True\\b',x['FullName'],re.I) else '_cloned'"
  text=text.replace(old,new)
 (R/name).write_text(text,encoding='utf-8')
(R/'rig').mkdir(exist_ok=True)
for name in ['Rig.csproj','Program.cs','global.json']:shutil.copy2(S/'rig'/name,R/'rig'/name)
shutil.copytree(S/'cross-baseline/src/Tedd.WildcardMatch',R/'cross-baseline/src/Tedd.WildcardMatch',ignore=shutil.ignore_patterns('bin','obj'),dirs_exist_ok=True)
(R/'native/native-build').mkdir(parents=True,exist_ok=True);shutil.copy2(P/'native/native-build/wildcard_native.dll',R/'native/native-build/wildcard_native.dll');shutil.copy2(P/'native/native-sources.json',R/'native/native-sources.json')
bench=(S/'benchmark-final.py').read_text(encoding='utf-8').replace(str(S),str(R)).replace('jobs/078.done','jobs/102.done').replace("('NativeMatching',16)","('NativeMatching',32)").replace("('Interop',18)","('Interop',36)").replace('All 76 benchmark cases completed','All 110 benchmark cases completed');(R/'benchmark-final.py').write_text(bench,encoding='utf-8')
report=(P/'confirmation-report.py').read_text(encoding='utf-8').replace(str(S),str(R)).replace('jobs/091.done','jobs/107.done').replace('Epoch 2 only; all epoch 1 timings are excluded.','Epoch 3 source confirmation only; earlier epochs are not pooled.');(R/'confirmation-report.py').write_text(report,encoding='utf-8')
for n,name in [(102,'validate-final.py'),(103,'prepare-normal.py'),(104,'register-normal.py'),(105,'confirm.py'),(106,'benchmark-final.py'),(107,'details-final.py'),(108,'aggregate-final.py'),(109,'confirmation-report.py')]:
 (P/'jobs'/f'{n:03}.json').write_text(json.dumps({'args':[r'C:\Python314\python.exe','-u',str(R/name)],'cwd':str(R),'env':{'TEMP':str(R/'tmp'),'TMP':str(R/'tmp')},'output':'epoch3/evidence/phase-'+name+'.txt','timeout':10800}))
print('Epoch 3 frozen-source pipeline prepared; shared post-restart catalog retained',flush=True)
