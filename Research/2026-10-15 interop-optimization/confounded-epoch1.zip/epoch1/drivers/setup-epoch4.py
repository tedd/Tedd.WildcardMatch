import pathlib,json,shutil
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');S=P/'epoch3';R=P/'epoch4';R.mkdir(exist_ok=True);(R/'evidence').mkdir(exist_ok=True);(R/'tmp').mkdir(exist_ok=True)
for name in ['rpc.py','validate-final.py','prepare-normal.py','register-normal.py','confirm.py','details-final.py','aggregate-final.py','benchmark-final.py','confirmation-report.py']:
 text=(S/name).read_text(encoding='utf-8').replace(str(S),str(R))
 if name=='prepare-normal.py':
  text=text.replace("(R/'normal-program.cs').write_text(program)","program=program.replace('Process.GetCurrentProcess().ProcessorAffinity = new IntPtr(1L << 30);','Process.GetCurrentProcess().ProcessorAffinity = new IntPtr(1L << 30);\\nProcess.GetCurrentProcess().PriorityClass = ProcessPriorityClass.High;')\n(R/'normal-program.cs').write_text(program)")
 if name=='register-normal.py':
  text=text.replace("['screening-summary.json','anchor-summary.json']","['screening-summary.json','anchor-summary.json','nolf-summary.json']").replace("  exp=","  if shape == 'GeneralShort':ops *= 10\n  exp=").replace("'blocks':10","'blocks':20").replace("'minimum_blocks':10","'minimum_blocks':20").replace("'1800','20'","'3600','40'")
  text=text.replace('Packed short-star matching and proof-based anchor verification','Packed short-star, proof-based anchor verification and deferred bitmap LF validation')
  text=text.replace('All tests and independent corpus checks pass.','For default bitmap plans without literal LF, final-LF trimming and deferred interior-LF rejection preserve the original contract. All tests and independent corpus checks pass. Both identical callers use High process priority and CPU 30.')
 if name=='confirm.py':text=text.replace("['102','103','104']","['115','116','117']")
 if name=='details-final.py':text=text.replace('jobs/105.done','jobs/118.done')
 if name=='benchmark-final.py':text=text.replace('jobs/102.done','jobs/115.done')
 if name=='aggregate-final.py':text=text.replace('jobs/106.done','jobs/119.done')
 if name=='confirmation-report.py':
  text=text.replace('jobs/107.done','jobs/120.done').replace('Epoch 3 source confirmation only','Epoch 4 source confirmation only').replace('Ten paired fresh-process blocks','Twenty paired fresh-process blocks').replace('CPU 30, .NET','High process priority, CPU 30, .NET')
 (R/name).write_text(text,encoding='utf-8')
(R/'rig').mkdir(exist_ok=True)
for name in ['Rig.csproj','Program.cs','global.json']:shutil.copy2(S/'rig'/name,R/'rig'/name)
shutil.copytree(S/'cross-baseline/src/Tedd.WildcardMatch',R/'cross-baseline/src/Tedd.WildcardMatch',ignore=shutil.ignore_patterns('bin','obj'),dirs_exist_ok=True)
(R/'native/native-build').mkdir(parents=True,exist_ok=True);shutil.copy2(S/'native/native-build/wildcard_native.dll',R/'native/native-build/wildcard_native.dll');shutil.copy2(S/'native/native-sources.json',R/'native/native-sources.json')
for name in ['assess-final.py','write-final-report.py']:
 text=(P/name).read_text(encoding='utf-8').replace(str(S),str(R))
 if name=='assess-final.py':
  text=text.replace('[105,106,107,108,109]','[118,119,120,121,122]').replace("'minimum':'Not selected: no useful caller benefit.'","'minimum':'Not selected: no useful caller benefit.','sequence':'Not selected: no useful broad-pattern benefit.','nolf':'Selected for new confirmation: defer LF validation in the proven default regime.'")
 if name=='write-final-report.py':
  text=text.replace('jobs/110.done','jobs/123.done').replace('Final source epoch 3','Final source epoch 4').replace('fresh normal-build portfolio ratio','fresh normal-build portfolio ratio').replace('747 tests pass: 248 on .NET 8, 248 on .NET 10, 251 on .NET 11. Six','753 tests pass: 250 on .NET 8, 250 on .NET 10, 253 on .NET 11. Eight').replace('Ten randomized paired fresh-process blocks','Twenty randomized paired fresh-process blocks').replace('dense anchors 512; newline 1,000.','dense anchors 512; newline 1,000; GeneralShort 30,000,000. Both normal-build arms use High process priority.').replace('including rejected ordinal-search, scalar-mask, dispatch-order and minimum-length alternatives','including rejected ordinal-search, scalar-mask, dispatch-order, minimum-length and subsequence alternatives')
  text=text.replace("'- A successful literal-anchor search", "'- Default non-Singleline bitmap plans without literal LF defer interior-LF rejection until acceptance, outside the recurrence.', '- A successful literal-anchor search")
 (R/name).write_text(text,encoding='utf-8')
for n,name in [(115,'validate-final.py'),(116,'prepare-normal.py'),(117,'register-normal.py'),(118,'confirm.py'),(119,'benchmark-final.py'),(120,'details-final.py'),(121,'aggregate-final.py'),(122,'confirmation-report.py'),(123,'assess-final.py'),(124,'write-final-report.py')]:
 (P/'jobs'/f'{n:03}.json').write_text(json.dumps({'args':[r'C:\Python314\python.exe','-u',str(R/name)],'cwd':str(R),'env':{'TEMP':str(R/'tmp'),'TMP':str(R/'tmp')},'output':'epoch4/evidence/phase-'+name+'.txt','timeout':10800}))
print('Source epoch 4: twenty paired blocks, High priority, longer GeneralShort batches; earlier plans retained',flush=True)
