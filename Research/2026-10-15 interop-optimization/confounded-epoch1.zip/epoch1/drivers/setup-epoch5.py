import pathlib,json,shutil
P=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');S=P/'epoch4';R=P/'epoch5';R.mkdir(exist_ok=True);(R/'evidence').mkdir(exist_ok=True);(R/'tmp').mkdir(exist_ok=True)
program=(S/'normal-program.cs').read_text(encoding='utf-8')
program=program.replace('readonly Tedd.WildcardMatch candidate;readonly Tedd.WildcardMatch control;','readonly Func<string,bool> match;')
program=program.replace('expected=inputs.Select(s=>Oracle(s,pattern)).ToArray();candidate=new(pattern);control=new(pattern);','expected=inputs.Select(s=>Oracle(s,pattern)).ToArray();\n if(reuse){var matcher=new Tedd.WildcardMatch(pattern);match=matcher.IsMatch;}else match=input=>Tedd.WildcardMatch.IsMatch(input,pattern);')
a=program.index(' public void Prepare(ScenarioContext context)');b=program.index(' public void Reset(',a)
program=program[:a]+' public void Prepare(ScenarioContext context){cancel=context.Cancellation;for(int i=0;i<inputs.Length;i++)if(match(inputs[i])!=expected[i])throw new Exception("Delegate oracle mismatch");}\n'+program[b:]
a=program.index(' public long ExecuteBatch(int count)');b=program.index(' public ValidationResult Validate()',a)
program=program[:a]+''' public long ExecuteBatch(int count){for(int i=0;i<count;i++){if((i&4095)==0)cancel.ThrowIfCancellationRequested();int j=i%inputs.Length;checksum+=match(inputs[j])?1:0;expectedChecksum+=expected[j]?1:0;}return count;}
'''+program[b:]
program=program.replace('readonly Tedd.WildcardMatch[] matchers=new Tedd.WildcardMatch[1024]','readonly Func<string,bool>[] matchers=new Func<string,bool>[1024]')
program=program.replace('var matcher=new Tedd.WildcardMatch(patterns[k]);for','var matcher=new Tedd.WildcardMatch(patterns[k]);Func<string,bool> match=matcher.IsMatch;for').replace('matchers[index]=matcher;','matchers[index]=match;').replace('matchers[i].IsMatch(inputs[i])!=expected[i]||matchers[i].IsMatch(inputs[i].AsSpan())!=expected[i]','matchers[i](inputs[i])!=expected[i]').replace('matchers[j].IsMatch(inputs[j])','matchers[j](inputs[j])')
program=program.replace(',"1",Wire.Hash',',"2",Wire.Hash').replace('One public direct match, corpus cycled; checksum observable','One selected public API call through a prepared delegate; corpus cycled; checksum observable').replace('One public reused match; each original fixture','One public reused match through a prepared delegate; each original fixture')
(R/'normal-program.cs').write_text(program,encoding='utf-8')
prepare=r'''
import pathlib,shutil,subprocess
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch5');P=R.parent;S=P/'epoch4';REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch');program=(R/'normal-program.cs').read_text(encoding='utf-8')
for arm in ['baseline','candidate']:
 dst=R/('normal-'+arm);dst.mkdir(exist_ok=True);source=P/'epoch2/cross-baseline/src/Tedd.WildcardMatch' if arm=='baseline' else REPO/'src/Tedd.WildcardMatch'
 for src in source.glob('*.cs'):shutil.copy2(src,dst/src.name)
 (dst/'Program.cs').write_text(program,encoding='utf-8');shutil.copy2(S/('normal-'+arm)/'Rig.csproj',dst/'Rig.csproj');shutil.copy2(S/('normal-'+arm)/'global.json',dst/'global.json')
 p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=dst,capture_output=True,text=True);(R/'evidence'/f'normal-{arm}-build.txt').write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError('Delegate-caller build failed '+arm)
print('Identical selected-API delegate callers built',flush=True)
'''
(R/'prepare-normal.py').write_text(prepare,encoding='utf-8')
for name in ['rpc.py','register-normal.py','confirm.py','details-final.py','confirmation-report.py','assess-final.py','write-final-report.py','preserve-final.py']:
 text=(S/name).read_text(encoding='utf-8').replace(str(S),str(R)).replace("R=P/'epoch4'","R=P/'epoch5'")
 if name=='register-normal.py':text=text.replace('newly frozen candidate','frozen candidate').replace('Both identical callers use High process priority and CPU 30.','Both identical callers use High process priority and CPU 30. Delegate dispatch matches the external comparative caller; the unselected API has no timed branch or preparatory invocation. Production source is unchanged from epoch 4.')
 if name=='confirm.py':text=text.replace("['115','116','117']","['115','128','129']")
 if name=='details-final.py':text=text.replace('jobs/118.done','jobs/130.done').replace("assembly=R/'final/", "assembly=R.parent/'epoch4/final/").replace("cwd=R/'final'","cwd=R.parent/'epoch4/final'")
 if name=='confirmation-report.py':text=text.replace('jobs/120.done','jobs/131.done').replace('Epoch 4 source confirmation only','Epoch 5 delegate-caller confirmation only').replace('Means include this scenario caller','Means include the representative delegate caller')
 if name=='assess-final.py':text=text.replace('[118,119,120,121,122]','[130,131,132]').replace("R/'final-artifacts/results'","R.parent/'epoch4/final-artifacts/results'")
 if name=='write-final-report.py':text=text.replace('jobs/125.done','jobs/133.done').replace('Final source epoch 4','Final production source epoch 4; representative caller confirmation epoch 5')
 if name=='preserve-final.py':text=text.replace("('epoch4',R)","('epoch4',P/'epoch4'),('epoch5',R)")
 (R/name).write_text(text,encoding='utf-8')
shutil.copy2(S/'evidence/source-freeze.json',R/'evidence/source-freeze.json')
for n,name in [(128,'prepare-normal.py'),(129,'register-normal.py'),(130,'confirm.py'),(131,'details-final.py'),(132,'confirmation-report.py'),(133,'assess-final.py'),(134,'write-final-report.py')]:
 (P/'jobs'/f'{n:03}.json').write_text(json.dumps({'args':[r'C:\Python314\python.exe','-u',str(R/name)],'cwd':str(R),'env':{'TEMP':str(R/'tmp'),'TMP':str(R/'tmp')},'output':'epoch5/evidence/phase-'+name+'.txt','timeout':10800}))
print('Representative caller validation frozen; production and external benchmark source unchanged',flush=True)
