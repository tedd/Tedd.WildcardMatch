import pathlib,sys,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');sys.path.insert(0,str(R));from experiment import lab
x=lab('lab.run',{'action':'status','operation_id':'op-2afffa60c0424afe85ac0d80879f4c9b'},'status-baseline-aa-2');print(json.dumps(x),flush=True)
