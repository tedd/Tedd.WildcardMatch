import pathlib,sys,shutil,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch2');REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch');sys.path.insert(0,str(R));from rpc import *
rig=R/'trial-swar';shutil.copytree(R/'rig',rig,ignore=shutil.ignore_patterns('bin','obj'),dirs_exist_ok=True)
for arm,ns in [('baseline','Control'),('candidate','Tedd')]:
 folder=rig/arm
 for p in folder.glob('*.cs'):p.unlink()
 for p in (REPO/'src/Tedd.WildcardMatch').glob('*.cs'):
  text=p.read_text(encoding='utf-8-sig').replace('namespace Tedd;','namespace '+ns+';')
  if arm=='baseline':text=text.replace('[assembly: CLSCompliant(true)]','')
  (folder/p.name).write_text(text,encoding='utf-8')
p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text(encoding='utf-8')
text=text.replace('private readonly char _packedTail;','private readonly char _packedTail;\n#if NET10_0_OR_GREATER\n    private readonly ulong _packedTailWord;\n#endif')
text=text.replace('_packedTail = tail;','_packedTail = tail;\n#if NET10_0_OR_GREATER\n        _packedTailWord = (ulong)tail * 0x0001000100010001UL;\n#endif')
start=text.index('#if NET10_0_OR_GREATER',text.index('internal bool MatchPacked'))
end=text.index('#endif',start)+len('#endif')
text=text[:start]+r"""#if NET10_0_OR_GREATER
        if ((uint)(length - 4) < 4)
        {
            ulong a = ReadWord(input, 0), b = ReadWord(input, length - 4);
            ulong last = EqualLanes(b, _packedTailWord);
            int tail;
            if (last != 0) tail = ((63 - BitOperations.LeadingZeroCount(last)) >> 4) + length - 4;
            else
            {
                ulong first = EqualLanes(a, _packedTailWord);
                if (first == 0) return false;
                tail = (63 - BitOperations.LeadingZeroCount(first)) >> 4;
            }
            int bound = tail - _packedLength;
            for (int i = 0; i <= bound; i++)
                if ((ReadWord(input, i) & _packedMask) == _packedValue)
                    return _singleline || (EqualLanes(a, 0x000a000a000a000aUL) | EqualLanes(b, 0x000a000a000a000aUL)) == 0;
            return false;
        }
#endif"""+text[end:]
pos=text.index('    [MethodImpl(MethodImplOptions.NoInlining)]')
text=text[:pos]+r"""#if NET10_0_OR_GREATER
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static ulong EqualLanes(ulong word, ulong value)
    {
        ulong x = word ^ value;
        const ulong low = 0x7fff7fff7fff7fffUL;
        return ~(((x & low) + low) | x | low);
    }
#endif

"""+text[pos:]
p.write_text(text,encoding='utf-8')
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence/swar-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Ordinal trial build failed')
i=launch(rig,'swar');g=grant(i,'execute_registered_scenario',100,'swar',1200);s=Session('swar');summary=[]
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'swar-scenarios')['scenarios']
 s.call('lab.discover',{'action':'compatibility','target_id':i['id']},'swar-compatibility')
 s.call('lab.experiment',{'action':'create_hypothesis','mechanism':'Replace bounded vector tail lookup with exact 16-bit lane-zero masks in two safe 64-bit words. Precompute repeated tail value; avoid cross-lane borrow false positives.','prediction':'Reduce short-input setup cost and preserve UTF-16/newline semantics. Three scenarios, ten fixed paired descriptive blocks each; no posthoc exclusions.','evidence_ids':[]},'swar-hypothesis')
 for shape in ['MultiStar','Diverse','LongText']:
  desc=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,desc,'swar-'+shape,512 if shape.startswith('Dense') else 30000 if shape=='LongText' else 300000)
  ex,c=execute(s,i,p,g,'swar-'+shape);summary.append({'shape':shape,'execution_id':ex,'comparison':c});(R/'evidence/swar-summary.json').write_text(json.dumps(summary,indent=2))
finally:s.close();(R/'stop-target-ordinal').touch()
