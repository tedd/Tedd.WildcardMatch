import pathlib,shutil,sys,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');rig=R/'trial-taildispatch';shutil.copytree(R/'trial-nopin',rig,dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','obj'))
p=rig/'candidate/WildcardMatch.cs';text=p.read_text().replace('public class WildcardMatch','public unsafe class WildcardMatch').replace('private readonly FixedPattern? _fixed;','private readonly delegate* managed<WildcardMatch, string, bool> _stringMatch;\n    private readonly FixedPattern? _fixed;')
needle='    }\n\n    /// <summary>Matches using call-local state;'
text=text.replace(needle,'        _stringMatch = !_fast ? &MatchSlowString : _literal ? &MatchLiteralString : _fixed != null ? &MatchFixedString : _short != null ? (_short.IsPacked ? &MatchPackedString : &MatchShortString) : _segments != null ? &MatchSegmentsString : &MatchGeneralString;\n    }\n\n    /// <summary>Matches using call-local state;')
text=text.replace('if (_fast) return MatchFast(input.AsSpan());\n        return WildcardEngine.IsMatch(input, _matchPattern, _options, _caseBehavior, _literal, _timeout, Wildcard, _prefix, _suffix, _leadingQuestions);','return _stringMatch(this, input);')
at=text.index('    /// <summary>Matches a borrowed input slice')
text=text[:at]+r'''    private static bool MatchLiteralString(WildcardMatch matcher, string input) => DefaultWildcardEngine.IsMatch(input.AsSpan(), matcher._matchPattern.AsSpan(), false, true);
    private static bool MatchFixedString(WildcardMatch matcher, string input) => matcher._fixed!.IsMatch(input.AsSpan());
    private static bool MatchPackedString(WildcardMatch matcher, string input) => input.Length <= 32 ? matcher._short!.MatchPacked(input.AsSpan()) : matcher._segments!.IsMatch(input.AsSpan());
    private static bool MatchShortString(WildcardMatch matcher, string input) => input.Length <= 32 ? matcher._short!.IsMatch(input.AsSpan()) : matcher.MatchFast(input.AsSpan());
    private static bool MatchSegmentsString(WildcardMatch matcher, string input) => matcher._segments!.IsMatch(input.AsSpan());
    private static bool MatchGeneralString(WildcardMatch matcher, string input) => DefaultWildcardEngine.IsMatch(input.AsSpan(), matcher._matchPattern.AsSpan(), (matcher._options & WildcardOptions.Singleline) != 0, false, matcher._prefix, matcher._suffix);
    private static bool MatchSlowString(WildcardMatch matcher, string input) => WildcardEngine.IsMatch(input, matcher._matchPattern, matcher._options, matcher._caseBehavior, matcher._literal, matcher._timeout, matcher.Wildcard, matcher._prefix, matcher._suffix, matcher._leadingQuestions);

'''+text[at:];p.write_text(text)
p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text().replace('bool MatchPacked','internal bool MatchPacked').replace(' readonly ulong _packedValue',' internal bool IsPacked => _packedLength != 0;\n readonly ulong _packedValue');p.write_text(text)
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence/taildispatch-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Tail dispatch build failed')
sys.path.insert(0,str(R));from rpc import *
i=launch(rig,'taildispatch');g=grant(i,'execute_registered_scenario',120,'taildispatch');s=Session('taildispatch')
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'taildispatch-scenarios')['scenarios'];out=[]
 for shape in ['Literal','Simple','MultiStar','LongText','Diverse']:
  a=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,a,'taildispatch-'+shape,30000 if shape=='LongText' else 300000);ex,c=execute(s,i,p,g,'taildispatch-'+shape);out.append({'shape':shape,'execution_id':ex,'comparison':c})
 (R/'evidence/taildispatch-summary.json').write_text(json.dumps(out,indent=2))
finally:s.close();(R/'stop-target-taildispatch').touch()
