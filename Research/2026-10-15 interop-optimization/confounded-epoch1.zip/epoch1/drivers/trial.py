import pathlib,sys,shutil,subprocess,json,time,os
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization');sys.path.insert(0,str(R));from rpc import *
name=sys.argv[1];rig=R/('trial-'+name);shutil.copytree(R/'rig',rig,ignore=shutil.ignore_patterns('bin','obj'),dirs_exist_ok=True)
p=rig/'candidate/WildcardMatch.cs';text=p.read_text()
if name=='greedy':text=text.replace('return _short.IsMatch(input);','return DefaultWildcardEngine.IsMatch(input, _matchPattern.AsSpan(), singleline, false, _prefix, _suffix);')
if name=='segments':text=text.replace('if (_short != null && input.Length <= 32) return _short.IsMatch(input);','if (_segments != null && input.Length <= 32) return _segments.IsMatch(input);')
p.write_text(text)
if name=='early':
 p=rig/'candidate/ShortPattern.cs';text=p.read_text();text=text.replace('private readonly bool _singleline;','private readonly bool _singleline;\n    private readonly bool _early;')
 text=text.replace('_singleline = singleline; }','_singleline = singleline; _early = (stars & (accept >> 1)) != 0 && !Array.Exists(literals, e => e.Code == \'\\n\'); }')
 text=text.replace('active |= (active & _stars) << 1;','active |= (active & _stars) << 1;\n            if (_early && (active & _accept) != 0) { if (_singleline) return true; int lf = input.Slice(i + 1).IndexOf(\'\\n\'); return lf < 0 || lf == input.Length - i - 2; }')
 p.write_text(text)
if name in ('packed','packedlate','packedwords','packedtail','packedsimd','packedvectorword'):
 p=rig/'candidate/ShortPattern.cs';text=p.read_text().replace('internal sealed class ShortPattern','internal sealed partial class ShortPattern');text=text.replace('if (pattern.Length > 63 || pattern.IndexOf(\'*\') < 0) return null;','if (pattern.Length > 63 || pattern.IndexOf(\'*\') < 0) return null;\n        var packed = CreatePacked(pattern, singleline); if (packed != null) return packed;');text=text.replace('ulong active = 1 | ((1 & _stars) << 1);','if (_packedLength != 0) return MatchPacked(input);\n        ulong active = 1 | ((1 & _stars) << 1);');p.write_text(text)
 (rig/'candidate/ShortPattern.Packed.cs').write_text(r'''
using System;
using System.Runtime.CompilerServices;
namespace Tedd;
internal sealed partial class ShortPattern {
 readonly ulong _packedValue,_packedMask;readonly int _packedLength,_packedAnchorOffset;readonly char _packedAnchor,_packedTail;
 ShortPattern(ulong value,ulong mask,int length,int anchorOffset,char anchor,char tail,bool singleline){_literals=Array.Empty<Entry>();_packedValue=value;_packedMask=mask;_packedLength=length;_packedAnchorOffset=anchorOffset;_packedAnchor=anchor;_packedTail=tail;_singleline=singleline;}
 static ShortPattern? CreatePacked(string p,bool singleline){
  if(!BitConverter.IsLittleEndian||p.Length<7||p[0]!='*'||p[p.Length-1]!='*'||p.IndexOf('\n')>=0)return null;
  int start=0;while(start<p.Length&&p[start]=='*')start++;
  int end=start;while(end<p.Length&&p[end]!='*')end++;
  int length=end-start;if(length<3||length>4)return null;
  int next=end;while(next<p.Length&&p[next]=='*')next++;
  if(next>=p.Length||p[next]=='?')return null;char tail=p[next++];if(next>=p.Length)return null;
  while(next<p.Length&&p[next]=='*')next++;if(next!=p.Length)return null;
  ulong value=0,mask=0;int anchorOffset=-1;char anchor='\0';
  for(int i=0;i<length;i++)if(p[start+i]!='?'){value|=(ulong)p[start+i]<<(16*i);mask|=65535UL<<(16*i);if(anchorOffset<0){anchorOffset=i;anchor=p[start+i];}}
  return new ShortPattern(value,mask,length,anchorOffset,anchor,tail,singleline);
 }
 [MethodImpl(MethodImplOptions.AggressiveInlining)]
 unsafe bool MatchPacked(ReadOnlySpan<char> input){
  int length=input.Length;
  if(!_singleline){if(length>0&&input[length-1]=='\n')length--;if(input.Slice(0,length).IndexOf('\n')>=0)return false;}
  int last=length-_packedLength-1;if(last<0)return false;
  fixed(char* p=input){
   for(int i=0;i<=last;i++){
    if(_packedAnchorOffset>=0&&p[i+_packedAnchorOffset]!=_packedAnchor)continue;
    if((*(ulong*)(p+i)&_packedMask)==_packedValue)
     return input.Slice(i+_packedLength,length-i-_packedLength).IndexOf(_packedTail)>=0;
   }
  }
  return false;
 }
}
''')
if name in ('packedlate','packedwords','packedtail','packedsimd','packedvectorword'):
 p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text();text=text.replace("if(!_singleline){if(length>0&&input[length-1]=='\\n')length--;if(input.Slice(0,length).IndexOf('\\n')>=0)return false;}","if(!_singleline && length>0 && input[length-1]=='\\n')length--;")
 text=text.replace("return input.Slice(i+_packedLength,length-i-_packedLength).IndexOf(_packedTail)>=0;","return input.Slice(i+_packedLength,length-i-_packedLength).IndexOf(_packedTail)>=0 && (_singleline || input.Slice(0,length).IndexOf('\\n')<0);")
 p.write_text(text)
if name=='packedwords':
 p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text();text=text.replace("if(_packedAnchorOffset>=0&&p[i+_packedAnchorOffset]!=_packedAnchor)continue;","");p.write_text(text)
if name in ('packedtail','packedsimd','packedvectorword'):
 p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text();text=text.replace("int last=length-_packedLength-1;if(last<0)return false;","if(length<=_packedLength)return false; int tail=input.Slice(0,length).LastIndexOf(_packedTail); int last=tail-_packedLength;if(last<0)return false;")
 text=text.replace("if(_packedAnchorOffset>=0&&p[i+_packedAnchorOffset]!=_packedAnchor)continue;","")
 text=text.replace("return input.Slice(i+_packedLength,length-i-_packedLength).IndexOf(_packedTail)>=0 && (_singleline || input.Slice(0,length).IndexOf('\\n')<0);","return _singleline || input.Slice(0,length).IndexOf('\\n')<0;")
 p.write_text(text)
if name=='packedvectorword':
 p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text();text=text.replace('using System.Runtime.CompilerServices;','using System.Runtime.CompilerServices;\n#if NET10_0_OR_GREATER\nusing System.Runtime.Intrinsics;\nusing System.Numerics;\n#endif')
 text=text.replace('if(length<=_packedLength)return false;',r'''#if NET10_0_OR_GREATER
  if(Vector128.IsHardwareAccelerated && (uint)(length-4)<4){
   fixed(char* p=input){
    Vector128<ushort> data=Vector128.Create(*(ulong*)p,*(ulong*)(p+length-4)).AsUInt16();
    uint e=Vector128.Equals(data,Vector128.Create((ushort)_packedTail)).AsByte().ExtractMostSignificantBits();
    int slot=(31-BitOperations.LeadingZeroCount(e))>>1;
    int tailIndex=slot>=4 ? slot+length-8 : slot;
    int finalStart=tailIndex-_packedLength;
    for(int i=0;i<=finalStart;i++)
     if((*(ulong*)(p+i)&_packedMask)==_packedValue)
      return _singleline || !Vector128.EqualsAny(data,Vector128.Create((ushort)'\n'));
    return false;
   }
  }
#endif
  if(length<=_packedLength)return false;''');p.write_text(text)
if name=='packedsimd':
 p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text();text=text.replace('using System.Runtime.CompilerServices;','using System.Runtime.CompilerServices;\n#if NET10_0_OR_GREATER\nusing System.Runtime.Intrinsics;\nusing System.Numerics;\n#endif')
 text=text.replace('readonly ulong _packedValue,_packedMask;', '#if NET10_0_OR_GREATER\n readonly bool _packedVector; readonly char _packedLast;\n#endif\n readonly ulong _packedValue,_packedMask;')
 text=text.replace('_singleline=singleline;}', '_singleline=singleline;\n#if NET10_0_OR_GREATER\n _packedVector=Vector128.IsHardwareAccelerated && length==3 && mask==0xFFFF0000FFFFUL;_packedLast=(char)(value>>32);\n#endif\n }')
 text=text.replace('if(length<=_packedLength)return false;',r'''#if NET10_0_OR_GREATER
  if(_packedVector && (uint)(length-4)<4){
   fixed(char* p=input){
    Vector128<ushort> data=Vector128.Create(*(ulong*)p,*(ulong*)(p+length-4)).AsUInt16();
    uint a=Vector128.Equals(data,Vector128.Create((ushort)_packedAnchor)).AsByte().ExtractMostSignificantBits();
    uint c=Vector128.Equals(data,Vector128.Create((ushort)_packedLast)).AsByte().ExtractMostSignificantBits();
    uint e=Vector128.Equals(data,Vector128.Create((ushort)_packedTail)).AsByte().ExtractMostSignificantBits();
    int shift=(length-4)*2;
    a=(a&255)|((a>>8)<<shift);c=(c&255)|((c>>8)<<shift);e=(e&255)|((e>>8)<<shift);
    int first=(int)BitOperations.TrailingZeroCount(a&(c>>4))>>1;
    int finalTail=(31-BitOperations.LeadingZeroCount(e))>>1;
    return finalTail-first>=3 && (_singleline || !Vector128.EqualsAny(data,Vector128.Create((ushort)'\n')));
   }
  }
#endif
  if(length<=_packedLength)return false;''')
 p.write_text(text)
if name=='lazytail':
 for n in ['ShortPattern.cs','ShortPattern.Packed.cs','CompiledSegments.cs']:
  shutil.copy2(R/'trial-nopin/candidate'/n,rig/'candidate'/n)
 p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text();start=text.index(' [MethodImpl(MethodImplOptions.AggressiveInlining)]\n bool MatchPacked')
 text=text[:start]+r''' [MethodImpl(MethodImplOptions.AggressiveInlining)]
 bool MatchPacked(ReadOnlySpan<char> input){
  int length=input.Length;
  if(!_singleline && length>0 && input[length-1]=='\n')length--;
#if NET10_0_OR_GREATER
  if(Vector128.IsHardwareAccelerated && (uint)(length-4)<4){
   ulong finalWord=ReadWord(input,length-4);
   Vector128<ushort> tailData=Vector128.CreateScalar(finalWord).AsUInt16();
   uint bits=Vector128.Equals(tailData,Vector128.Create((ushort)_packedTail)).AsByte().ExtractMostSignificantBits()&255;
   int finalStart=((31-BitOperations.LeadingZeroCount(bits))>>1)+length-4-_packedLength;
   for(int i=0;i<=finalStart;i++){
    if((ReadWord(input,i)&_packedMask)!=_packedValue)continue;
    if(_singleline)return true;
    Vector128<ushort> all=Vector128.Create(ReadWord(input,0),finalWord).AsUInt16();
    return !Vector128.EqualsAny(all,Vector128.Create((ushort)'\n'));
   }
   return false;
  }
#endif
  if(length<=_packedLength)return false;
  int tail=input.Slice(0,length).LastIndexOf(_packedTail),last=tail-_packedLength;
  for(int i=0;i<=last;i++)
   if((ReadWord(input,i)&_packedMask)==_packedValue)return _singleline||input.Slice(0,length).IndexOf('\n')<0;
  return false;
 }
}
''';p.write_text(text)
if name in ('nopin','hotsplit'):
 for n in ['ShortPattern.cs','ShortPattern.Packed.cs']:
  shutil.copy2(R/'trial-packedvectorword/candidate'/n,rig/'candidate'/n)
 shutil.copy2(R/'trial-knownanchor/candidate/CompiledSegments.cs',rig/'candidate/CompiledSegments.cs')
 p=rig/'candidate/ShortPattern.Packed.cs';text=p.read_text();text=text.replace('using System;','using System;\nusing System.Runtime.InteropServices;');text=text.replace('unsafe bool MatchPacked','bool MatchPacked').replace('fixed(char* p=input){','{').replace('*(ulong*)(p+length-4)','ReadWord(input,length-4)').replace('*(ulong*)(p+i)','ReadWord(input,i)').replace('*(ulong*)p','ReadWord(input,0)')
 at=text.index(' [MethodImpl(MethodImplOptions.AggressiveInlining)]')
 text=text[:at]+r''' [MethodImpl(MethodImplOptions.AggressiveInlining)]
 static ulong ReadWord(ReadOnlySpan<char> input,int offset){
#if NET10_0_OR_GREATER
  return Unsafe.ReadUnaligned<ulong>(ref Unsafe.As<char,byte>(ref Unsafe.Add(ref MemoryMarshal.GetReference(input),offset)));
#else
  return MemoryMarshal.Read<ulong>(MemoryMarshal.AsBytes(input.Slice(offset,4)));
#endif
 }
'''+text[at:];p.write_text(text)
if name=='hotsplit':
 p=rig/'candidate/WildcardMatch.cs';text=p.read_text();old='return WildcardEngine.IsMatch(input, _matchPattern, _options, _caseBehavior, _literal, _timeout, Wildcard, _prefix, _suffix, _leadingQuestions);';text=text.replace(old,'return MatchSlow(input);')
 at=text.index('    /// <summary>Matches a borrowed input slice')
 text=text[:at]+r'''    [MethodImpl(MethodImplOptions.NoInlining)]
    private bool MatchSlow(string input) => WildcardEngine.IsMatch(input, _matchPattern, _options, _caseBehavior, _literal, _timeout, Wildcard, _prefix, _suffix, _leadingQuestions);

'''+text[at:];p.write_text(text)
if name=='combined':
 for n in ['ShortPattern.cs','ShortPattern.Packed.cs']:
  shutil.copy2(R/'trial-packedsimd/candidate'/n,rig/'candidate'/n)
 shutil.copy2(R/'trial-knownanchor/candidate/CompiledSegments.cs',rig/'candidate/CompiledSegments.cs')
if name=='knownanchor':
 p=rig/'candidate/CompiledSegments.cs';text=p.read_text();text=text.replace("if ((segment.Second < 0 || input[candidate + segment.Second] == _pattern[segment.Offset + segment.Second]) && Matches(input, in segment, candidate)) break;","if (segment.AnchorLength == segment.Length || ((segment.Second < 0 || input[candidate + segment.Second] == _pattern[segment.Offset + segment.Second]) && Matches(input, in segment, candidate))) break;");p.write_text(text)
if name=='lfscan':
 p=rig/'candidate/CompiledSegments.cs';text=p.read_text();text=text.replace('return Window(input);','if (input.IndexOf(\'\\n\') >= 0) return false;\n            return Window(input, false);');text=text.replace('return Window(input) ||','return Window(input, !_singleline) ||').replace('Window(input.Slice(0, input.Length - 1))','Window(input.Slice(0, input.Length - 1), !_singleline)');text=text.replace('private bool Window(ReadOnlySpan<char> input)','private bool Window(ReadOnlySpan<char> input, bool checkLines)');text=text.replace('if (!_singleline && input.Slice(checkedUntil, candidate - checkedUntil)','if (checkLines && input.Slice(checkedUntil, candidate - checkedUntil)');text=text.replace('return _singleline || input.Slice(position, limit - position)','return !checkLines || input.Slice(position, limit - position)');p.write_text(text)
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=rig,capture_output=True,text=True);(R/'evidence'/f'{name}-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Trial build failed '+name)
i=launch(rig,name);g=grant(i,'execute_registered_scenario',220 if name=='combined' else 100,name);s=Session(name)
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},name+'-scenarios')['scenarios']
 s.call('lab.discover',{'action':'compatibility','target_id':i['id']},name+'-compatibility')
 summaries=[]
 for shape in (['Literal','Simple','MultiStar','LongText','Diverse','Dense4096','Dense16384','Newline'] if name=='combined' else ['MultiStar','Diverse','LongText']):
  a=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,a,name+'-'+shape,512 if shape.startswith('Dense') else 1000 if shape=='Newline' else 30000 if shape=='LongText' else 300000)
  ex,c=execute(s,i,p,g,name+'-'+shape);summaries.append({'shape':shape,'execution_id':ex,'comparison':c})
 (R/'evidence'/f'{name}-summary.json').write_text(json.dumps(summaries,indent=2))
finally:
 s.close();(R/f'stop-target-{name}').touch()








