import pathlib, subprocess, json, time, os, ctypes, traceback
ROOT=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization')
DOTNET=r'D:\Workspaces\AI\dotnetlab-runtime\dotnet.exe'
HOST=r'D:\Workspaces\AI\dotnetlab-implementation\bin\DotNetLab.Host\Release\net10.0\DotNetLab.Host.dll'
ENV=os.environ.copy(); ENV.update(TEMP=str(ROOT/'tmp'), TMP=str(ROOT/'tmp'), PYTHONDONTWRITEBYTECODE='1')
k=ctypes.windll.kernel32; k.CreateMutexW.restype=ctypes.c_void_p; k.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_uint32]; k.ReleaseMutex.argtypes=[ctypes.c_void_p]
mutex=k.CreateMutexW(None,False,'Global\\ScientificMethodPerformanceHostLock')
if k.WaitForSingleObject(mutex,0) not in (0,128): raise RuntimeError('Host performance lock is held by another task')
(ROOT/'lock-held').write_text(str(os.getpid()))
print('LOCK HELD',flush=True)
try:
 while not (ROOT/'stop-worker').exists():
  jobs=sorted((ROOT/'jobs').glob('*.json'))
  for job in jobs:
   done=job.with_suffix('.done')
   if done.exists(): continue
   spec=json.loads(job.read_text(encoding='utf-8-sig'))
   try:
    if spec.get('type')=='lab':
     args=[DOTNET,HOST,'call',str(ROOT/'catalog'),spec['tool']]
     result=subprocess.run(args,input=json.dumps(spec['payload']),capture_output=True,text=True,env=ENV,cwd=str(ROOT),timeout=spec.get('timeout',120))
    else:
     env=ENV|spec.get('env',{})
     result=subprocess.run(spec['args'],capture_output=True,text=True,env=env,cwd=spec.get('cwd',str(ROOT)),timeout=spec.get('timeout',1800))
    (ROOT/spec['output']).write_text(result.stdout,encoding='utf-8')
    (ROOT/(spec['output']+'.stderr')).write_text(result.stderr,encoding='utf-8')
    done.write_text(json.dumps({'exit_code':result.returncode,'output':spec['output']}))
   except Exception:
    done.write_text(json.dumps({'error':traceback.format_exc()}))
   print(job.stem,done.read_text(),flush=True)
  time.sleep(.2)
finally:
 k.ReleaseMutex(mutex)
 (ROOT/'lock-held').unlink(missing_ok=True)
