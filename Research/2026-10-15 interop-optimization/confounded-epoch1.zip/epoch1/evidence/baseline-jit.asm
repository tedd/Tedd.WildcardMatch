; Assembly listing for method Tedd.WildcardMatch:IsMatch(System.String,System.String,int):bool (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 5 inlinees with PGO data; 20 single block inlinees; 4 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 112
       lea      rbp, [rsp+0xA0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       mov      rdi, rcx
       mov      rsi, rdx
       mov      ebx, r8d
 
G_M000_IG02:                ;; offset=0x0028
       test     rsi, rsi
       je       G_M000_IG19
       mov      ecx, ebx
       call     [Tedd.WildcardEngine:ValidateOptions(int)]
       mov      rcx, rsi
       mov      edx, ebx
       call     [Tedd.WildcardEngine:GetMatchingPattern(System.String,int):System.String]
       mov      r14, rax
       test     ebx, 0x803
       je       G_M000_IG06
 
G_M000_IG03:                ;; offset=0x0053
       mov      ecx, ebx
       call     [Tedd.WildcardEngine:GetCaseBehavior(int):int]
       mov      r15d, eax
       test     byte  ptr [(reloc 0x7ffc657fe270)], 1
       je       G_M000_IG23
 
G_M000_IG04:                ;; offset=0x006B
       mov      rdx, 0x216B2800C60
       mov      rdx, gword ptr [rdx]
       mov      rcx, r14
       cmp      dword ptr [rcx], ecx
       call     [System.String:IndexOfAny(char[]):int:this]
       mov      ecx, eax
       shr      ecx, 31
       mov      r9, 0x21680456CE0
       mov      rdx, qword ptr [r9]
       mov      gword ptr [rsp+0x30], rsi
       mov      dword ptr [rsp+0x38], -1
       mov      dword ptr [rsp+0x40], -1
       mov      dword ptr [rsp+0x48], -1
       mov      r9d, r15d
       mov      dword ptr [rsp+0x20], ecx
       mov      qword ptr [rsp+0x28], rdx
       mov      rcx, rdi
       mov      rdx, r14
       mov      r8d, ebx
       call     [Tedd.WildcardEngine:IsMatch(System.String,System.String,int,int,bool,System.TimeSpan,System.String,int,int,int):bool]
       nop      
 
G_M000_IG05:                ;; offset=0x00CE
       add      rsp, 112
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x00DD
       test     rdi, rdi
       je       G_M000_IG20
       lea      rsi, bword ptr [rdi+0x0C]
       mov      edi, dword ptr [rdi+0x08]
       test     r14, r14
       je       SHORT G_M000_IG07
       lea      r15, bword ptr [r14+0x0C]
       mov      r13d, dword ptr [r14+0x08]
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x00FC
       xor      r15, r15
       xor      r13d, r13d
 
G_M000_IG08:                ;; offset=0x0102
       test     bl, 16
       setne    bl
       movzx    rbx, bl
       test     byte  ptr [(reloc 0x7ffc657fe270)], 1
       je       G_M000_IG21
 
G_M000_IG09:                ;; offset=0x0118
       mov      rdx, 0x216B2800C60
       mov      rdx, gword ptr [rdx]
       mov      rcx, r14
       cmp      dword ptr [rcx], ecx
       call     [System.String:IndexOfAny(char[]):int:this]
       test     eax, eax
       jl       G_M000_IG12
       mov      rcx, r15
       mov      r8d, r13d
       mov      edx, 42
       call     [System.PackedSpanHelpers:IndexOf[System.SpanHelpers+DontNegate`1[short],System.PackedSpanHelpers+NopTransform](byref,short,int):int]
       test     eax, eax
       jl       G_M000_IG11
       mov      bword ptr [rbp-0x40], rsi
       mov      dword ptr [rbp-0x38], edi
       mov      bword ptr [rbp-0x50], r15
       mov      dword ptr [rbp-0x48], r13d
       mov      dword ptr [rsp+0x20], -1
       lea      rcx, [rbp-0x40]
       lea      rdx, [rbp-0x50]
       mov      r8d, ebx
       mov      r9d, -1
       call     [Tedd.DefaultWildcardEngine:Window(System.ReadOnlySpan`1[char],System.ReadOnlySpan`1[char],bool,int,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      eax, 1
       jmp      G_M000_IG18
 
G_M000_IG10:                ;; offset=0x018D
       test     edi, edi
       jle      G_M000_IG13
       lea      r14d, [rdi-0x01]
       mov      ecx, r14d
       cmp      word  ptr [rsi+2*rcx], 10
       jne      G_M000_IG13
       cmp      r14d, edi
       ja       G_M000_IG22
       mov      bword ptr [rbp-0x40], rsi
       mov      dword ptr [rbp-0x38], r14d
       mov      bword ptr [rbp-0x50], r15
       mov      dword ptr [rbp-0x48], r13d
       mov      dword ptr [rsp+0x20], -1
       lea      rcx, [rbp-0x40]
       lea      rdx, [rbp-0x50]
       mov      r8d, ebx
       mov      r9d, -1
       call     [Tedd.DefaultWildcardEngine:Window(System.ReadOnlySpan`1[char],System.ReadOnlySpan`1[char],bool,int,int):bool]
       jmp      G_M000_IG18
 
G_M000_IG11:                ;; offset=0x01E4
       mov      bword ptr [rbp-0x40], rsi
       mov      dword ptr [rbp-0x38], edi
       mov      bword ptr [rbp-0x50], r15
       mov      dword ptr [rbp-0x48], r13d
       lea      rcx, [rbp-0x40]
       lea      rdx, [rbp-0x50]
       mov      r8d, ebx
       call     [Tedd.DefaultWildcardEngine:Fixed(System.ReadOnlySpan`1[char],System.ReadOnlySpan`1[char],bool):bool]
       jmp      SHORT G_M000_IG18
 
G_M000_IG12:                ;; offset=0x0206
       cmp      edi, r13d
       je       SHORT G_M000_IG14
       test     edi, edi
       jle      SHORT G_M000_IG13
       lea      r14d, [rdi-0x01]
       cmp      r14d, r13d
       jne      SHORT G_M000_IG13
       mov      eax, r14d
       mov      ecx, eax
       cmp      word  ptr [rsi+2*rcx], 10
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0224
       xor      eax, eax
       jmp      SHORT G_M000_IG18
 
G_M000_IG14:                ;; offset=0x0228
       cmp      r13d, edi
       ja       G_M000_IG22
 
G_M000_IG15:                ;; offset=0x0231
       mov      r8d, r13d
       add      r8, r8
       cmp      r8, 10
       je       SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x023D
       mov      rcx, rsi
       mov      rdx, r15
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x024B
       mov      rax, qword ptr [rsi]
       mov      rcx, qword ptr [rsi+0x02]
       mov      rdx, qword ptr [r15]
       xor      rax, rdx
       xor      rcx, qword ptr [r15+0x02]
       or       rax, rcx
       sete     al
       movzx    rax, al
 
G_M000_IG18:                ;; offset=0x0265
       add      rsp, 112
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG19:                ;; offset=0x0274
       mov      rcx, 0x7FFC656284E0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      ecx, 35
       mov      rdx, 0x7FFC657FCEC8
       call     [CORINFO_HELP_STRCNS]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.ArgumentNullException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG20:                ;; offset=0x02B0
       mov      rcx, 0x7FFC656284E0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      ecx, 155
       mov      rdx, 0x7FFC657FCEC8
       call     [CORINFO_HELP_STRCNS]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.ArgumentNullException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG21:                ;; offset=0x02EC
       mov      rcx, 0x7FFC657FE208
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       jmp      G_M000_IG09
 
G_M000_IG22:                ;; offset=0x0300
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG23:                ;; offset=0x0307
       mov      rcx, 0x7FFC657FE208
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       jmp      G_M000_IG04
 
; Total bytes of code 795

; Assembly listing for method Tedd.WildcardMatch:IsMatch(System.String):bool:this (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 11 inlinees with PGO data; 35 single block inlinees; 9 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 120
       lea      rbp, [rsp+0xB0]
       xor      eax, eax
       mov      qword ptr [rbp-0x58], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      rax, rdx
 
G_M000_IG02:                ;; offset=0x002E
       test     rax, rax
       je       G_M000_IG73
       cmp      byte  ptr [rcx+0x4C], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x003D
       movzx    rdx, byte  ptr [rcx+0x4D]
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, qword ptr [rcx+0x50]
       mov      qword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rcx+0x30]
       mov      gword ptr [rsp+0x30], rdx
       mov      edx, dword ptr [rcx+0x44]
       mov      dword ptr [rsp+0x38], edx
       mov      edx, dword ptr [rcx+0x48]
       mov      dword ptr [rsp+0x40], edx
       mov      edx, dword ptr [rcx+0x40]
       mov      dword ptr [rsp+0x48], edx
       mov      rdx, gword ptr [rcx+0x20]
       mov      r8d, dword ptr [rcx+0x38]
       mov      r9d, dword ptr [rcx+0x3C]
       mov      rcx, rax
       call     [Tedd.WildcardEngine:IsMatch(System.String,System.String,int,int,bool,System.TimeSpan,System.String,int,int,int):bool]
       nop      
 
G_M000_IG04:                ;; offset=0x0082
       vzeroupper 
       add      rsp, 120
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG05:                ;; offset=0x0096
       lea      rbx, bword ptr [rax+0x0C]
       mov      esi, dword ptr [rax+0x08]
       test     byte  ptr [rcx+0x38], 16
       setne    dil
       movzx    rdi, dil
       cmp      byte  ptr [rcx+0x4D], 0
       jne      G_M000_IG51
       mov      r14, gword ptr [rcx+0x08]
       test     r14, r14
       jne      G_M000_IG42
       mov      r14, gword ptr [rcx+0x10]
       test     r14, r14
       je       SHORT G_M000_IG06
       cmp      esi, 32
       jle      G_M000_IG22
 
G_M000_IG06:                ;; offset=0x00D2
       mov      r14, gword ptr [rcx+0x18]
       test     r14, r14
       je       SHORT G_M000_IG07
       cmp      esi, 32
       jg       G_M000_IG15
 
G_M000_IG07:                ;; offset=0x00E4
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG08
       lea      r14, bword ptr [r8+0x0C]
       mov      r15d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG09
       align    [0 bytes for IG23]
 
G_M000_IG08:                ;; offset=0x00F7
       xor      r14, r14
       xor      r15d, r15d
 
G_M000_IG09:                ;; offset=0x00FD
       mov      r13d, dword ptr [rcx+0x44]
       mov      r12d, dword ptr [rcx+0x48]
       mov      rcx, r14
       mov      r8d, r15d
       mov      edx, 42
       call     [System.PackedSpanHelpers:IndexOf[System.SpanHelpers+DontNegate`1[short],System.PackedSpanHelpers+NopTransform](byref,short,int):int]
       test     eax, eax
       jl       G_M000_IG13
       mov      bword ptr [rbp-0x48], rbx
       mov      dword ptr [rbp-0x40], esi
       mov      bword ptr [rbp-0x58], r14
       mov      dword ptr [rbp-0x50], r15d
       mov      dword ptr [rsp+0x20], r12d
       lea      rcx, [rbp-0x48]
       lea      rdx, [rbp-0x58]
       mov      r8d, edi
       mov      r9d, r13d
       call     [Tedd.DefaultWildcardEngine:Window(System.ReadOnlySpan`1[char],System.ReadOnlySpan`1[char],bool,int,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      eax, 1
       jmp      SHORT G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0151
       test     esi, esi
       jle      SHORT G_M000_IG11
       lea      eax, [rsi-0x01]
       mov      ecx, eax
       cmp      word  ptr [rbx+2*rcx], 10
       je       SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0161
       xor      eax, eax
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x0165
       lea      ecx, [rsi-0x01]
       cmp      ecx, esi
       ja       G_M000_IG74
       mov      bword ptr [rbp-0x48], rbx
       mov      dword ptr [rbp-0x40], ecx
       mov      bword ptr [rbp-0x58], r14
       mov      dword ptr [rbp-0x50], r15d
       mov      dword ptr [rsp+0x20], r12d
       lea      rcx, [rbp-0x48]
       lea      rdx, [rbp-0x58]
       mov      r8d, edi
       mov      r9d, r13d
       call     [Tedd.DefaultWildcardEngine:Window(System.ReadOnlySpan`1[char],System.ReadOnlySpan`1[char],bool,int,int):bool]
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x019A
       mov      bword ptr [rbp-0x48], rbx
       mov      dword ptr [rbp-0x40], esi
       mov      bword ptr [rbp-0x58], r14
       mov      dword ptr [rbp-0x50], r15d
       lea      rcx, [rbp-0x48]
       lea      rdx, [rbp-0x58]
       mov      r8d, edi
       call     [Tedd.DefaultWildcardEngine:Fixed(System.ReadOnlySpan`1[char],System.ReadOnlySpan`1[char],bool):bool]
 
G_M000_IG14:                ;; offset=0x01BA
       jmp      G_M000_IG59
 
G_M000_IG15:                ;; offset=0x01BF
       mov      edi, esi
       cmp      byte  ptr [r14+0x1C], 0
       jne      SHORT G_M000_IG16
       cmp      byte  ptr [r14+0x1F], 0
       je       SHORT G_M000_IG19
 
G_M000_IG16:                ;; offset=0x01CF
       mov      bword ptr [rbp-0x48], rbx
       mov      dword ptr [rbp-0x40], esi
       lea      rdx, [rbp-0x48]
       mov      rcx, r14
       call     [Tedd.CompiledSegments:Window(System.ReadOnlySpan`1[char]):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      eax, 1
       jmp      SHORT G_M000_IG21
 
G_M000_IG17:                ;; offset=0x01EE
       lea      eax, [rsi-0x01]
       mov      edx, eax
       cmp      word  ptr [rbx+2*rdx], 10
       je       SHORT G_M000_IG18
       xor      eax, eax
       jmp      SHORT G_M000_IG21
 
G_M000_IG18:                ;; offset=0x01FE
       lea      edx, [rsi-0x01]
       cmp      edx, esi
       ja       G_M000_IG74
       mov      bword ptr [rbp-0x48], rbx
       mov      dword ptr [rbp-0x40], edx
       lea      rdx, [rbp-0x48]
       mov      rcx, r14
       call     [Tedd.CompiledSegments:Window(System.ReadOnlySpan`1[char]):bool:this]
       jmp      SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x021F
       lea      edx, [rdi-0x01]
       cmp      word  ptr [rbx+2*rdx], 10
       jne      SHORT G_M000_IG20
       lea      edi, [rsi-0x01]
       cmp      edi, esi
       ja       G_M000_IG74
 
G_M000_IG20:                ;; offset=0x0234
       mov      bword ptr [rbp-0x48], rbx
       mov      dword ptr [rbp-0x40], edi
       lea      rdx, [rbp-0x48]
       mov      rcx, r14
       call     [Tedd.CompiledSegments:Window(System.ReadOnlySpan`1[char]):bool:this]
 
G_M000_IG21:                ;; offset=0x0248
       jmp      G_M000_IG59
 
G_M000_IG22:                ;; offset=0x024D
       mov      rax, qword ptr [r14+0x10]
       mov      rcx, rax
       and      rcx, 1
       add      rcx, rcx
       or       rcx, 1
       xor      r8d, r8d
       cmp      r8d, esi
       jge      G_M000_IG38
 
G_M000_IG23:                ;; offset=0x026B
       movzx    rdx, word  ptr [rbx+2*r8]
       lea      r10d, [rsi-0x01]
       cmp      r8d, r10d
       jne      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0279
       cmp      edx, 10
       jne      SHORT G_M000_IG25
       test     rcx, qword ptr [r14+0x20]
       jne      G_M000_IG40
 
G_M000_IG25:                ;; offset=0x0288
       mov      r10, gword ptr [r14+0x08]
       mov      r9, r10
       mov      r10d, dword ptr [r10+0x08]
       dec      r10d
       and      r10d, edx
       cmp      r10d, dword ptr [r9+0x08]
       jae      G_M000_IG75
       shl      r10, 4
       lea      r10, bword ptr [r9+r10+0x10]
       movzx    r9, word  ptr [r10]
       cmp      r9d, edx
       jne      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x02B5
       mov      r10, qword ptr [r10+0x08]
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x02BB
       xor      r10d, r10d
 
G_M000_IG28:                ;; offset=0x02BE
       cmp      byte  ptr [r14+0x28], 0
       je       SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x02C5
       mov      r9d, 1
       jmp      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x02CD
       cmp      edx, 10
       setne    r9b
       movzx    r9, r9b
 
G_M000_IG31:                ;; offset=0x02D8
       test     r9d, r9d
       je       SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x02DD
       mov      rdx, qword ptr [r14+0x18]
       jmp      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x02E3
       xor      edx, edx
 
G_M000_IG34:                ;; offset=0x02E5
       or       rdx, r10
       and      rdx, rcx
       add      rdx, rdx
       test     r9d, r9d
       je       SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x02F3
       and      rcx, rax
       jmp      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x02F8
       xor      ecx, ecx
 
G_M000_IG37:                ;; offset=0x02FA
       or       rcx, rdx
       mov      rdx, rcx
       and      rdx, rax
       add      rdx, rdx
       or       rdx, rcx
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG39
       inc      r8d
       cmp      r8d, esi
       jl       G_M000_IG23
 
G_M000_IG38:                ;; offset=0x031D
       test     rcx, qword ptr [r14+0x20]
       setne    al
       movzx    rax, al
       jmp      SHORT G_M000_IG41
 
G_M000_IG39:                ;; offset=0x0329
       xor      eax, eax
       jmp      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x032D
       mov      eax, 1
 
G_M000_IG41:                ;; offset=0x0332
       jmp      G_M000_IG59
 
G_M000_IG42:                ;; offset=0x0337
       mov      rdi, rbx
       mov      rcx, gword ptr [r14+0x08]
       mov      r15d, dword ptr [rcx+0x08]
       cmp      esi, r15d
       je       SHORT G_M000_IG43
       lea      ecx, [r15+0x01]
       cmp      esi, ecx
       jne      G_M000_IG49
       cmp      r15d, esi
       jae      G_M000_IG75
       mov      ecx, r15d
       cmp      word  ptr [rdi+2*rcx], 10
       jne      G_M000_IG49
 
G_M000_IG43:                ;; offset=0x036A
       mov      r13, gword ptr [r14+0x10]
       test     r13, r13
       jne      G_M000_IG66
       mov      ecx, r15d
       sub      ecx, 8
       cmp      ecx, 8
       jbe      G_M000_IG64
       cmp      byte  ptr [r14+0x1C], 0
       jne      SHORT G_M000_IG44
       mov      r8d, dword ptr [r14+0x18]
       cmp      r8d, esi
       ja       G_M000_IG74
       mov      rcx, rdi
       mov      edx, 10
       call     [System.PackedSpanHelpers:IndexOf[System.SpanHelpers+DontNegate`1[short],System.PackedSpanHelpers+NopTransform](byref,short,int):int]
       test     eax, eax
       jge      SHORT G_M000_IG49
 
G_M000_IG44:                ;; offset=0x03AC
       mov      ecx, dword ptr [r14+0x18]
       cmp      ecx, r15d
       jge      G_M000_IG71
       test     ecx, ecx
       jl       G_M000_IG62
       cmp      r15d, esi
       jg       G_M000_IG62
       mov      rdx, gword ptr [r14+0x08]
       jmp      SHORT G_M000_IG47
 
G_M000_IG45:                ;; offset=0x03D0
       mov      r8d, ecx
       movzx    r8, word  ptr [rdi+2*r8]
       cmp      r8d, eax
       jne      SHORT G_M000_IG49
 
G_M000_IG46:                ;; offset=0x03DD
       inc      ecx
       cmp      ecx, r15d
       jge      G_M000_IG71
 
G_M000_IG47:                ;; offset=0x03E8
       mov      r8, rdx
       cmp      ecx, dword ptr [r8+0x08]
       jae      G_M000_IG75
       mov      eax, ecx
       movzx    rax, word  ptr [r8+2*rax+0x0C]
       cmp      eax, 63
       jne      SHORT G_M000_IG45
 
G_M000_IG48:                ;; offset=0x0402
       cmp      byte  ptr [r14+0x1C], 0
       jne      SHORT G_M000_IG46
       mov      eax, ecx
       cmp      word  ptr [rdi+2*rax], 10
       jne      SHORT G_M000_IG46
 
G_M000_IG49:                ;; offset=0x0412
       xor      eax, eax
 
G_M000_IG50:                ;; offset=0x0414
       jmp      SHORT G_M000_IG59
 
G_M000_IG51:                ;; offset=0x0416
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       je       SHORT G_M000_IG52
       lea      rdx, bword ptr [rcx+0x0C]
       mov      ecx, dword ptr [rcx+0x08]
       jmp      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0428
       xor      rdx, rdx
       xor      ecx, ecx
 
G_M000_IG53:                ;; offset=0x042C
       cmp      esi, ecx
       je       SHORT G_M000_IG55
       test     esi, esi
       jle      SHORT G_M000_IG54
       lea      r8d, [rsi-0x01]
       cmp      r8d, ecx
       jne      SHORT G_M000_IG54
       lea      r8d, [rsi-0x01]
       cmp      word  ptr [rbx+2*r8], 10
       je       SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0449
       xor      eax, eax
       jmp      SHORT G_M000_IG59
 
G_M000_IG55:                ;; offset=0x044D
       cmp      ecx, esi
       ja       G_M000_IG74
 
G_M000_IG56:                ;; offset=0x0455
       mov      r8d, ecx
       add      r8, r8
       cmp      r8, 10
       je       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0461
       mov      rcx, rbx
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       jmp      SHORT G_M000_IG59
       align    [0 bytes for IG67]
 
G_M000_IG58:                ;; offset=0x046C
       mov      rax, rbx
       mov      rcx, qword ptr [rax]
       mov      rax, qword ptr [rax+0x02]
       mov      r8, qword ptr [rdx]
       xor      rcx, r8
       xor      rax, qword ptr [rdx+0x02]
       or       rax, rcx
       sete     al
       movzx    rax, al
 
G_M000_IG59:                ;; offset=0x0489
       vzeroupper 
       add      rsp, 120
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG60:                ;; offset=0x049D
       cmp      ecx, esi
       jae      G_M000_IG75
       mov      edx, ecx
       movzx    rdx, word  ptr [rdi+2*rdx]
       cmp      edx, eax
       jne      G_M000_IG49
 
G_M000_IG61:                ;; offset=0x04B3
       inc      ecx
       cmp      ecx, r15d
       jge      G_M000_IG71
 
G_M000_IG62:                ;; offset=0x04BE
       mov      rdx, gword ptr [r14+0x08]
       mov      r8, rdx
       cmp      ecx, dword ptr [r8+0x08]
       jae      G_M000_IG75
       mov      eax, ecx
       movzx    rax, word  ptr [r8+2*rax+0x0C]
       cmp      eax, 63
       jne      SHORT G_M000_IG60
 
G_M000_IG63:                ;; offset=0x04DC
       cmp      byte  ptr [r14+0x1C], 0
       jne      SHORT G_M000_IG61
       cmp      ecx, esi
       jae      G_M000_IG75
       mov      eax, ecx
       cmp      word  ptr [rdi+2*rax], 10
       je       G_M000_IG49
       jmp      SHORT G_M000_IG61
 
G_M000_IG64:                ;; offset=0x04FA
       vmovups  xmm0, xmmword ptr [rbx]
       add      r15d, -8
       movsxd   rcx, r15d
       vmovups  xmm1, xmmword ptr [rbx+2*rcx]
       vpxor    xmm2, xmm0, xmmword ptr [r14+0x28]
       vmovups  xmm3, xmmword ptr [r14+0x48]
       vpand    xmm2, xmm2, xmm3
       vpxor    xmm4, xmm1, xmmword ptr [r14+0x38]
       vmovups  xmm5, xmmword ptr [r14+0x58]
       vpand    xmm4, xmm4, xmm5
       vpor     xmm2, xmm4, xmm2
       cmp      byte  ptr [r14+0x1C], 0
       jne      SHORT G_M000_IG65
       vbroadcastss xmm4, dword ptr [reloc @RWD00]
       vpcmpeqw xmm0, xmm0, xmm4
       vpandn   xmm0, xmm3, xmm0
       vpcmpeqw xmm1, xmm1, xmm4
       vpandn   xmm1, xmm5, xmm1
       vpor     xmm0, xmm1, xmm0
       vpor     xmm2, xmm0, xmm2
 
G_M000_IG65:                ;; offset=0x0556
       vptest   xmm2, xmm2
       sete     al
       movzx    rax, al
       jmp      G_M000_IG50
 
G_M000_IG66:                ;; offset=0x0566
       mov      rax, rbx
       xor      ecx, ecx
       mov      rdx, gword ptr [r14+0x10]
       cmp      dword ptr [rdx+0x08], 0
       jle      SHORT G_M000_IG71
       lea      edx, [r15-0x10]
 
G_M000_IG67:                ;; offset=0x0579
       mov      r8d, ecx
       shl      r8d, 4
       mov      r10d, edx
       cmp      r8d, r10d
       jg       SHORT G_M000_IG72
 
G_M000_IG68:                ;; offset=0x0588
       movsxd   r8, r8d
       vmovups  ymm0, ymmword ptr [rax+2*r8]
       mov      r8, r13
       cmp      ecx, dword ptr [r8+0x08]
       jae      G_M000_IG75
       mov      r10, rcx
       shl      r10, 6
       lea      r8, bword ptr [r8+r10+0x10]
       vmovups  ymm1, ymmword ptr [r8+0x20]
       vpxor    ymm2, ymm0, ymmword ptr [r8]
       vpand    ymm2, ymm2, ymm1
       cmp      byte  ptr [r14+0x1C], 0
       jne      SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x05C0
       vpcmpeqw ymm0, ymm0, ymmword ptr [reloc @RWD32]
       vpandn   ymm0, ymm1, ymm0
       vpor     ymm2, ymm0, ymm2
 
G_M000_IG70:                ;; offset=0x05D0
       vptest   ymm2, ymm2
       jne      G_M000_IG49
       inc      ecx
       mov      r8, gword ptr [r14+0x10]
       cmp      dword ptr [r8+0x08], ecx
       jg       SHORT G_M000_IG67
 
G_M000_IG71:                ;; offset=0x05E7
       mov      eax, 1
       jmp      G_M000_IG50
 
G_M000_IG72:                ;; offset=0x05F1
       mov      r8d, r10d
       jmp      SHORT G_M000_IG68
 
G_M000_IG73:                ;; offset=0x05F6
       mov      rcx, 0x7FFC656284E0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      ecx, 155
       mov      rdx, 0x7FFC657FCEC8
       call     [CORINFO_HELP_STRCNS]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.ArgumentNullException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG74:                ;; offset=0x0632
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG75:                ;; offset=0x0639
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000A000Ah		; 9.18369e-40
RWD04  	dd	00000000h, 00000000h, 00000000h, 00000000h, 00000000h, 00000000h
	dd	00000000h
RWD32  	dq	000A000A000A000Ah, 000A000A000A000Ah, 000A000A000A000Ah, 000A000A000A000Ah

; Total bytes of code 1599

