; Assembly listing for method Tedd.WildcardMatch:IsMatch(System.String,System.String,int):bool (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 5 inlinees with PGO data; 20 single block inlinees; 4 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 112
       lea      rbp, [rsp+0xA0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x50], ymm4
       mov      rdi, rcx
       mov      rsi, rdx
       mov      ebx, r8d
 
G_M000_IG02:                ;; offset=0x0028
       test     rsi, rsi
       je       G_M000_IG19
       mov      ecx, ebx
       call     [Tedd.WildcardEngine:ValidateOptions(int)]
       mov      rcx, rsi
       mov      edx, ebx
       call     [Tedd.WildcardEngine:GetMatchingPattern(System.String,int):System.String]
       mov      r14, rax
       test     ebx, 0x803
       je       G_M000_IG06
 
G_M000_IG03:                ;; offset=0x0053
       mov      ecx, ebx
       call     [Tedd.WildcardEngine:GetCaseBehavior(int):int]
       mov      r15d, eax
       test     byte  ptr [(reloc 0x7ffc6580e280)], 1
       je       G_M000_IG23
 
G_M000_IG04:                ;; offset=0x006B
       mov      rdx, 0x17DAC800C60
       mov      rdx, gword ptr [rdx]
       mov      rcx, r14
       cmp      dword ptr [rcx], ecx
       call     [System.String:IndexOfAny(char[]):int:this]
       mov      ecx, eax
       shr      ecx, 31
       mov      r9, 0x17D80456CE0
       mov      rdx, qword ptr [r9]
       mov      gword ptr [rsp+0x30], rsi
       mov      dword ptr [rsp+0x38], -1
       mov      dword ptr [rsp+0x40], -1
       mov      dword ptr [rsp+0x48], -1
       mov      r9d, r15d
       mov      dword ptr [rsp+0x20], ecx
       mov      qword ptr [rsp+0x28], rdx
       mov      rcx, rdi
       mov      rdx, r14
       mov      r8d, ebx
       call     [Tedd.WildcardEngine:IsMatch(System.String,System.String,int,int,bool,System.TimeSpan,System.String,int,int,int):bool]
       nop      
 
G_M000_IG05:                ;; offset=0x00CE
       add      rsp, 112
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x00DD
       test     rdi, rdi
       je       G_M000_IG20
       lea      rsi, bword ptr [rdi+0x0C]
       mov      edi, dword ptr [rdi+0x08]
       test     r14, r14
       je       SHORT G_M000_IG07
       lea      r15, bword ptr [r14+0x0C]
       mov      r13d, dword ptr [r14+0x08]
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x00FC
       xor      r15, r15
       xor      r13d, r13d
 
G_M000_IG08:                ;; offset=0x0102
       test     bl, 16
       setne    bl
       movzx    rbx, bl
       test     byte  ptr [(reloc 0x7ffc6580e280)], 1
       je       G_M000_IG21
 
G_M000_IG09:                ;; offset=0x0118
       mov      rdx, 0x17DAC800C60
       mov      rdx, gword ptr [rdx]
       mov      rcx, r14
       cmp      dword ptr [rcx], ecx
       call     [System.String:IndexOfAny(char[]):int:this]
       test     eax, eax
       jl       G_M000_IG12
       mov      rcx, r15
       mov      r8d, r13d
       mov      edx, 42
       call     [System.PackedSpanHelpers:IndexOf[System.SpanHelpers+DontNegate`1[short],System.PackedSpanHelpers+NopTransform](byref,short,int):int]
       test     eax, eax
       jl       G_M000_IG11
       mov      bword ptr [rbp-0x40], rsi
       mov      dword ptr [rbp-0x38], edi
       mov      bword ptr [rbp-0x50], r15
       mov      dword ptr [rbp-0x48], r13d
       mov      dword ptr [rsp+0x20], -1
       lea      rcx, [rbp-0x40]
       lea      rdx, [rbp-0x50]
       mov      r8d, ebx
       mov      r9d, -1
       call     [Tedd.DefaultWildcardEngine:Window(System.ReadOnlySpan`1[char],System.ReadOnlySpan`1[char],bool,int,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG10
       mov      eax, 1
       jmp      G_M000_IG18
 
G_M000_IG10:                ;; offset=0x018D
       test     edi, edi
       jle      G_M000_IG13
       lea      r14d, [rdi-0x01]
       mov      ecx, r14d
       cmp      word  ptr [rsi+2*rcx], 10
       jne      G_M000_IG13
       cmp      r14d, edi
       ja       G_M000_IG22
       mov      bword ptr [rbp-0x40], rsi
       mov      dword ptr [rbp-0x38], r14d
       mov      bword ptr [rbp-0x50], r15
       mov      dword ptr [rbp-0x48], r13d
       mov      dword ptr [rsp+0x20], -1
       lea      rcx, [rbp-0x40]
       lea      rdx, [rbp-0x50]
       mov      r8d, ebx
       mov      r9d, -1
       call     [Tedd.DefaultWildcardEngine:Window(System.ReadOnlySpan`1[char],System.ReadOnlySpan`1[char],bool,int,int):bool]
       jmp      G_M000_IG18
 
G_M000_IG11:                ;; offset=0x01E4
       mov      bword ptr [rbp-0x40], rsi
       mov      dword ptr [rbp-0x38], edi
       mov      bword ptr [rbp-0x50], r15
       mov      dword ptr [rbp-0x48], r13d
       lea      rcx, [rbp-0x40]
       lea      rdx, [rbp-0x50]
       mov      r8d, ebx
       call     [Tedd.DefaultWildcardEngine:Fixed(System.ReadOnlySpan`1[char],System.ReadOnlySpan`1[char],bool):bool]
       jmp      SHORT G_M000_IG18
 
G_M000_IG12:                ;; offset=0x0206
       cmp      edi, r13d
       je       SHORT G_M000_IG14
       test     edi, edi
       jle      SHORT G_M000_IG13
       lea      r14d, [rdi-0x01]
       cmp      r14d, r13d
       jne      SHORT G_M000_IG13
       mov      eax, r14d
       mov      ecx, eax
       cmp      word  ptr [rsi+2*rcx], 10
       je       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0224
       xor      eax, eax
       jmp      SHORT G_M000_IG18
 
G_M000_IG14:                ;; offset=0x0228
       cmp      r13d, edi
       ja       G_M000_IG22
 
G_M000_IG15:                ;; offset=0x0231
       mov      r8d, r13d
       add      r8, r8
       cmp      r8, 10
       je       SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x023D
       mov      rcx, rsi
       mov      rdx, r15
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x024B
       mov      rax, qword ptr [rsi]
       mov      rcx, qword ptr [rsi+0x02]
       mov      rdx, qword ptr [r15]
       xor      rax, rdx
       xor      rcx, qword ptr [r15+0x02]
       or       rax, rcx
       sete     al
       movzx    rax, al
 
G_M000_IG18:                ;; offset=0x0265
       add      rsp, 112
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG19:                ;; offset=0x0274
       mov      rcx, 0x7FFC656384E0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      ecx, 35
       mov      rdx, 0x7FFC6580CEC8
       call     [CORINFO_HELP_STRCNS]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.ArgumentNullException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG20:                ;; offset=0x02B0
       mov      rcx, 0x7FFC656384E0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      ecx, 155
       mov      rdx, 0x7FFC6580CEC8
       call     [CORINFO_HELP_STRCNS]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.ArgumentNullException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG21:                ;; offset=0x02EC
       mov      rcx, 0x7FFC6580E218
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       jmp      G_M000_IG09
 
G_M000_IG22:                ;; offset=0x0300
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG23:                ;; offset=0x0307
       mov      rcx, 0x7FFC6580E218
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       jmp      G_M000_IG04
 
; Total bytes of code 795

; Assembly listing for method Tedd.WildcardMatch:IsMatch(System.String):bool:this (FullOpts)
; Emitting BLENDED_CODE for generic X64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 25 inlinees with PGO data; 65 single block inlinees; 17 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 136
       lea      rbp, [rsp+0xC0]
       xor      eax, eax
       mov      qword ptr [rbp-0x68], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      qword ptr [rbp-0x40], rax
       mov      rax, rdx
 
G_M000_IG02:                ;; offset=0x0031
       test     rax, rax
       je       G_M000_IG110
       cmp      byte  ptr [rcx+0x4D], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0040
       movzx    rdx, byte  ptr [rcx+0x4E]
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, qword ptr [rcx+0x50]
       mov      qword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rcx+0x30]
       mov      gword ptr [rsp+0x30], rdx
       mov      edx, dword ptr [rcx+0x44]
       mov      dword ptr [rsp+0x38], edx
       mov      edx, dword ptr [rcx+0x48]
       mov      dword ptr [rsp+0x40], edx
       mov      edx, dword ptr [rcx+0x40]
       mov      dword ptr [rsp+0x48], edx
       mov      rdx, gword ptr [rcx+0x20]
       mov      r8d, dword ptr [rcx+0x38]
       mov      r9d, dword ptr [rcx+0x3C]
       mov      rcx, rax
       call     [Tedd.WildcardEngine:IsMatch(System.String,System.String,int,int,bool,System.TimeSpan,System.String,int,int,int):bool]
       nop      
 
G_M000_IG04:                ;; offset=0x0085
       vzeroupper 
       add      rsp, 136
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG05:                ;; offset=0x009C
       lea      rbx, bword ptr [rax+0x0C]
       mov      esi, dword ptr [rax+0x08]
       test     byte  ptr [rcx+0x38], 16
       setne    dil
       movzx    rdi, dil
       movzx    rdx, byte  ptr [rcx+0x4C]
       dec      edx
       cmp      edx, 4
       ja       G_M000_IG88
 
G_M000_IG06:                ;; offset=0x00BE
       mov      edx, edx
       lea      rax, [reloc @RWD00]
       mov      eax, dword ptr [rax+4*rdx]
       lea      r8, G_M000_IG02
       add      rax, r8
       jmp      rax
 
G_M000_IG07:                ;; offset=0x00D6
       mov      rdi, gword ptr [rcx+0x18]
       mov      r14d, esi
       cmp      byte  ptr [rdi+0x1C], 0
       jne      SHORT G_M000_IG08
       cmp      byte  ptr [rdi+0x1F], 0
       je       SHORT G_M000_IG12
 
G_M000_IG08:                ;; offset=0x00E9
       mov      bword ptr [rbp-0x58], rbx
       mov      dword ptr [rbp-0x50], esi
       lea      rdx, [rbp-0x58]
       mov      rcx, rdi
       call     [Tedd.CompiledSegments:Window(System.ReadOnlySpan`1[char]):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG09
       mov      eax, 1
       jmp      SHORT G_M000_IG14
       align    [0 bytes for IG23]
 
G_M000_IG09:                ;; offset=0x0108
       test     esi, esi
       jle      SHORT G_M000_IG10
       lea      eax, [rsi-0x01]
       mov      edx, eax
       cmp      word  ptr [rbx+2*rdx], 10
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0118
       xor      eax, eax
       jmp      SHORT G_M000_IG14
 
G_M000_IG11:                ;; offset=0x011C
       lea      edx, [rsi-0x01]
       cmp      edx, esi
       ja       G_M000_IG111
       mov      bword ptr [rbp-0x58], rbx
       mov      dword ptr [rbp-0x50], edx
       lea      rdx, [rbp-0x58]
       mov      rcx, rdi
       call     [Tedd.CompiledSegments:Window(System.ReadOnlySpan`1[char]):bool:this]
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x013D
       test     r14d, r14d
       jle      SHORT G_M000_IG13
       lea      edx, [r14-0x01]
       cmp      word  ptr [rbx+2*rdx], 10
       jne      SHORT G_M000_IG13
       lea      r14d, [rsi-0x01]
       cmp      r14d, esi
       ja       G_M000_IG111
 
G_M000_IG13:                ;; offset=0x015A
       mov      bword ptr [rbp-0x58], rbx
       mov      dword ptr [rbp-0x50], r14d
       lea      rdx, [rbp-0x58]
       mov      rcx, rdi
       call     [Tedd.CompiledSegments:Window(System.ReadOnlySpan`1[char]):bool:this]
 
G_M000_IG14:                ;; offset=0x016F
       jmp      G_M000_IG95
 
G_M000_IG15:                ;; offset=0x0174
       cmp      esi, 32
       jle      G_M000_IG22
       cmp      gword ptr [rcx+0x18], 0
       je       G_M000_IG88
       mov      rdi, gword ptr [rcx+0x18]
       mov      r14d, esi
       cmp      byte  ptr [rdi+0x1C], 0
       jne      SHORT G_M000_IG16
       cmp      byte  ptr [rdi+0x1F], 0
       je       SHORT G_M000_IG19
 
G_M000_IG16:                ;; offset=0x019B
       mov      bword ptr [rbp-0x58], rbx
       mov      dword ptr [rbp-0x50], esi
       lea      rdx, [rbp-0x58]
       mov      rcx, rdi
       call     [Tedd.CompiledSegments:Window(System.ReadOnlySpan`1[char]):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      eax, 1
       jmp      SHORT G_M000_IG21
 
G_M000_IG17:                ;; offset=0x01BA
       lea      eax, [rsi-0x01]
       mov      edx, eax
       cmp      word  ptr [rbx+2*rdx], 10
       je       SHORT G_M000_IG18
       xor      eax, eax
       jmp      SHORT G_M000_IG21
 
G_M000_IG18:                ;; offset=0x01CA
       lea      edx, [rsi-0x01]
       cmp      edx, esi
       ja       G_M000_IG111
       mov      bword ptr [rbp-0x58], rbx
       mov      dword ptr [rbp-0x50], edx
       lea      rdx, [rbp-0x58]
       mov      rcx, rdi
       call     [Tedd.CompiledSegments:Window(System.ReadOnlySpan`1[char]):bool:this]
       jmp      SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x01EB
       lea      edx, [r14-0x01]
       cmp      word  ptr [rbx+2*rdx], 10
       jne      SHORT G_M000_IG20
       lea      r14d, [rsi-0x01]
       cmp      r14d, esi
       ja       G_M000_IG111
 
G_M000_IG20:                ;; offset=0x0203
       mov      bword ptr [rbp-0x58], rbx
       mov      dword ptr [rbp-0x50], r14d
       lea      rdx, [rbp-0x58]
       mov      rcx, rdi
       call     [Tedd.CompiledSegments:Window(System.ReadOnlySpan`1[char]):bool:this]
 
G_M000_IG21:                ;; offset=0x0218
       jmp      G_M000_IG95
 
G_M000_IG22:                ;; offset=0x021D
       mov      rdi, gword ptr [rcx+0x10]
       mov      rdx, rbx
       mov      ecx, esi
       cmp      dword ptr [rdi+0x38], 0
       jne      G_M000_IG41
       mov      r8, qword ptr [rdi+0x10]
       mov      rax, r8
       and      rax, 1
       add      rax, rax
       or       rax, 1
       xor      r10d, r10d
       cmp      r10d, ecx
       jge      G_M000_IG38
 
G_M000_IG23:                ;; offset=0x024E
       cmp      r10d, ecx
       jae      G_M000_IG112
       movzx    r9, word  ptr [rdx+2*r10]
       lea      r11d, [rcx-0x01]
       cmp      r10d, r11d
       jne      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0265
       cmp      r9d, 10
       jne      SHORT G_M000_IG25
       test     rax, qword ptr [rdi+0x20]
       jne      G_M000_IG40
 
G_M000_IG25:                ;; offset=0x0275
       mov      r11, gword ptr [rdi+0x08]
       mov      rbx, r11
       mov      r11d, dword ptr [r11+0x08]
       dec      r11d
       and      r11d, r9d
       cmp      r11d, dword ptr [rbx+0x08]
       jae      G_M000_IG112
       shl      r11, 4
       lea      r11, bword ptr [rbx+r11+0x10]
       movzx    rsi, word  ptr [r11]
       cmp      esi, r9d
       jne      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x02A2
       mov      r11, qword ptr [r11+0x08]
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x02A8
       xor      r11d, r11d
 
G_M000_IG28:                ;; offset=0x02AB
       cmp      byte  ptr [rdi+0x46], 0
       je       SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x02B1
       mov      ebx, 1
       jmp      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x02B8
       cmp      r9d, 10
       setne    bl
       movzx    rbx, bl
 
G_M000_IG31:                ;; offset=0x02C2
       test     ebx, ebx
       je       SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x02C6
       mov      r9, qword ptr [rdi+0x18]
       jmp      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x02CC
       xor      r9d, r9d
 
G_M000_IG34:                ;; offset=0x02CF
       or       r9, r11
       and      r9, rax
       add      r9, r9
       test     ebx, ebx
       je       SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x02DC
       and      rax, r8
       jmp      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x02E1
       xor      eax, eax
 
G_M000_IG37:                ;; offset=0x02E3
       or       rax, r9
       mov      r9, rax
       and      r9, r8
       add      r9, r9
       or       r9, rax
       mov      rax, r9
       test     rax, rax
       je       SHORT G_M000_IG39
       inc      r10d
       cmp      r10d, ecx
       jl       G_M000_IG23
 
G_M000_IG38:                ;; offset=0x0306
       test     rax, qword ptr [rdi+0x20]
       setne    al
       movzx    rax, al
       jmp      G_M000_IG51
       align    [11 bytes for IG44]
 
G_M000_IG39:                ;; offset=0x0320
       xor      eax, eax
       jmp      G_M000_IG51
 
G_M000_IG40:                ;; offset=0x0327
       mov      eax, 1
       jmp      G_M000_IG51
 
G_M000_IG41:                ;; offset=0x0331
       mov      r14, rbx
       mov      r15d, esi
       mov      r13d, r15d
       cmp      byte  ptr [rdi+0x46], 0
       jne      SHORT G_M000_IG42
       test     r13d, r13d
       jle      SHORT G_M000_IG42
       lea      edx, [r13-0x01]
       cmp      word  ptr [r14+2*rdx], 10
       jne      SHORT G_M000_IG42
       lea      r13d, [r15-0x01]
 
G_M000_IG42:                ;; offset=0x0355
       cmp      byte  ptr [rdi+0x47], 0
       je       SHORT G_M000_IG43
       lea      edx, [r13-0x04]
       cmp      edx, 4
       jb       G_M000_IG48
 
G_M000_IG43:                ;; offset=0x0368
       cmp      r13d, dword ptr [rdi+0x38]
       jle      SHORT G_M000_IG46
       cmp      r13d, r15d
       ja       G_M000_IG111
       movzx    rdx, word  ptr [rdi+0x44]
       movsx    rdx, dx
       mov      rcx, r14
       mov      r8d, r13d
       call     [System.SpanHelpers:LastIndexOfValueType[short,System.SpanHelpers+DontNegate`1[short]](byref,short,int):int]
       sub      eax, dword ptr [rdi+0x38]
       js       SHORT G_M000_IG46
       xor      rcx, rcx
       test     r15d, r15d
       cmovne   rcx, r14
       mov      bword ptr [rbp-0x48], rcx
       xor      r8d, r8d
 
G_M000_IG44:                ;; offset=0x03A0
       movsxd   rdx, r8d
       mov      rdx, qword ptr [rcx+2*rdx]
       and      rdx, qword ptr [rdi+0x30]
       cmp      rdx, qword ptr [rdi+0x28]
       je       SHORT G_M000_IG47
       inc      r8d
       cmp      r8d, eax
       jle      SHORT G_M000_IG44
 
G_M000_IG45:                ;; offset=0x03B9
       xor      ecx, ecx
       mov      bword ptr [rbp-0x48], rcx
 
G_M000_IG46:                ;; offset=0x03BF
       xor      eax, eax
       jmp      G_M000_IG51
       align    [6 bytes for IG55]
 
G_M000_IG47:                ;; offset=0x03CC
       cmp      byte  ptr [rdi+0x46], 0
       jne      G_M000_IG49
       mov      rcx, r14
       mov      r8d, r13d
       mov      edx, 10
       call     [System.PackedSpanHelpers:IndexOf[System.SpanHelpers+DontNegate`1[short],System.PackedSpanHelpers+NopTransform](byref,short,int):int]
       shr      eax, 31
       jmp      G_M000_IG51
 
G_M000_IG48:                ;; offset=0x03EF
       xor      rax, rax
       test     esi, esi
       cmovne   rax, rbx
       mov      bword ptr [rbp-0x48], rax
       mov      rdx, rax
       vmovq    xmm0, qword ptr [rdx]
       movsxd   rcx, r13d
       vpinsrq  xmm0, xmm0, qword ptr [rdx+2*rcx-0x08], 1
       vpbroadcastw xmm1, word  ptr [rdi+0x42]
       vpcmpeqw xmm1, xmm1, xmm0
       vpmovmskb edx, xmm1
       vpbroadcastw xmm1, word  ptr [rdi+0x40]
       vpcmpeqw xmm1, xmm1, xmm0
       vpmovmskb ecx, xmm1
       vpbroadcastw xmm1, word  ptr [rdi+0x44]
       vpcmpeqw xmm1, xmm1, xmm0
       vpmovmskb r8d, xmm1
       lea      eax, [2*r13-0x08]
       mov      r10d, r8d
       shr      r10d, 8
       and      eax, 31
       shlx     r10d, r10d, eax
       movzx    r8, r8b
       or       r8d, r10d
       lzcnt    r8d, r8d
       neg      r8d
       add      r8d, 31
       sar      r8d, 1
       mov      r10d, edx
       shr      r10d, 8
       shlx     r10d, r10d, eax
       movzx    rdx, dl
       or       edx, r10d
       mov      r10d, ecx
       shr      r10d, 8
       shlx     eax, r10d, eax
       movzx    rcx, cl
       or       ecx, eax
       shr      ecx, 4
       and      edx, ecx
       tzcnt    edx, edx
       sar      edx, 1
       sub      r8d, edx
       cmp      r8d, 3
       jl       G_M000_IG46
       cmp      byte  ptr [rdi+0x46], 0
       je       SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x04A5
       mov      eax, 1
       jmp      SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x04AC
       vpcmpeqw xmm0, xmm0, xmmword ptr [reloc @RWD32]
       vptest   xmm0, xmm0
       sete     al
       movzx    rax, al
 
G_M000_IG51:                ;; offset=0x04BF
       jmp      G_M000_IG95
 
G_M000_IG52:                ;; offset=0x04C4
       cmp      esi, 32
       jg       G_M000_IG63
       mov      rdi, gword ptr [rcx+0x10]
       mov      r14, rbx
       mov      r15d, esi
       mov      r13d, r15d
       cmp      byte  ptr [rdi+0x46], 0
       jne      SHORT G_M000_IG53
       test     r15d, r15d
       jle      SHORT G_M000_IG53
       lea      edx, [r15-0x01]
       cmp      word  ptr [r14+2*rdx], 10
       jne      SHORT G_M000_IG53
       lea      r13d, [r15-0x01]
 
G_M000_IG53:                ;; offset=0x04F5
       cmp      byte  ptr [rdi+0x47], 0
       je       SHORT G_M000_IG54
       lea      edx, [r13-0x04]
       cmp      edx, 4
       jb       G_M000_IG59
 
G_M000_IG54:                ;; offset=0x0508
       cmp      r13d, dword ptr [rdi+0x38]
       jle      SHORT G_M000_IG57
       cmp      r13d, r15d
       ja       G_M000_IG111
       movzx    rdx, word  ptr [rdi+0x44]
       movsx    rdx, dx
       mov      rcx, r14
       mov      r8d, r13d
       call     [System.SpanHelpers:LastIndexOfValueType[short,System.SpanHelpers+DontNegate`1[short]](byref,short,int):int]
       sub      eax, dword ptr [rdi+0x38]
       js       SHORT G_M000_IG57
       xor      rcx, rcx
       test     r15d, r15d
       cmovne   rcx, r14
       mov      bword ptr [rbp-0x40], rcx
       xor      r8d, r8d
 
G_M000_IG55:                ;; offset=0x0540
       movsxd   rdx, r8d
       mov      rdx, qword ptr [rcx+2*rdx]
       and      rdx, qword ptr [rdi+0x30]
       cmp      rdx, qword ptr [rdi+0x28]
       je       SHORT G_M000_IG58
       inc      r8d
       cmp      r8d, eax
       jle      SHORT G_M000_IG55
 
G_M000_IG56:                ;; offset=0x0559
       xor      ecx, ecx
       mov      bword ptr [rbp-0x40], rcx
 
G_M000_IG57:                ;; offset=0x055F
       xor      eax, eax
       jmp      G_M000_IG62
 
G_M000_IG58:                ;; offset=0x0566
       cmp      byte  ptr [rdi+0x46], 0
       jne      G_M000_IG60
       mov      rcx, r14
       mov      r8d, r13d
       mov      edx, 10
       call     [System.PackedSpanHelpers:IndexOf[System.SpanHelpers+DontNegate`1[short],System.PackedSpanHelpers+NopTransform](byref,short,int):int]
       shr      eax, 31
       jmp      G_M000_IG62
 
G_M000_IG59:                ;; offset=0x0589
       xor      rax, rax
       test     esi, esi
       cmovne   rax, rbx
       mov      bword ptr [rbp-0x40], rax
       mov      rdx, rax
       vmovq    xmm0, qword ptr [rdx]
       movsxd   rcx, r13d
       vpinsrq  xmm0, xmm0, qword ptr [rdx+2*rcx-0x08], 1
       vpbroadcastw xmm1, word  ptr [rdi+0x42]
       vpcmpeqw xmm1, xmm1, xmm0
       vpmovmskb edx, xmm1
       vpbroadcastw xmm1, word  ptr [rdi+0x40]
       vpcmpeqw xmm1, xmm1, xmm0
       vpmovmskb ecx, xmm1
       vpbroadcastw xmm1, word  ptr [rdi+0x44]
       vpcmpeqw xmm1, xmm1, xmm0
       vpmovmskb eax, xmm1
       lea      r8d, [2*r13-0x08]
       mov      r10d, eax
       shr      r10d, 8
       and      r8d, 31
       shlx     r10d, r10d, r8d
       movzx    rax, al
       or       eax, r10d
       lzcnt    eax, eax
       neg      eax
       add      eax, 31
       sar      eax, 1
       mov      r10d, edx
       shr      r10d, 8
       shlx     r10d, r10d, r8d
       movzx    rdx, dl
       or       edx, r10d
       mov      r10d, ecx
       shr      r10d, 8
       shlx     r8d, r10d, r8d
       movzx    rcx, cl
       or       ecx, r8d
       shr      ecx, 4
       and      edx, ecx
       tzcnt    edx, edx
       sar      edx, 1
       sub      eax, edx
       cmp      eax, 3
       jl       G_M000_IG57
       cmp      byte  ptr [rdi+0x46], 0
       je       SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x063A
       mov      eax, 1
       jmp      SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0641
       vpcmpeqw xmm0, xmm0, xmmword ptr [reloc @RWD32]
       vptest   xmm0, xmm0
       sete     al
       movzx    rax, al
 
G_M000_IG62:                ;; offset=0x0654
       jmp      G_M000_IG95
 
G_M000_IG63:                ;; offset=0x0659
       mov      rdi, gword ptr [rcx+0x18]
       mov      r14d, esi
       cmp      byte  ptr [rdi+0x1C], 0
       jne      SHORT G_M000_IG64
       cmp      byte  ptr [rdi+0x1F], 0
       je       SHORT G_M000_IG67
 
G_M000_IG64:                ;; offset=0x066C
       mov      bword ptr [rbp-0x58], rbx
       mov      dword ptr [rbp-0x50], esi
       lea      rdx, [rbp-0x58]
       mov      rcx, rdi
       call     [Tedd.CompiledSegments:Window(System.ReadOnlySpan`1[char]):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG65
       mov      eax, 1
       jmp      SHORT G_M000_IG69
 
G_M000_IG65:                ;; offset=0x068B
       lea      eax, [rsi-0x01]
       mov      edx, eax
       cmp      word  ptr [rbx+2*rdx], 10
       je       SHORT G_M000_IG66
       xor      eax, eax
       jmp      SHORT G_M000_IG69
 
G_M000_IG66:                ;; offset=0x069B
       lea      edx, [rsi-0x01]
       cmp      edx, esi
       ja       G_M000_IG111
       mov      bword ptr [rbp-0x58], rbx
       mov      dword ptr [rbp-0x50], edx
       lea      rdx, [rbp-0x58]
       mov      rcx, rdi
       call     [Tedd.CompiledSegments:Window(System.ReadOnlySpan`1[char]):bool:this]
       jmp      SHORT G_M000_IG69
 
G_M000_IG67:                ;; offset=0x06BC
       lea      edx, [r14-0x01]
       cmp      word  ptr [rbx+2*rdx], 10
       jne      SHORT G_M000_IG68
       lea      r14d, [rsi-0x01]
       cmp      r14d, esi
       ja       G_M000_IG111
 
G_M000_IG68:                ;; offset=0x06D4
       mov      bword ptr [rbp-0x58], rbx
       mov      dword ptr [rbp-0x50], r14d
       lea      rdx, [rbp-0x58]
       mov      rcx, rdi
       call     [Tedd.CompiledSegments:Window(System.ReadOnlySpan`1[char]):bool:this]
 
G_M000_IG69:                ;; offset=0x06E9
       jmp      G_M000_IG95
 
G_M000_IG70:                ;; offset=0x06EE
       mov      rdi, gword ptr [rcx+0x08]
       mov      r14, rbx
       mov      rcx, gword ptr [rdi+0x08]
       mov      r15d, dword ptr [rcx+0x08]
       cmp      esi, r15d
       je       SHORT G_M000_IG71
       lea      ecx, [r15+0x01]
       cmp      esi, ecx
       jne      G_M000_IG77
       cmp      r15d, esi
       jae      G_M000_IG112
       mov      ecx, r15d
       cmp      word  ptr [r14+2*rcx], 10
       jne      G_M000_IG77
 
G_M000_IG71:                ;; offset=0x0726
       mov      r13, gword ptr [rdi+0x10]
       test     r13, r13
       jne      G_M000_IG103
       mov      ecx, r15d
       sub      ecx, 8
       cmp      ecx, 8
       jbe      G_M000_IG101
       cmp      byte  ptr [rdi+0x1C], 0
       jne      SHORT G_M000_IG72
       mov      r8d, dword ptr [rdi+0x18]
       cmp      r8d, esi
       ja       G_M000_IG111
       mov      rcx, r14
       mov      edx, 10
       call     [System.PackedSpanHelpers:IndexOf[System.SpanHelpers+DontNegate`1[short],System.PackedSpanHelpers+NopTransform](byref,short,int):int]
       test     eax, eax
       jge      SHORT G_M000_IG77
 
G_M000_IG72:                ;; offset=0x0767
       mov      ecx, dword ptr [rdi+0x18]
       cmp      ecx, r15d
       jge      G_M000_IG108
       test     ecx, ecx
       jl       G_M000_IG99
       cmp      r15d, esi
       jg       G_M000_IG99
       mov      rdx, gword ptr [rdi+0x08]
       jmp      SHORT G_M000_IG75
 
G_M000_IG73:                ;; offset=0x078A
       mov      r8d, ecx
       movzx    r8, word  ptr [r14+2*r8]
       cmp      r8d, eax
       jne      SHORT G_M000_IG77
 
G_M000_IG74:                ;; offset=0x0797
       inc      ecx
       cmp      ecx, r15d
       jge      G_M000_IG108
 
G_M000_IG75:                ;; offset=0x07A2
       mov      r8, rdx
       cmp      ecx, dword ptr [r8+0x08]
       jae      G_M000_IG112
       mov      eax, ecx
       movzx    rax, word  ptr [r8+2*rax+0x0C]
       cmp      eax, 63
       jne      SHORT G_M000_IG73
 
G_M000_IG76:                ;; offset=0x07BC
       cmp      byte  ptr [rdi+0x1C], 0
       jne      SHORT G_M000_IG74
       mov      eax, ecx
       cmp      word  ptr [r14+2*rax], 10
       jne      SHORT G_M000_IG74
 
G_M000_IG77:                ;; offset=0x07CC
       xor      eax, eax
 
G_M000_IG78:                ;; offset=0x07CE
       jmp      G_M000_IG95
 
G_M000_IG79:                ;; offset=0x07D3
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       je       SHORT G_M000_IG80
       lea      rdx, bword ptr [rcx+0x0C]
       mov      ecx, dword ptr [rcx+0x08]
       jmp      SHORT G_M000_IG81
 
G_M000_IG80:                ;; offset=0x07E5
       xor      rdx, rdx
       xor      ecx, ecx
 
G_M000_IG81:                ;; offset=0x07E9
       cmp      esi, ecx
       je       SHORT G_M000_IG83
       test     esi, esi
       jle      SHORT G_M000_IG82
       lea      r8d, [rsi-0x01]
       cmp      r8d, ecx
       jne      SHORT G_M000_IG82
       lea      r8d, [rsi-0x01]
       cmp      word  ptr [rbx+2*r8], 10
       je       SHORT G_M000_IG83
 
G_M000_IG82:                ;; offset=0x0806
       xor      eax, eax
       jmp      SHORT G_M000_IG87
 
G_M000_IG83:                ;; offset=0x080A
       cmp      ecx, esi
       ja       G_M000_IG111
 
G_M000_IG84:                ;; offset=0x0812
       mov      r8d, ecx
       add      r8, r8
       cmp      r8, 10
       je       SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x081E
       mov      rcx, rbx
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       jmp      SHORT G_M000_IG87
       align    [0 bytes for IG104]
 
G_M000_IG86:                ;; offset=0x0829
       mov      rax, rbx
       mov      rcx, qword ptr [rax]
       mov      r8, qword ptr [rax+0x02]
       mov      rax, qword ptr [rdx]
       xor      rcx, rax
       xor      r8, qword ptr [rdx+0x02]
       or       rcx, r8
       sete     al
       movzx    rax, al
 
G_M000_IG87:                ;; offset=0x0846
       jmp      G_M000_IG95
 
G_M000_IG88:                ;; offset=0x084B
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG89
       lea      r14, bword ptr [r8+0x0C]
       mov      r15d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x085E
       xor      r14, r14
       xor      r15d, r15d
 
G_M000_IG90:                ;; offset=0x0864
       mov      r13d, dword ptr [rcx+0x44]
       mov      r12d, dword ptr [rcx+0x48]
       mov      rcx, r14
       mov      r8d, r15d
       mov      edx, 42
       call     [System.PackedSpanHelpers:IndexOf[System.SpanHelpers+DontNegate`1[short],System.PackedSpanHelpers+NopTransform](byref,short,int):int]
       test     eax, eax
       jl       G_M000_IG94
       mov      bword ptr [rbp-0x58], rbx
       mov      dword ptr [rbp-0x50], esi
       mov      bword ptr [rbp-0x68], r14
       mov      dword ptr [rbp-0x60], r15d
       mov      dword ptr [rsp+0x20], r12d
       lea      rcx, [rbp-0x58]
       lea      rdx, [rbp-0x68]
       mov      r8d, edi
       mov      r9d, r13d
       call     [Tedd.DefaultWildcardEngine:Window(System.ReadOnlySpan`1[char],System.ReadOnlySpan`1[char],bool,int,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG91
       mov      eax, 1
       jmp      SHORT G_M000_IG95
 
G_M000_IG91:                ;; offset=0x08B8
       test     esi, esi
       jle      SHORT G_M000_IG92
       lea      eax, [rsi-0x01]
       mov      ecx, eax
       cmp      word  ptr [rbx+2*rcx], 10
       je       SHORT G_M000_IG93
 
G_M000_IG92:                ;; offset=0x08C8
       xor      eax, eax
       jmp      SHORT G_M000_IG95
 
G_M000_IG93:                ;; offset=0x08CC
       lea      ecx, [rsi-0x01]
       cmp      ecx, esi
       ja       G_M000_IG111
       mov      bword ptr [rbp-0x58], rbx
       mov      dword ptr [rbp-0x50], ecx
       mov      bword ptr [rbp-0x68], r14
       mov      dword ptr [rbp-0x60], r15d
       mov      dword ptr [rsp+0x20], r12d
       lea      rcx, [rbp-0x58]
       lea      rdx, [rbp-0x68]
       mov      r8d, edi
       mov      r9d, r13d
       call     [Tedd.DefaultWildcardEngine:Window(System.ReadOnlySpan`1[char],System.ReadOnlySpan`1[char],bool,int,int):bool]
       jmp      SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x0901
       mov      bword ptr [rbp-0x58], rbx
       mov      dword ptr [rbp-0x50], esi
       mov      bword ptr [rbp-0x68], r14
       mov      dword ptr [rbp-0x60], r15d
       lea      rcx, [rbp-0x58]
       lea      rdx, [rbp-0x68]
       mov      r8d, edi
       call     [Tedd.DefaultWildcardEngine:Fixed(System.ReadOnlySpan`1[char],System.ReadOnlySpan`1[char],bool):bool]
 
G_M000_IG95:                ;; offset=0x0921
       nop      
 
G_M000_IG96:                ;; offset=0x0922
       vzeroupper 
       add      rsp, 136
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG97:                ;; offset=0x0939
       cmp      ecx, esi
       jae      G_M000_IG112
       mov      edx, ecx
       movzx    rdx, word  ptr [r14+2*rdx]
       cmp      edx, eax
       jne      G_M000_IG77
 
G_M000_IG98:                ;; offset=0x0950
       inc      ecx
       cmp      ecx, r15d
       jge      G_M000_IG108
 
G_M000_IG99:                ;; offset=0x095B
       mov      rdx, gword ptr [rdi+0x08]
       mov      r8, rdx
       cmp      ecx, dword ptr [r8+0x08]
       jae      G_M000_IG112
       mov      eax, ecx
       movzx    rax, word  ptr [r8+2*rax+0x0C]
       cmp      eax, 63
       jne      SHORT G_M000_IG97
 
G_M000_IG100:                ;; offset=0x0979
       cmp      byte  ptr [rdi+0x1C], 0
       jne      SHORT G_M000_IG98
       cmp      ecx, esi
       jae      G_M000_IG112
       mov      eax, ecx
       cmp      word  ptr [r14+2*rax], 10
       je       G_M000_IG77
       jmp      SHORT G_M000_IG98
 
G_M000_IG101:                ;; offset=0x0997
       vmovups  xmm0, xmmword ptr [rbx]
       add      r15d, -8
       movsxd   rcx, r15d
       vmovups  xmm1, xmmword ptr [rbx+2*rcx]
       vpxor    xmm2, xmm0, xmmword ptr [rdi+0x28]
       vmovups  xmm3, xmmword ptr [rdi+0x48]
       vpand    xmm2, xmm2, xmm3
       vpxor    xmm4, xmm1, xmmword ptr [rdi+0x38]
       vmovups  xmm5, xmmword ptr [rdi+0x58]
       vpand    xmm4, xmm4, xmm5
       vpor     xmm2, xmm4, xmm2
       cmp      byte  ptr [rdi+0x1C], 0
       jne      SHORT G_M000_IG102
       vbroadcastss xmm4, dword ptr [reloc @RWD32]
       vpcmpeqw xmm0, xmm0, xmm4
       vpandn   xmm0, xmm3, xmm0
       vpcmpeqw xmm1, xmm1, xmm4
       vpandn   xmm1, xmm5, xmm1
       vpor     xmm0, xmm1, xmm0
       vpor     xmm2, xmm0, xmm2
 
G_M000_IG102:                ;; offset=0x09EE
       vptest   xmm2, xmm2
       sete     al
       movzx    rax, al
       jmp      G_M000_IG78
 
G_M000_IG103:                ;; offset=0x09FE
       xor      eax, eax
       mov      rcx, gword ptr [rdi+0x10]
       cmp      dword ptr [rcx+0x08], 0
       jle      SHORT G_M000_IG108
       lea      ecx, [r15-0x10]
 
G_M000_IG104:                ;; offset=0x0A0E
       mov      edx, eax
       shl      edx, 4
       mov      r8d, ecx
       cmp      edx, r8d
       jg       SHORT G_M000_IG109
 
G_M000_IG105:                ;; offset=0x0A1B
       movsxd   rdx, edx
       vmovups  ymm0, ymmword ptr [rbx+2*rdx]
       mov      rdx, r13
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG112
       mov      r8, rax
       shl      r8, 6
       lea      rdx, bword ptr [rdx+r8+0x10]
       vmovups  ymm1, ymmword ptr [rdx+0x20]
       vpxor    ymm2, ymm0, ymmword ptr [rdx]
       vpand    ymm2, ymm2, ymm1
       cmp      byte  ptr [rdi+0x1C], 0
       jne      SHORT G_M000_IG107
 
G_M000_IG106:                ;; offset=0x0A4E
       vpcmpeqw ymm0, ymm0, ymmword ptr [reloc @RWD64]
       vpandn   ymm0, ymm1, ymm0
       vpor     ymm2, ymm0, ymm2
 
G_M000_IG107:                ;; offset=0x0A5E
       vptest   ymm2, ymm2
       jne      G_M000_IG77
       inc      eax
       mov      rdx, gword ptr [rdi+0x10]
       cmp      dword ptr [rdx+0x08], eax
       jg       SHORT G_M000_IG104
 
G_M000_IG108:                ;; offset=0x0A74
       mov      eax, 1
       jmp      G_M000_IG78
 
G_M000_IG109:                ;; offset=0x0A7E
       mov      edx, r8d
       jmp      SHORT G_M000_IG105
 
G_M000_IG110:                ;; offset=0x0A83
       mov      rcx, 0x7FFC656384E0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      ecx, 155
       mov      rdx, 0x7FFC6580CEC8
       call     [CORINFO_HELP_STRCNS]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.ArgumentNullException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG111:                ;; offset=0x0ABF
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG112:                ;; offset=0x0AC6
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	000007A2h ; case G_M000_IG79
       	dd	000006BDh ; case G_M000_IG70
       	dd	00000493h ; case G_M000_IG52
       	dd	00000143h ; case G_M000_IG15
       	dd	000000A5h ; case G_M000_IG07
RWD20  	dd	00000000h, 00000000h, 00000000h
RWD32  	dq	000A000A000A000Ah, 000A000A000A000Ah
RWD48  	dd	00000000h, 00000000h, 00000000h, 00000000h
RWD64  	dq	000A000A000A000Ah, 000A000A000A000Ah, 000A000A000A000Ah, 000A000A000A000Ah

; Total bytes of code 2764

