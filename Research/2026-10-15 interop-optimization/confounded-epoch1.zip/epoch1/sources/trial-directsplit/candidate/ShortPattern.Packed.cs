
using System;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;
#if NET10_0_OR_GREATER
using System.Runtime.Intrinsics;
using System.Numerics;
#endif
namespace Tedd;
internal sealed partial class ShortPattern {
 internal bool IsPacked => _packedLength != 0;
 readonly ulong _packedValue,_packedMask;readonly int _packedLength,_packedAnchorOffset;readonly char _packedAnchor,_packedTail;
 ShortPattern(ulong value,ulong mask,int length,int anchorOffset,char anchor,char tail,bool singleline){_literals=Array.Empty<Entry>();_packedValue=value;_packedMask=mask;_packedLength=length;_packedAnchorOffset=anchorOffset;_packedAnchor=anchor;_packedTail=tail;_singleline=singleline;}
 static ShortPattern? CreatePacked(string p,bool singleline){
  if(!BitConverter.IsLittleEndian||p.Length<7||p[0]!='*'||p[p.Length-1]!='*'||p.IndexOf('\n')>=0)return null;
  int start=0;while(start<p.Length&&p[start]=='*')start++;
  int end=start;while(end<p.Length&&p[end]!='*')end++;
  int length=end-start;if(length<3||length>4)return null;
  int next=end;while(next<p.Length&&p[next]=='*')next++;
  if(next>=p.Length||p[next]=='?')return null;char tail=p[next++];if(next>=p.Length)return null;
  while(next<p.Length&&p[next]=='*')next++;if(next!=p.Length)return null;
  ulong value=0,mask=0;int anchorOffset=-1;char anchor='\0';
  for(int i=0;i<length;i++)if(p[start+i]!='?'){value|=(ulong)p[start+i]<<(16*i);mask|=65535UL<<(16*i);if(anchorOffset<0){anchorOffset=i;anchor=p[start+i];}}
  return new ShortPattern(value,mask,length,anchorOffset,anchor,tail,singleline);
 }
 [MethodImpl(MethodImplOptions.AggressiveInlining)]
 static ulong ReadWord(ReadOnlySpan<char> input,int offset){
#if NET10_0_OR_GREATER
  return Unsafe.ReadUnaligned<ulong>(ref Unsafe.As<char,byte>(ref Unsafe.Add(ref MemoryMarshal.GetReference(input),offset)));
#else
  return MemoryMarshal.Read<ulong>(MemoryMarshal.AsBytes(input.Slice(offset,4)));
#endif
 }
 [MethodImpl(MethodImplOptions.AggressiveInlining)]
 internal bool MatchPacked(ReadOnlySpan<char> input){
  int length=input.Length;
  if(!_singleline && length>0 && input[length-1]=='\n')length--;
  #if NET10_0_OR_GREATER
  if(Vector128.IsHardwareAccelerated && (uint)(length-4)<4){
   {
    Vector128<ushort> data=Vector128.Create(ReadWord(input,0),ReadWord(input,length-4)).AsUInt16();
    uint e=Vector128.Equals(data,Vector128.Create((ushort)_packedTail)).AsByte().ExtractMostSignificantBits();
    int slot=(31-BitOperations.LeadingZeroCount(e))>>1;
    int tailIndex=slot>=4 ? slot+length-8 : slot;
    int finalStart=tailIndex-_packedLength;
    for(int i=0;i<=finalStart;i++)
     if((ReadWord(input,i)&_packedMask)==_packedValue)
      return _singleline || !Vector128.EqualsAny(data,Vector128.Create((ushort)'\n'));
    return false;
   }
  }
#endif
  return MatchPackedScalar(input,length);
 }
 [MethodImpl(MethodImplOptions.NoInlining)]
 bool MatchPackedScalar(ReadOnlySpan<char> input,int length){
  if(length<=_packedLength)return false; int tail=input.Slice(0,length).LastIndexOf(_packedTail); int last=tail-_packedLength;if(last<0)return false;
  {
   for(int i=0;i<=last;i++){
    
    if((ReadWord(input,i)&_packedMask)==_packedValue)
     return _singleline || input.Slice(0,length).IndexOf('\n')<0;
   }
  }
  return false;
 }
}
