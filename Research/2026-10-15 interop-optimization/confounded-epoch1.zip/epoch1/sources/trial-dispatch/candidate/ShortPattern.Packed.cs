
using System;
using System.Runtime.CompilerServices;
#if NET10_0_OR_GREATER
using System.Runtime.Intrinsics;
using System.Numerics;
#endif
namespace Tedd;
internal sealed partial class ShortPattern {
 #if NET10_0_OR_GREATER
 readonly bool _packedVector; readonly char _packedLast;
#endif
 internal bool IsPacked => _packedLength != 0;
 readonly ulong _packedValue,_packedMask;readonly int _packedLength,_packedAnchorOffset;readonly char _packedAnchor,_packedTail;
 ShortPattern(ulong value,ulong mask,int length,int anchorOffset,char anchor,char tail,bool singleline){_literals=Array.Empty<Entry>();_packedValue=value;_packedMask=mask;_packedLength=length;_packedAnchorOffset=anchorOffset;_packedAnchor=anchor;_packedTail=tail;_singleline=singleline;
#if NET10_0_OR_GREATER
 _packedVector=Vector128.IsHardwareAccelerated && length==3 && mask==0xFFFF0000FFFFUL;_packedLast=(char)(value>>32);
#endif
 }
 static ShortPattern? CreatePacked(string p,bool singleline){
  if(!BitConverter.IsLittleEndian||p.Length<7||p[0]!='*'||p[p.Length-1]!='*'||p.IndexOf('\n')>=0)return null;
  int start=0;while(start<p.Length&&p[start]=='*')start++;
  int end=start;while(end<p.Length&&p[end]!='*')end++;
  int length=end-start;if(length<3||length>4)return null;
  int next=end;while(next<p.Length&&p[next]=='*')next++;
  if(next>=p.Length||p[next]=='?')return null;char tail=p[next++];if(next>=p.Length)return null;
  while(next<p.Length&&p[next]=='*')next++;if(next!=p.Length)return null;
  ulong value=0,mask=0;int anchorOffset=-1;char anchor='\0';
  for(int i=0;i<length;i++)if(p[start+i]!='?'){value|=(ulong)p[start+i]<<(16*i);mask|=65535UL<<(16*i);if(anchorOffset<0){anchorOffset=i;anchor=p[start+i];}}
  return new ShortPattern(value,mask,length,anchorOffset,anchor,tail,singleline);
 }
 [MethodImpl(MethodImplOptions.AggressiveInlining)]
 internal unsafe bool MatchPacked(ReadOnlySpan<char> input){
  int length=input.Length;
  if(!_singleline && length>0 && input[length-1]=='\n')length--;
  #if NET10_0_OR_GREATER
  if(_packedVector && (uint)(length-4)<4){
   fixed(char* p=input){
    Vector128<ushort> data=Vector128.Create(*(ulong*)p,*(ulong*)(p+length-4)).AsUInt16();
    uint a=Vector128.Equals(data,Vector128.Create((ushort)_packedAnchor)).AsByte().ExtractMostSignificantBits();
    uint c=Vector128.Equals(data,Vector128.Create((ushort)_packedLast)).AsByte().ExtractMostSignificantBits();
    uint e=Vector128.Equals(data,Vector128.Create((ushort)_packedTail)).AsByte().ExtractMostSignificantBits();
    int shift=(length-4)*2;
    a=(a&255)|((a>>8)<<shift);c=(c&255)|((c>>8)<<shift);e=(e&255)|((e>>8)<<shift);
    int first=(int)BitOperations.TrailingZeroCount(a&(c>>4))>>1;
    int finalTail=(31-BitOperations.LeadingZeroCount(e))>>1;
    return finalTail-first>=3 && (_singleline || !Vector128.EqualsAny(data,Vector128.Create((ushort)'\n')));
   }
  }
#endif
  if(length<=_packedLength)return false; int tail=input.Slice(0,length).LastIndexOf(_packedTail); int last=tail-_packedLength;if(last<0)return false;
  fixed(char* p=input){
   for(int i=0;i<=last;i++){
    
    if((*(ulong*)(p+i)&_packedMask)==_packedValue)
     return _singleline || input.Slice(0,length).IndexOf('\n')<0;
   }
  }
  return false;
 }
}
