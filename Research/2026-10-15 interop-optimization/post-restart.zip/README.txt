Unpooled post-restart evidence. Epoch 2 is the first selected source; epoch 3 contains the anchor-proof change; epoch 4 contains deferred LF validation and the final twenty-block regime and both native storage modes.
Catalog is an official verified SQLite backup. Extract artifacts beside catalog.sqlite to inspect offline. Re-executions require new plans and grants.
