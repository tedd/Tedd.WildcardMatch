import pathlib,sys,json,subprocess,os,hashlib
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch2');REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch')
if json.loads((R.parent/'jobs/078.done').read_text()).get('exit_code')!=0:raise RuntimeError('Epoch 2 validation incomplete')
frozen=json.loads((R/'evidence/source-freeze.json').read_text())
for name,h in frozen['files'].items():
 if hashlib.sha256((REPO/name).read_bytes()).hexdigest()!=h:raise RuntimeError('Source changed after freeze '+name)
env=os.environ.copy();env['WILDCARD_NATIVE_LIBRARY']=str(R/'final/native-build/wildcard_native.dll')
with (R/'evidence/final-benchmark.txt').open('w') as out:
 p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','run','--project','src/Tedd.WildcardMatch.Benchmark','-c','Release','--no-build','--','--filter','*','--launchCount','3','--warmupCount','3','--iterationCount','10','--iterationTime','100','--affinity','1073741824','--artifacts',str(R/'final-artifacts')],cwd=R/'final',env=env,stdout=out,stderr=subprocess.STDOUT)
if p.returncode:raise RuntimeError('Final benchmark failed')
for name,count in [('Matching',32),('NativeMatching',16),('Construction',8),('Interop',18),('InteropControl',2)]:
 p=R/'final-artifacts/results'/f'Tedd.WildcardMatchBenchmark.{name}Benchmarks-report-full.json';j=json.loads(p.read_text())
 if len(j['Benchmarks'])!=count or any(not x.get('Statistics') or x['Statistics']['Mean']<=0 for x in j['Benchmarks']):raise RuntimeError('Incomplete result '+name)
print('All 76 benchmark cases completed',flush=True)
