import pathlib,sys,subprocess,json,uuid
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch2');sys.path.insert(0,str(R));from rpc import *
def import_file(path):
 media='application/json' if path.suffix=='.json' else 'application/vnd.microsoft.portable-executable'
 p=subprocess.run([D,HOST,'import',str(R/'catalog'),str(path),media],capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 x=json.loads(p.stdout);(R/'evidence'/('import-'+path.parent.parent.parent.name+'-'+path.name+'.json')).write_text(p.stdout);return x['id']
files={}
for arm in ['baseline','candidate']:
 folder=R/('normal-'+arm)/'bin/Release/net10.0';files[arm]=[]
 for path in sorted(folder.iterdir()):
  if path.suffix=='.dll' or path.name.endswith(('.runtimeconfig.json','.deps.json')):files[arm].append({'name':path.name,'artifact_id':import_file(path)})
source=import_file(R/'evidence/source-freeze.json')
i=launch(R/'normal-candidate','normal-discovery5');grant(i,'execute_registered_scenario',1,'normal-registration');s=Session('normal-registration')
try:
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'normal-scenarios')['scenarios']
 builds={a:s.call('lab.experiment',{'action':'register_normal_build','entry_assembly':'WildcardInteropRig.dll','files':f},'normal-build-'+a) for a,f in files.items()}
 candidate=s.call('lab.experiment',{'action':'create_candidate','name':'Prepared packed short-star matching with bounded reads and selected managed strategy','build_identity':builds['candidate']['content_hash'],'components':[]},'selected-candidate')
 exploratory=[x['execution_id'] for x in json.loads((R/'evidence/screening-summary.json').read_text())]
 shapes=['Portfolio','Literal','Simple','MultiStar','LongText','Diverse','Dense4096','Dense16384','Newline','GeneralShort','FixedMedium','FixedLong','LiteralLong']
 ids=['interop-reused-'+shape for shape in shapes]+['interop-static-'+shape for shape in ['Literal','Simple','MultiStar','LongText']]
 plans=[]
 for sid in ids:
  desc=next(x for x in sc if x['id']==sid);shape=sid.split('-')[-1];ops=512 if shape.startswith('Dense') else 1000 if shape=='Newline' else 30000 if shape in ['LongText','FixedLong','LiteralLong'] else 300000
  if not shape.startswith('Dense') and shape != 'Newline':ops *= 10
  exp={'id':'prospective-'+uuid.uuid4().hex,'scenario_id':sid,'scenario_version':desc['version'],'input_hash':desc['input_hash'],'variants':['baseline','candidate'],'blocks':10,'operations_per_run':ops,'warmup_batches':2,'seed':'20261015','profile':'quiet-validation','independent_blocks':True,'independence_justification':'Each paired block uses two fresh sequential processes with identical callers, harness dependencies, runtime, CPU affinity and no scenario state carryover. A shared host lock excludes this agent team\'s overlapping work. Other OS workloads and thermal/frequency drift remain uncontrolled; distinct processes alone do not prove stochastic independence.','confirmatory':True,'maximum_duration_seconds':600,'analysis':{'alpha_family':.05,'family_size':17,'equivalence_lower_ratio':.95,'equivalence_upper_ratio':1.05,'useful_improvement_ratio':.95,'meaningful_regression_ratio':1.05,'minimum_blocks':10},'primary_metric':'scenario.ns_per_operation','fresh_normal_build':True,'guardrail_metrics':None}
  p=s.call('lab.experiment',{'action':'create_confirmation_plan','selected_candidate_id':candidate['id'],'source_patch_artifact_id':source,'source_equivalence_rationale':'Both normal entries compile the exact frozen original or selected production sources into the same Tedd namespace and identical scenario caller bodies. Only production code in the entry assembly differs. Prepared short shapes use bounded UTF-16 masks and validated four-unit reads; newline/option semantics are unchanged. A completed literal anchor is not re-compared after IndexOf. All tests and independent corpus checks pass. Native comparators use separate external evidence.','baseline_build_id':builds['baseline']['id'],'candidate_build_id':builds['candidate']['id'],'baseline_variant':'baseline','candidate_variant':'candidate','experiment':exp,'exploratory_evidence_ids':exploratory},'confirmation-plan-'+sid)
  plans.append({'scenario':sid,'id':p['id']})
 (R/'evidence/confirmation-plan-index.json').write_text(json.dumps(plans,indent=2));print('Frozen',len(plans),'confirmation plans',flush=True)
finally:s.close();(R/'stop-target-normal-discovery5').touch()
for item in plans:
 p=subprocess.run([D,HOST,'grant-confirmation',str(R/'catalog'),item['id'],'1800','20'],capture_output=True,text=True)
 (R/'evidence'/('confirmation-grant-'+item['scenario']+'.json')).write_text(p.stdout)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 item['grant_id']=json.loads(p.stdout)['id']
(R/'evidence/confirmation-plan-index.json').write_text(json.dumps(plans,indent=2))
