
import pathlib,sys,subprocess,json
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch2');sys.path.insert(0,str(R));from rpc import *
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe','build','Rig.csproj','-c','Release'],cwd=R/'rig',capture_output=True,text=True);(R/'evidence/screening-build.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Screening build failed')
i=launch(R/'rig','screening2');g=grant(i,'execute_registered_scenario',160,'screening',1200);s=Session('screening');summary=[]
try:
 s.rpc('tools/list',{})
 s.call('lab.discover',{'action':'workspace'},'workspace')
 s.call('lab.discover',{'action':'profiles'},'profiles')
 s.call('lab.discover',{'action':'compatibility','target_id':i['id']},'screening-compatibility')
 s.call('lab.discover',{'action':'targets'},'targets')
 s.call('lab.discover',{'action':'capabilities','target_id':i['id']},'screening-capabilities')
 s.call('lab.experiment',{'action':'create_hypothesis','mechanism':'A09/A16/M24/V03: prepared masked UTF-16 segments and a bounded tail search replace bitmap recurrence for eligible short-star shapes; C18: preserve direct common paths and bind fallback once.','prediction':'Lower reused multi-star and mixed-portfolio costs against the original source, while every mandatory latency guard remains within five percent and per-match allocations remain zero. Epoch 1 timings are excluded.','evidence_ids':[]},'epoch2-hypothesis')
 sc=s.call('lab.discover',{'action':'scenarios','target_id':i['id']},'screening-scenarios')['scenarios']
 for shape in ['Literal','Simple','MultiStar','LongText','Diverse','Dense4096','Dense16384','Newline']:
  desc=next(x for x in sc if x['id']=='interop-reused-'+shape);p=plan(s,desc,'screening-'+shape,512 if shape.startswith('Dense') else 1000 if shape=='Newline' else 30000 if shape=='LongText' else 300000)
  ex,c=execute(s,i,p,g,'screening-'+shape);summary.append({'shape':shape,'execution_id':ex,'comparison':c});(R/'evidence/screening-summary.json').write_text(json.dumps(summary,indent=2))
finally:s.close();(R/'stop-target-screening2').touch()
