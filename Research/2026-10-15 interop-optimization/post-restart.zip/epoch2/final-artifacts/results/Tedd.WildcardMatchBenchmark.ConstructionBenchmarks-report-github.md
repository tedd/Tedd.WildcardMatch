```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9711/25H2/2025Update/HudsonValley2)
AMD Ryzen 9 5950X 3.40GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 11.0.100-rc.2.26504.105
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3
  Job-ZMHJYT : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3

Affinity=01000000000000000000000000000000  EnvironmentVariables=DOTNET_TieredCompilation=0  IterationCount=10  
IterationTime=100ms  LaunchCount=3  WarmupCount=3  

```
| Method            | Pattern       | Mean         | Error      | StdDev     | Median       | Ratio  | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |-------------- |-------------:|-----------:|-----------:|-------------:|-------:|--------:|-------:|----------:|------------:|
| **TeddDirectReused**  | ***a?c*e***       |    **115.75 ns** |   **2.862 ns** |   **4.196 ns** |    **114.50 ns** |   **1.00** |    **0.05** | **0.0166** |     **296 B** |        **1.00** |
| TeddRegexReused   | *a?c*e*       |  2,088.06 ns |  15.590 ns |  22.852 ns |  2,087.84 ns |  18.06 |    0.67 | 0.1050 |    2000 B |        6.76 |
| TeddRegexCompiled | *a?c*e*       | 15,917.33 ns |  66.155 ns |  90.554 ns | 15,942.13 ns | 137.68 |    4.92 | 0.6429 |   12696 B |       42.89 |
| DotNetGlob        | *a?c*e*       |    796.57 ns |   9.172 ns |  13.728 ns |    802.03 ns |   6.89 |    0.27 | 0.1051 |    1792 B |        6.05 |
|                   |               |              |            |            |              |        |         |        |           |             |
| **TeddDirectReused**  | **report-??.txt** |     **54.36 ns** |   **0.127 ns** |   **0.174 ns** |     **54.32 ns** |   **1.00** |    **0.00** | **0.0132** |     **224 B** |        **1.00** |
| TeddRegexReused   | report-??.txt |  1,916.77 ns |  10.911 ns |  15.296 ns |  1,922.94 ns |  35.26 |    0.30 | 0.1153 |    2024 B |        9.04 |
| TeddRegexCompiled | report-??.txt | 10,016.32 ns | 144.357 ns | 211.597 ns |  9,887.40 ns | 184.25 |    3.87 | 0.4920 |    8448 B |       37.71 |
| DotNetGlob        | report-??.txt |    654.09 ns |   3.866 ns |   5.787 ns |    655.15 ns |  12.03 |    0.11 | 0.0581 |     976 B |        4.36 |
