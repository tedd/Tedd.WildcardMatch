```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9711/25H2/2025Update/HudsonValley2)
AMD Ryzen 9 5950X 3.40GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 11.0.100-rc.2.26504.105
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3
  Job-ZMHJYT : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3

Affinity=01000000000000000000000000000000  EnvironmentVariables=DOTNET_TieredCompilation=0  IterationCount=10  
IterationTime=100ms  LaunchCount=3  WarmupCount=3  

```
| Method     | Case                 | Mean       | Error     | StdDev    | Median     | Allocated |
|----------- |--------------------- |-----------:|----------:|----------:|-----------:|----------:|
| **Normal**     | **Literal/GitWildmatch** |  **30.642 ns** | **0.0127 ns** | **0.0178 ns** |  **30.639 ns** |         **-** |
| Suppressed | Literal/GitWildmatch |  30.064 ns | 0.0132 ns | 0.0190 ns |  30.067 ns |         - |
| **Normal**     | **Literal/Krauss**       |  **11.168 ns** | **0.0199 ns** | **0.0286 ns** |  **11.162 ns** |         **-** |
| Suppressed | Literal/Krauss       |  10.667 ns | 0.0223 ns | 0.0333 ns |  10.672 ns |         - |
| **Normal**     | **Liter(...)cards [21]** |  **75.377 ns** | **0.5444 ns** | **0.7808 ns** |  **75.015 ns** |         **-** |
| Suppressed | Liter(...)cards [21] |  75.847 ns | 0.8650 ns | 1.2679 ns |  75.304 ns |         - |
| **Normal**     | **Multi(...)match [22]** |  **30.735 ns** | **0.0321 ns** | **0.0480 ns** |  **30.739 ns** |         **-** |
| Suppressed | Multi(...)match [22] |  30.421 ns | 0.0547 ns | 0.0818 ns |  30.415 ns |         - |
| **Normal**     | **MultiStar/Krauss**     |   **9.849 ns** | **0.0652 ns** | **0.0955 ns** |   **9.829 ns** |         **-** |
| Suppressed | MultiStar/Krauss     |   9.466 ns | 0.0500 ns | 0.0733 ns |   9.440 ns |         - |
| **Normal**     | **Multi(...)cards [23]** | **158.106 ns** | **2.9796 ns** | **4.3675 ns** | **155.751 ns** |         **-** |
| Suppressed | Multi(...)cards [23] | 153.321 ns | 0.7695 ns | 1.1518 ns | 153.584 ns |         - |
| **Normal**     | **Simple/GitWildmatch**  |  **34.283 ns** | **0.0296 ns** | **0.0425 ns** |  **34.288 ns** |         **-** |
| Suppressed | Simple/GitWildmatch  |  33.935 ns | 0.0510 ns | 0.0747 ns |  33.917 ns |         - |
| **Normal**     | **Simple/Krauss**        |  **11.365 ns** | **0.0266 ns** | **0.0382 ns** |  **11.342 ns** |         **-** |
| Suppressed | Simple/Krauss        |  11.030 ns | 0.0028 ns | 0.0042 ns |  11.031 ns |         - |
| **Normal**     | **Simple/ZemaWildcards** |  **81.634 ns** | **0.7254 ns** | **1.0857 ns** |  **81.601 ns** |         **-** |
| Suppressed | Simple/ZemaWildcards |  80.422 ns | 0.1937 ns | 0.2779 ns |  80.528 ns |         - |
