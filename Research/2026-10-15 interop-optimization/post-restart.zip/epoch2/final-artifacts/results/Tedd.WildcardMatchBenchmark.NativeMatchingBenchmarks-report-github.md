```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9711/25H2/2025Update/HudsonValley2)
AMD Ryzen 9 5950X 3.40GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 11.0.100-rc.2.26504.105
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3
  Job-ZMHJYT : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3

Affinity=01000000000000000000000000000000  EnvironmentVariables=DOTNET_TieredCompilation=0  IterationCount=10  
IterationTime=100ms  LaunchCount=3  WarmupCount=3  

```
| Method | Case                 | Mean          | Error      | StdDev      | Median        | Allocated |
|------- |--------------------- |--------------:|-----------:|------------:|--------------:|----------:|
| **Match**  | **Literal/GitWildmatch** |     **29.157 ns** |  **0.1777 ns** |   **0.2605 ns** |     **29.072 ns** |         **-** |
| **Match**  | **Literal/Krauss**       |      **9.517 ns** |  **0.0137 ns** |   **0.0201 ns** |      **9.516 ns** |         **-** |
| **Match**  | **Literal/Pcre2Jit**     |     **16.552 ns** |  **0.0234 ns** |   **0.0320 ns** |     **16.546 ns** |         **-** |
| **Match**  | **Liter(...)cards [21]** |     **75.250 ns** |  **0.4488 ns** |   **0.6291 ns** |     **75.256 ns** |         **-** |
| **Match**  | **LongT(...)match [21]** |    **666.351 ns** |  **4.2514 ns** |   **6.2317 ns** |    **664.937 ns** |         **-** |
| **Match**  | **LongText/Krauss**      |    **233.062 ns** |  **0.3965 ns** |   **0.5812 ns** |    **233.061 ns** |         **-** |
| **Match**  | **LongText/Pcre2Jit**    |  **1,489.847 ns** |  **9.9401 ns** |  **14.5701 ns** |  **1,491.445 ns** |         **-** |
| **Match**  | **LongT(...)cards [22]** | **21,860.623 ns** | **74.6627 ns** | **109.4396 ns** | **21,866.821 ns** |         **-** |
| **Match**  | **Multi(...)match [22]** |     **28.985 ns** |  **0.0309 ns** |   **0.0453 ns** |     **28.989 ns** |         **-** |
| **Match**  | **MultiStar/Krauss**     |      **8.108 ns** |  **0.0529 ns** |   **0.0775 ns** |      **8.094 ns** |         **-** |
| **Match**  | **MultiStar/Pcre2Jit**   |     **22.736 ns** |  **0.0331 ns** |   **0.0464 ns** |     **22.714 ns** |         **-** |
| **Match**  | **Multi(...)cards [23]** |    **156.853 ns** |  **3.7855 ns** |   **5.6660 ns** |    **153.908 ns** |         **-** |
| **Match**  | **Simple/GitWildmatch**  |     **32.662 ns** |  **0.0505 ns** |   **0.0755 ns** |     **32.680 ns** |         **-** |
| **Match**  | **Simple/Krauss**        |      **9.619 ns** |  **0.0042 ns** |   **0.0061 ns** |      **9.618 ns** |         **-** |
| **Match**  | **Simple/Pcre2Jit**      |     **16.695 ns** |  **0.0070 ns** |   **0.0104 ns** |     **16.695 ns** |         **-** |
| **Match**  | **Simple/ZemaWildcards** |     **79.943 ns** |  **0.3796 ns** |   **0.5444 ns** |     **79.769 ns** |         **-** |
