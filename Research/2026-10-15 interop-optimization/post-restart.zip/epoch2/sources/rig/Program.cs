
using DotNetLab.Contracts;
using DotNetLab.Harness;
using System.Diagnostics;
Process.GetCurrentProcess().ProcessorAffinity = new IntPtr(1L << 30);
var registry = new ScenarioRegistry();
foreach (var shape in new[]{"Literal","Simple","MultiStar","LongText","Dense4096","Dense16384","Newline","Diverse"})
 foreach (bool reuse in new[]{true,false}) registry.Register(new MatchScenario(shape,reuse));
var host = new HarnessHost(registry,args[1]);
if(args[0]=="--harness") {await host.RunOwnedAsync();return;}
using var cancel = new CancellationTokenSource();
var listener=host.ListenAsync(cancel.Token);
Console.WriteLine(Wire.Serialize(host.Target));Console.Out.Flush();
while(!File.Exists(args[2]))await Task.Delay(200);
cancel.Cancel();await listener;
sealed class MatchScenario : ISynchronousScenario {
 readonly string shape; readonly bool reuse; readonly string pattern; readonly string[] inputs;readonly bool[] expected;
 readonly Tedd.WildcardMatch candidate;readonly Control.WildcardMatch control;
 string variant="baseline";long checksum,expectedChecksum;CancellationToken cancel;
 public MatchScenario(string shape,bool reuse){this.shape=shape;this.reuse=reuse;
 pattern=shape switch{"Literal"=>"report-2026.txt","Simple"=>"report-??.txt","MultiStar"=>"*a?c*e*","LongText"=>"*alpha*beta??*omega*","Diverse"=>"*a?c*e*",_=>"*"+new string('a',70)+"?b*"};
 int n=shape=="Dense16384"?16384:4096;
 inputs=shape switch{
 "Literal"=>["report-2026.txt","report-2025.txt","xreport-2026.txt","report-2026.txtx"],
 "Simple"=>["report-01.txt","report-aa.txt","report-1.txt","report-001.txt"],
 "MultiStar"=>["xabcyef","abce","abcd","ababcd","aZc-long-e-tail","acex"],
 "LongText"=>[new string('x',512)+"alpha-middle-beta42-tail-omega"+new string('z',512),new string('x',512)+"alpha-middle-beta42-tail-delta"+new string('z',512),new string('x',512)+"alpha-beta12-omega"+new string('z',512),new string('x',512)+"alpha-beta1-omega"+new string('z',512)],
 "Newline"=>["\n"+new string('a',n),new string('a',n)+"\n",new string('a',70)+"\nb",new string('a',70)+"zb\n"],
 "Diverse"=>Enumerable.Range(0,256).Select(i=>new string('x',i%64)+(i%4==0?"aZce":i%4==1?"a\nce":i%4==2?"aZcxe\n":"aZcxx")+new string('z',i%17)).ToArray(),
 _=>[new string('a',n),new string('a',n)+"zb",new string('a',n)+"zc",new string('a',n)+"zb\n"]};
 expected=inputs.Select(s=>Oracle(s,pattern)).ToArray();candidate=new(pattern);control=new(pattern);
 }
 static bool Oracle(string s,string p){bool Full(int end){var a=new bool[end+1];a[0]=true;foreach(char c in p){var b=new bool[end+1];b[0]=c=='*'&&a[0];for(int i=1;i<=end;i++)b[i]=c=='*'?a[i]||(b[i-1]&&s[i-1]!='\n'):a[i-1]&&(c=='?'?s[i-1]!='\n':c==s[i-1]);a=b;}return a[end];}return Full(s.Length)||(s.EndsWith('\n')&&Full(s.Length-1));}
 public ScenarioDescriptor Describe()=>new("interop-"+(reuse?"reused-":"static-")+shape,"1",Wire.Hash(new{pattern,inputs,expected}),ResetLevel.LogicalState,ThreadAffinity.Any,false,"One public direct match, corpus cycled; checksum observable",["baseline","candidate"]);
 public void Prepare(ScenarioContext context){variant=context.Variant;cancel=context.Cancellation;for(int i=0;i<inputs.Length;i++)if(candidate.IsMatch(inputs[i])!=expected[i]||control.IsMatch(inputs[i])!=expected[i]||Tedd.WildcardMatch.IsMatch(inputs[i],pattern)!=expected[i]||Control.WildcardMatch.IsMatch(inputs[i],pattern)!=expected[i])throw new Exception("Oracle mismatch");}
 public void Reset(ResetContext context){checksum=expectedChecksum=0;}
 public long ExecuteBatch(int count){if(reuse){if(variant=="baseline")for(int i=0;i<count;i++){if((i&4095)==0)cancel.ThrowIfCancellationRequested();int j=i%inputs.Length;checksum+=control.IsMatch(inputs[j])?1:0;expectedChecksum+=expected[j]?1:0;}else for(int i=0;i<count;i++){if((i&4095)==0)cancel.ThrowIfCancellationRequested();int j=i%inputs.Length;checksum+=candidate.IsMatch(inputs[j])?1:0;expectedChecksum+=expected[j]?1:0;}}else{if(variant=="baseline")for(int i=0;i<count;i++){if((i&4095)==0)cancel.ThrowIfCancellationRequested();int j=i%inputs.Length;checksum+=Control.WildcardMatch.IsMatch(inputs[j],pattern)?1:0;expectedChecksum+=expected[j]?1:0;}else for(int i=0;i<count;i++){if((i&4095)==0)cancel.ThrowIfCancellationRequested();int j=i%inputs.Length;checksum+=Tedd.WildcardMatch.IsMatch(inputs[j],pattern)?1:0;expectedChecksum+=expected[j]?1:0;}}return count;}
 public ValidationResult Validate()=>new(checksum==expectedChecksum);public void Cleanup(){}
}
