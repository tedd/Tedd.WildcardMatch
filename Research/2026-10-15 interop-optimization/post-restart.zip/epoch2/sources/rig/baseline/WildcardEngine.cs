using System;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;

namespace Control;

internal static partial class WildcardEngine
{
    internal static readonly TimeSpan InfiniteTimeout = TimeSpan.FromMilliseconds(-1);
    private static readonly char[] Tokens = { '*', '?' };
    private const int Multiline = 2;
    private const int AnyNewLine = 0x800;

    private static class NewlineOption
    {
        // Probe enum metadata only for this optional flag; never initialize a Regex.
        internal static readonly bool Supported = Enum.IsDefined(typeof(RegexOptions), AnyNewLine);
    }

    internal static void ValidatePattern(string wildcard)
    {
        if (wildcard is null)
#pragma warning disable CA2208 // Preserve the Regex-backed API's null-pattern parameter name.
            throw new ArgumentNullException("str");
#pragma warning restore CA2208
    }

    internal static void ValidateOptions(WildcardOptions options)
    {
        // Preserve Regex option validation, including flags supplied by numeric casts.
        int value = (int)options;
        if ((uint)value >> 12 != 0 || ((value & AnyNewLine) != 0 && !NewlineOption.Supported) ||
            ((value & 0x100) != 0 && (value & ~0x30B) != 0) ||
            ((value & 0x400) != 0 && (value & 0x940) != 0))
            throw new ArgumentOutOfRangeException(nameof(options));
    }

    internal static void ValidateTimeout(TimeSpan timeout)
    {
        if (timeout != InfiniteTimeout && (timeout.Ticks <= 0 || timeout.TotalMilliseconds > int.MaxValue - 1))
#pragma warning disable CA2208 // Preserve the Regex constructor's exception metadata.
            throw new ArgumentOutOfRangeException("matchTimeout");
#pragma warning restore CA2208
    }

    internal static int GetPrefix(string pattern) => pattern.IndexOfAny(Tokens);
    internal static int GetSuffix(string pattern) => pattern.Length - pattern.LastIndexOfAny(Tokens) - 1;

    internal static bool IsLiteral(string wildcard) => wildcard.IndexOfAny(Tokens) < 0;

    internal static string GetMatchingPattern(string wildcard, WildcardOptions options)
    {
        // .NET 11's x-mode ignores unescaped VT, which Regex.Escape leaves literal.
        // Other whitespace is escaped by the translator. Normalize only this rare mode.
        return ((int)options & 0x20) != 0 && wildcard.IndexOf('\v') >= 0 && NewlineOption.Supported
            ? wildcard.Replace("\v", "") : wildcard;
    }

    internal static int GetCaseBehavior(WildcardOptions options)
    {
        if ((options & WildcardOptions.IgnoreCase) == 0) return 0;
        CultureInfo culture = (options & WildcardOptions.CultureInvariant) != 0
            ? CultureInfo.InvariantCulture : CultureInfo.CurrentCulture;
        string name = culture.Name;
        if (name.Length == 0) return 1;
        return (name == "tr" || name.StartsWith("tr-", StringComparison.Ordinal) ||
                name == "az" || name.StartsWith("az-", StringComparison.Ordinal)) ? 3 : 2;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static char Fold(char value, int behavior)
    {
        // Regex uses Unicode lowercase mappings, with special I equivalence groups.
        // Uppercase/OrdinalIgnoreCase equate additional characters (e.g. long s).
        if (behavior == 3)
        {
            if (value == 'I' || value == '\u0131') return '\u0131';
            if (value == 'i' || value == '\u0130') return 'i';
        }
        else if (behavior == 2 && value == '\u0130') return 'i';
        if (value >= 'A' && value <= 'Z') return (char)(value + 32);
        return value < 128 ? value : char.ToLowerInvariant(value);
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static bool Accept(char pattern, char input, bool singleline, int behavior) =>
        pattern == '?' ? singleline || input != '\n' :
        pattern == input || (behavior != 0 && Fold(pattern, behavior) == Fold(input, behavior));

    internal static bool IsMatch(string input, string pattern, WildcardOptions options,
        int behavior, bool literal, TimeSpan timeout, string originalPattern, int prefix = -1, int suffix = -1, int leadingQuestions = -1)
    {
        if (input is null) throw new ArgumentNullException(nameof(input));
        var clock = new MatchClock(input, originalPattern, timeout);
        bool singleline = (options & WildcardOptions.Singleline) != 0;
        bool result;
        if (((int)options & AnyNewLine) != 0)
            result = MatchUnicodeLines(input, pattern, singleline, behavior, ((int)options & Multiline) != 0, ref clock);
        else if (((int)options & Multiline) != 0)
            result = MatchLines(input, pattern, singleline, behavior, ref clock);
        else if (literal && behavior == 0)
        {
            // Bulk comparison avoids scalar traversal of long literal patterns.
            int length = pattern.Length;
            result = (input.Length == length ||
                      (input.Length > 0 && input.Length - 1 == length && input[input.Length - 1] == '\n')) &&
                     string.CompareOrdinal(input, 0, pattern, 0, length) == 0;
        }
        else if (literal && behavior != 0 && TryAsciiLiteral(input, pattern, behavior, ref clock, out bool asciiResult))
            result = asciiResult;
        else
        {
            result = MatchWindow(input, input.Length, pattern, singleline, behavior, ref clock, prefix, suffix, leadingQuestions);
            // '$' also accepts the position before one final LF. Try the true end
            // first because patterns with literal LF may require the full input.
            if (!result && input.Length > 0 && input[input.Length - 1] == '\n')
                result = MatchWindow(input, input.Length - 1, pattern, singleline, behavior, ref clock, prefix, suffix, leadingQuestions);
        }
        clock.CheckNow();
        return result;
    }

    // H-017: ASCII letters have identical groups in invariant/non-Turkic modes.
    // Any non-ASCII unit falls back to the full Regex-compatible case mapping;
    // Turkic groups bypass this path. Keep cooperative timeout checks in the loop.
    private static bool TryAsciiLiteral(string input, string pattern, int behavior, ref MatchClock clock, out bool result)
    {
        result = false;
        if (behavior == 3) return false;
        int length = pattern.Length;
        if (input.Length != length && !(input.Length > 0 && input.Length - 1 == length && input[input.Length - 1] == '\n')) return true;
        for (int i = 0; i < length; i++)
        {
            clock.Check();
            char a = pattern[i], b = input[i];
            if ((a | b) >= 128) return false;
            if (a != b && (uint)((a | 32) - 'a') > 25) return true;
            if (a != b && (a | 32) != (b | 32)) return true;
        }
        result = true;
        return true;
    }

    // H-018: search the complete literal run to avoid first-character false
    // positives. Spans are bounded by the current window; no substring is made.
    // The caller verifies that the star did not consume an intervening LF.
    private static int FindLiteral(string input, int start, int end, string pattern, int token, int patternEnd, ref MatchClock clock)
    {
        int next = token + 1;
        while (next < patternEnd && pattern[next] != '*' && pattern[next] != '?') { next++; clock.Check(); }
        int length = next - token;
        if (length == 1) return input.IndexOf(pattern[token], start, end - start);
        int offset = input.AsSpan(start, end - start).IndexOf(pattern.AsSpan(token, length), StringComparison.Ordinal);
        return offset < 0 ? -1 : start + offset;
    }

    private static bool MatchWindow(string input, int end, string pattern, bool singleline,
        int behavior, ref MatchClock clock, int preparedPrefix, int preparedSuffix, int preparedQuestions)
    {
        int text = 0, token = 0, patternEnd = pattern.Length;
        if (behavior == 0 && patternEnd >= 32)
        {
            // Long literal runs use runtime bulk comparison. Keep short patterns on
            // the scalar path to avoid extra searches. See Research/2026-10-02 wildcard-engine-1.
            int prefix = preparedPrefix >= 0 ? preparedPrefix : pattern.IndexOfAny(Tokens);
            if (prefix > 0)
            {
                if (prefix > end || string.CompareOrdinal(input, 0, pattern, 0, prefix) != 0) return false;
                text = token = prefix;
            }
            int suffix = preparedSuffix >= 0 ? preparedSuffix : patternEnd - pattern.LastIndexOfAny(Tokens) - 1;
            if (suffix > 0)
            {
                if (suffix > end - text || string.CompareOrdinal(input, end - suffix, pattern, patternEnd - suffix, suffix) != 0) return false;
                patternEnd -= suffix;
                end -= suffix;
            }
            clock.CheckNow();
        }
        if (patternEnd >= 32 && token == 0 && pattern[0] == '?' && pattern[1] == '?')
        {
            // H-014/H-020: consume a long leading question run as one bounded
            // input range. '?' still excludes LF unless Singleline is selected.
            int length = preparedQuestions;
            if (length < 0)
            {
                length = 2;
                while (length < patternEnd && pattern[length] == '?') { length++; clock.Check(); }
            }
            if (length > end || (!singleline && input.IndexOf('\n', 0, length) >= 0)) return false;
            token = text = length;
        }
        // Anchor fixed prefix/suffix before retrying the interior. A suffix mismatch
        // rejects '*aaaa...b' without rescanning it at every input offset.
        while (token < patternEnd && pattern[token] != '*')
        {
            clock.Check();
            if (text == end || !Accept(pattern[token], input[text], singleline, behavior)) return false;
            token++;
            text++;
        }
        if (token == patternEnd) return text == end;
        while (pattern[patternEnd - 1] != '*')
        {
            clock.Check();
            if (text == end || !Accept(pattern[patternEnd - 1], input[end - 1], singleline, behavior)) return false;
            patternEnd--;
            end--;
        }

        int retryToken = -1, retryText = 0;
        while (text < end)
        {
            clock.Check();
            if (token < patternEnd && pattern[token] == '*')
            {
                do { token++; clock.Check(); } while (token < patternEnd && pattern[token] == '*');
                if (token == patternEnd)
                    return singleline || input.IndexOf('\n', text, end - text) < 0;
                if (behavior == 0 && pattern.Length >= 16 && pattern[token] != '?')
                {
                    int found = FindLiteral(input, text, end, pattern, token, patternEnd, ref clock);
                    if (found < 0 || (!singleline && input.IndexOf('\n', text, found - text) >= 0)) return false;
                    text = found;
                }
                retryToken = token;
                retryText = text;
            }
            else if (token < patternEnd && Accept(pattern[token], input[text], singleline, behavior))
            {
                token++;
                text++;
            }
            else if (retryToken >= 0 && retryText < end && (singleline || input[retryText] != '\n'))
            {
                // Earliest feasible placement of a segment leaves maximal room for
                // later segments. Only the latest star needs retry state.
                if (behavior == 0 && pattern.Length >= 16 && pattern[retryToken] != '?')
                {
                    int found = FindLiteral(input, retryText + 1, end, pattern, retryToken, patternEnd, ref clock);
                    if (found < 0 || (!singleline && input.IndexOf('\n', retryText, found - retryText) >= 0)) return false;
                    retryText = found;
                    text = found;
                }
                else text = ++retryText;
                token = retryToken;
            }
            else return false;
        }
        while (token < patternEnd && pattern[token] == '*') { token++; clock.Check(); }
        return token == patternEnd;
    }

    private static bool MatchLines(string input, string pattern, bool singleline, int behavior, ref MatchClock clock)
    {
        // Numeric RegexOptions.Multiline casts retain '^'/'$' line-anchor semantics
        // without adding line-search overhead to ordinary whole-string matches.
        int start = 0;
        do
        {
            if (MatchFromLine(input, start, pattern, singleline, behavior, ref clock)) return true;
            int newline = input.IndexOf('\n', start);
            clock.CheckNow();
            if (newline < 0) return false;
            start = newline + 1;
        } while (start <= input.Length);
        return false;
    }

    private static bool MatchFromLine(string input, int start, string pattern, bool singleline,
        int behavior, ref MatchClock clock)
    {
        int text = start, token = 0, retryToken = -1, retryText = 0;
        while (true)
        {
            clock.Check();
            if (token == pattern.Length)
            {
                if (text == input.Length || input[text] == '\n') return true;
            }
            else if (pattern[token] == '*')
            {
                do { token++; clock.Check(); } while (token < pattern.Length && pattern[token] == '*');
                retryToken = token;
                retryText = text;
                continue;
            }
            else if (text < input.Length && Accept(pattern[token], input[text], singleline, behavior))
            {
                token++;
                text++;
                continue;
            }
            if (retryToken < 0 || retryText == input.Length || (!singleline && input[retryText] == '\n')) return false;
            text = ++retryText;
            token = retryToken;
        }
    }

    private static bool IsUnicodeNewline(char value) =>
        value == '\n' || value == '\r' || value == '\v' || value == '\f' ||
        value == '\u0085' || value == '\u2028' || value == '\u2029';

    private static bool UnicodeEnd(string input, int position, bool multiline)
    {
        if (position == input.Length) return true;
        if (!IsUnicodeNewline(input[position])) return false;
        // CRLF is one sequence: its interior is neither an end nor a line start.
        if (input[position] == '\n' && position > 0 && input[position - 1] == '\r') return false;
        int length = input[position] == '\r' && position + 1 < input.Length && input[position + 1] == '\n' ? 2 : 1;
        return multiline || position + length == input.Length;
    }

    private static bool MatchUnicodeLines(string input, string pattern, bool singleline,
        int behavior, bool multiline, ref MatchClock clock)
    {
        // .NET 11's AnyNewLine numeric flag broadens both dot and anchor semantics.
        // Keep this optional mode separate from the ordinary LF-only fast paths.
        int start = 0;
        while (true)
        {
            int text = start, token = 0, retryToken = -1, retryText = 0;
            while (true)
            {
                clock.Check();
                if (token == pattern.Length)
                {
                    if (UnicodeEnd(input, text, multiline)) return true;
                }
                else if (pattern[token] == '*')
                {
                    do { token++; clock.Check(); } while (token < pattern.Length && pattern[token] == '*');
                    retryToken = token;
                    retryText = text;
                    continue;
                }
                else if (text < input.Length && (pattern[token] == '?'
                    ? singleline || !IsUnicodeNewline(input[text])
                    : pattern[token] == input[text] || (behavior != 0 && Fold(pattern[token], behavior) == Fold(input[text], behavior))))
                {
                    token++;
                    text++;
                    continue;
                }
                if (retryToken < 0 || retryText == input.Length || (!singleline && IsUnicodeNewline(input[retryText]))) break;
                text = ++retryText;
                token = retryToken;
            }
            if (!multiline) return false;
            while (start < input.Length && !IsUnicodeNewline(input[start])) { start++; clock.Check(); }
            if (start == input.Length) return false;
            if (input[start++] == '\r' && start < input.Length && input[start] == '\n') start++;
        }
    }

    private struct MatchClock
    {
        private readonly string _input, _pattern;
        private readonly TimeSpan _timeout;
        private readonly long _started, _budget;
        private int _checks;

        internal MatchClock(string input, string pattern, TimeSpan timeout)
        {
            _input = input;
            _pattern = pattern;
            _timeout = timeout;
            _budget = timeout == InfiniteTimeout ? 0 : Math.Max(1, (long)Math.Ceiling(timeout.TotalSeconds * Stopwatch.Frequency));
            _started = _budget == 0 ? 0 : Stopwatch.GetTimestamp();
            _checks = 0;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal void Check()
        {
            // Default matches never read the clock; finite checks are amortized.
            if (_budget != 0 && (++_checks & 1023) == 0) CheckNow();
        }

        internal void CheckNow()
        {
            if (_budget != 0 && Stopwatch.GetTimestamp() - _started >= _budget)
                throw new RegexMatchTimeoutException(_input, InternalUtils.StringToWildcard(_pattern), _timeout);
        }
    }
}
