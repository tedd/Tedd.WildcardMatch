using System;
using System.Runtime.CompilerServices;
namespace Tedd;
internal sealed partial class ShortPattern
{
    private static ShortPattern? CreateSequence(string pattern, bool singleline)
    {
        if (pattern[0] != '*' || pattern[pattern.Length - 1] != '*') return null;
        ulong sequence = 0;
        int count = 0;
        bool star = true;
        foreach (char token in pattern)
        {
            if (token == '*') { star = true; continue; }
            if (!star || token == '?' || token == '\n' || count == 4) return null;
            sequence |= (ulong)token << (16 * count++);
            star = false;
        }
        return count >= 2 ? new ShortPattern(sequence, 0, -count, default, singleline) : null;
    }
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private bool MatchSequence(ReadOnlySpan<char> input)
    {
        if (!_singleline && input.Length > 0 && input[input.Length - 1] == '\n') input = input.Slice(0, input.Length - 1);
        ulong sequence = _packedValue;
        int position = 0;
        for (int i = 0; i < -_packedLength; i++)
        {
            int found = input.Slice(position).IndexOf((char)sequence);
            if (found < 0) return false;
            position += found + 1;
            sequence >>= 16;
        }
        return _singleline || input.IndexOf('\n') < 0;
    }
}
