import pathlib,sys,json,time
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch3');sys.path.insert(0,str(R));from rpc import *
for n in ['102','103','104']:
 if json.loads((R.parent/'jobs'/f'{n}.done').read_text()).get('exit_code')!=0:raise RuntimeError('Epoch 2 prerequisite failed '+n)
plans=json.loads((R/'evidence/confirmation-plan-index.json').read_text());s=Session('confirmation')
summary=[]
try:
 for item in plans:
  label='confirm-'+item['scenario'];print(label,'starting',flush=True)
  op=s.call('lab.run',{'action':'start_confirmation','plan_id':item['id'],'grant_id':item['grant_id'],'idempotency_key':label},label+'-accepted');end=s.wait(op,label)
  execution=s.call('lab.inspect',{'action':'record','id':end['result_id']},label+'-execution')
  comparison=s.call('lab.compare',{'execution_id':end['result_id'],'normal_build_confirmation':True},label+'-comparison')
  summary.append({'scenario':item['scenario'],'execution_id':end['result_id'],'comparison':comparison});(R/'evidence/confirmation-summary.json').write_text(json.dumps(summary,indent=2));print(label,'completed',flush=True)
finally:s.close()
