import pathlib,sys,json,subprocess,os
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch3');sys.path.insert(0,str(R));from rpc import *
if json.loads((R.parent/'jobs/105.done').read_text()).get('exit_code')!=0:raise RuntimeError('Confirmation incomplete')
s=Session('confirmation-details')
try:
 for item in json.loads((R/'evidence/confirmation-summary.json').read_text()):
  name=item['scenario'];d=item['comparison'];s.call('lab.inspect',{'action':'record','id':d['comparison_id']},'confirmed-statistics-'+name)
  if d.get('objective_vector_id'):s.call('lab.inspect',{'action':'record','id':d['objective_vector_id']},'confirmed-objectives-'+name)
  raw=json.loads((R/'evidence'/('confirm-'+name+'-execution.json')).read_text())['data'];execution=json.loads(raw['json'])
  sessions=[s.call('lab.inspect',{'action':'record','id':identity},'normal-session-'+identity) for identity in execution['session_ids']]
  (R/'evidence'/('confirmed-sessions-'+name+'.json')).write_text(json.dumps(sessions,indent=2))
finally:s.close()
env=os.environ.copy();env.update(DOTNET_TieredCompilation='0',DOTNET_JitDisasm='Tedd.WildcardMatch:IsMatch Tedd.WildcardMatch:MatchPackedString Tedd.ShortPattern:MatchPacked Tedd.ShortPattern:MatchPackedScalar Tedd.CompiledSegments:Window',DOTNET_JitStdOutFile=str(R/'evidence/final-jit.asm'))
assembly=R/'final/src/Tedd.WildcardMatch.Benchmark/bin/Release/net10.0/Tedd.WildcardMatch.Benchmark.dll'
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe',str(assembly),'--validate-packages'],env=env,cwd=R/'final',capture_output=True,text=True);(R/'evidence/final-jit-validation.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Final JIT corpus validation failed')
print('Confirmation details and final generated code retained',flush=True)

env.update(WILDCARD_NATIVE_LIBRARY=str(R/'final/native-build/wildcard_native.dll'),DOTNET_JitDisasm='Tedd.WildcardMatchBenchmark.NativeMatcher:MatchEach*',DOTNET_JitStdOutFile=str(R/'evidence/final-interop-jit.asm'))
p=subprocess.run([r'C:\Program Files\dotnet\dotnet.exe',str(assembly),'--validate-native'],env=env,cwd=R/'final',capture_output=True,text=True);(R/'evidence/final-interop-jit-validation.txt').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('Interop generated-code validation failed')
