import subprocess,json,pathlib,time,uuid,os
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch3');D=r'D:\Workspaces\AI\dotnetlab-runtime\dotnet.exe';HOST=r'D:\Workspaces\AI\dotnetlab-implementation\bin\DotNetLab.Host\Release\net10.0\DotNetLab.Host.dll'
class Session:
 def __init__(self,label):
  self.label=label;self.serial=0;self.log=(R/'evidence'/f'{label}-rpc.jsonl').open('w');self.stderr=(R/'evidence'/f'{label}-controller.txt').open('w')
  self.p=subprocess.Popen([D,HOST,'serve',str(R.parent/'epoch2/catalog')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr,text=True)
  self.rpc('initialize',{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'wildcard-optimization','version':'1'}})
  self.p.stdin.write(json.dumps({'jsonrpc':'2.0','method':'notifications/initialized'})+'\n');self.p.stdin.flush()
 def rpc(self,method,params):
  self.serial+=1;n=self.serial;req={'jsonrpc':'2.0','id':n,'method':method,'params':params};self.log.write(json.dumps({'request':req})+'\n');self.log.flush();self.p.stdin.write(json.dumps(req)+'\n');self.p.stdin.flush()
  while True:
   line=self.p.stdout.readline()
   if not line:raise RuntimeError('Controller closed: '+self.label)
   msg=json.loads(line)
   if msg.get('id')==n:
    self.log.write(json.dumps({'response':msg})+'\n');self.log.flush()
    if 'error' in msg:raise RuntimeError(msg['error'])
    return msg['result']
 def call(self,tool,payload,name):
  result=self.rpc('tools/call',{'name':tool,'arguments':{'request':payload}})
  blocks=result.get('content',[]);texts=[x['text'] for x in blocks if x.get('type')=='text']
  objects=[]
  for t in texts:
   try:objects.append(json.loads(t))
   except ValueError:pass
  env=next((x for x in objects if isinstance(x,dict) and 'status'in x),None)
  if env is None:raise RuntimeError(result)
  (R/'evidence'/f'{name}.json').write_text(json.dumps(env,indent=2))
  if env['status']!='ok':raise RuntimeError(env)
  return env['data']
 def wait(self,operation,name):
  oid=operation['id']
  for i in range(3000):
   x=self.call('lab.run',{'action':'status','operation_id':oid},name+'-status')
   if x['state'] in ['completed','failed','cancelled','tainted','interrupted']:
    if x['state']!='completed':raise RuntimeError(x)
    return x
   time.sleep(.25)
  raise RuntimeError('Operation polling budget exhausted')
 def close(self):self.p.stdin.close();self.p.wait(timeout=30);self.log.close();self.stderr.close()
def grant(identity,permission,count,label,seconds=600):
 p=subprocess.run([D,HOST,'grant',str(R.parent/'epoch2/catalog'),str(identity['process_id']),permission,str(seconds),str(count)],capture_output=True,text=True)
 (R/'evidence'/f'{label}-grant-{permission}.json').write_text(p.stdout)
 if p.returncode:raise RuntimeError(p.stderr+p.stdout)
 return json.loads(p.stdout)['id']
def launch(rig,label):
 env=os.environ.copy();env['DOTNET_TieredCompilation']='0'
 f=(R/f'target-{label}.txt').open('w');p=subprocess.Popen([D,str(rig/'bin/Release/net10.0/WildcardInteropRig.dll'),'--listen',str(R.parent/'epoch2/catalog'),str(R/f'stop-target-{label}')],stdout=f,stderr=subprocess.STDOUT,env=env);f.close()
 for i in range(100):
  txt=(R/f'target-{label}.txt').read_text()
  if txt:return json.loads(txt.splitlines()[0])
  time.sleep(.1)
 raise RuntimeError('Target did not initialize')
def plan(session,scenario,label,ops=300000,profile='quiet-validation'):
 return session.call('lab.experiment',{'action':'create_plan','scenario_id':scenario['id'],'scenario_version':scenario['version'],'input_hash':scenario['input_hash'],'variants':['baseline','candidate'],'blocks':10,'operations_per_run':ops,'warmup_batches':2,'seed':'20261015','profile':profile,'independent_blocks':False,'confirmatory':False,'maximum_duration_seconds':180,'analysis':{'alpha_family':.05,'family_size':4,'equivalence_lower_ratio':.95,'equivalence_upper_ratio':1.05,'useful_improvement_ratio':.8,'meaningful_regression_ratio':1.05,'minimum_blocks':10}},label+'-plan')
def execute(session,identity,p,g,label,observation=None):
 payload={'action':'start','target_id':identity['id'],'expected_target_epoch':'0','plan_id':p['id'],'grant_id':g,'idempotency_key':label}
 if observation:payload['observation_grant_id']=observation
 x=session.call('lab.run',payload,label+'-accepted');end=session.wait(x,label)
 execution=session.call('lab.inspect',{'action':'record','id':end['result_id']},label+'-execution')
 comp=session.call('lab.compare',{'execution_id':end['result_id'],'include_objectives':True},label+'-comparison')
 print(label,'complete',end['result_id'],flush=True)
 return end['result_id'],comp
