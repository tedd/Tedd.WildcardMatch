```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9711/25H2/2025Update/HudsonValley2)
AMD Ryzen 9 5950X 3.40GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 11.0.100-rc.2.26504.105
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3
  Job-ZMHJYT : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3

Affinity=01000000000000000000000000000000  EnvironmentVariables=DOTNET_TieredCompilation=0  IterationCount=10  
IterationTime=100ms  LaunchCount=3  WarmupCount=3  

```
| Method            | Pattern       | Mean         | Error      | StdDev     | Median       | Ratio  | RatioSD | Gen0   | Allocated | Alloc Ratio |
|------------------ |-------------- |-------------:|-----------:|-----------:|-------------:|-------:|--------:|-------:|----------:|------------:|
| **TeddDirectReused**  | ***a?c*e***       |    **110.79 ns** |   **0.560 ns** |   **0.804 ns** |    **110.67 ns** |   **1.00** |    **0.01** | **0.0177** |     **296 B** |        **1.00** |
| TeddRegexReused   | *a?c*e*       |  2,078.74 ns |  13.151 ns |  18.860 ns |  2,077.08 ns |  18.76 |    0.21 | 0.1049 |    2000 B |        6.76 |
| TeddRegexCompiled | *a?c*e*       | 15,810.68 ns |  90.016 ns | 123.215 ns | 15,748.10 ns | 142.72 |    1.48 | 0.6405 |   12696 B |       42.89 |
| DotNetGlob        | *a?c*e*       |    791.79 ns |  10.861 ns |  15.920 ns |    782.90 ns |   7.15 |    0.15 | 0.1012 |    1792 B |        6.05 |
|                   |               |              |            |            |              |        |         |        |           |             |
| **TeddDirectReused**  | **report-??.txt** |     **54.66 ns** |   **0.173 ns** |   **0.248 ns** |     **54.62 ns** |   **1.00** |    **0.01** | **0.0132** |     **224 B** |        **1.00** |
| TeddRegexReused   | report-??.txt |  1,915.10 ns |  18.805 ns |  26.969 ns |  1,930.67 ns |  35.04 |    0.51 | 0.1161 |    2024 B |        9.04 |
| TeddRegexCompiled | report-??.txt | 10,095.09 ns | 113.430 ns | 166.265 ns | 10,156.04 ns | 184.69 |    3.10 | 0.4978 |    8448 B |       37.71 |
| DotNetGlob        | report-??.txt |    674.03 ns |  22.306 ns |  31.991 ns |    665.20 ns |  12.33 |    0.58 | 0.0530 |     976 B |        4.36 |
