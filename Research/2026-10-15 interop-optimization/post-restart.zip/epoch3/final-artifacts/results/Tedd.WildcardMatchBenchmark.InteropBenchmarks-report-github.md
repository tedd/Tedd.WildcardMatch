```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9711/25H2/2025Update/HudsonValley2)
AMD Ryzen 9 5950X 3.40GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 11.0.100-rc.2.26504.105
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3
  Job-ZMHJYT : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3

Affinity=01000000000000000000000000000000  EnvironmentVariables=DOTNET_TieredCompilation=0  IterationCount=10  
IterationTime=100ms  LaunchCount=3  WarmupCount=3  

```
| Method     | ShareInputs | Case                 | Mean      | Error    | StdDev   | Median    | Allocated |
|----------- |------------ |--------------------- |----------:|---------:|---------:|----------:|----------:|
| **Normal**     | **False**       | **Literal/GitWildmatch** |  **27.82 ns** | **0.014 ns** | **0.021 ns** |  **27.82 ns** |         **-** |
| Suppressed | False       | Literal/GitWildmatch |  27.22 ns | 0.011 ns | 0.015 ns |  27.23 ns |         - |
| **Normal**     | **False**       | **Literal/Krauss**       |  **11.12 ns** | **0.006 ns** | **0.009 ns** |  **11.12 ns** |         **-** |
| Suppressed | False       | Literal/Krauss       |  10.51 ns | 0.006 ns | 0.008 ns |  10.51 ns |         - |
| **Normal**     | **False**       | **Liter(...)cards [21]** |  **79.98 ns** | **0.721 ns** | **0.962 ns** |  **79.88 ns** |         **-** |
| Suppressed | False       | Liter(...)cards [21] |  80.96 ns | 1.778 ns | 2.661 ns |  79.91 ns |         - |
| **Normal**     | **False**       | **Multi(...)match [22]** |  **30.04 ns** | **0.058 ns** | **0.083 ns** |  **30.03 ns** |         **-** |
| Suppressed | False       | Multi(...)match [22] |  29.74 ns | 0.036 ns | 0.050 ns |  29.73 ns |         - |
| **Normal**     | **False**       | **MultiStar/Krauss**     |  **11.28 ns** | **0.011 ns** | **0.014 ns** |  **11.28 ns** |         **-** |
| Suppressed | False       | MultiStar/Krauss     |  11.05 ns | 0.034 ns | 0.049 ns |  11.07 ns |         - |
| **Normal**     | **False**       | **Multi(...)cards [23]** | **157.20 ns** | **2.020 ns** | **2.960 ns** | **155.19 ns** |         **-** |
| Suppressed | False       | Multi(...)cards [23] | 155.09 ns | 1.211 ns | 1.698 ns | 154.09 ns |         - |
| **Normal**     | **False**       | **Simple/GitWildmatch**  |  **34.09 ns** | **0.074 ns** | **0.105 ns** |  **34.10 ns** |         **-** |
| Suppressed | False       | Simple/GitWildmatch  |  32.76 ns | 0.057 ns | 0.083 ns |  32.76 ns |         - |
| **Normal**     | **False**       | **Simple/Krauss**        |  **11.33 ns** | **0.005 ns** | **0.007 ns** |  **11.33 ns** |         **-** |
| Suppressed | False       | Simple/Krauss        |  11.03 ns | 0.006 ns | 0.008 ns |  11.02 ns |         - |
| **Normal**     | **False**       | **Simple/ZemaWildcards** |  **83.43 ns** | **1.248 ns** | **1.829 ns** |  **82.33 ns** |         **-** |
| Suppressed | False       | Simple/ZemaWildcards |  81.34 ns | 0.219 ns | 0.328 ns |  81.44 ns |         - |
| **Normal**     | **True**        | **Literal/GitWildmatch** |  **28.18 ns** | **0.012 ns** | **0.017 ns** |  **28.18 ns** |         **-** |
| Suppressed | True        | Literal/GitWildmatch |  27.48 ns | 0.020 ns | 0.029 ns |  27.48 ns |         - |
| **Normal**     | **True**        | **Literal/Krauss**       |  **11.42 ns** | **0.008 ns** | **0.011 ns** |  **11.42 ns** |         **-** |
| Suppressed | True        | Literal/Krauss       |  10.81 ns | 0.005 ns | 0.007 ns |  10.80 ns |         - |
| **Normal**     | **True**        | **Liter(...)cards [21]** |  **80.81 ns** | **0.568 ns** | **0.832 ns** |  **80.78 ns** |         **-** |
| Suppressed | True        | Liter(...)cards [21] |  79.27 ns | 0.654 ns | 0.980 ns |  79.54 ns |         - |
| **Normal**     | **True**        | **Multi(...)match [22]** |  **31.88 ns** | **0.065 ns** | **0.098 ns** |  **31.88 ns** |         **-** |
| Suppressed | True        | Multi(...)match [22] |  30.00 ns | 0.024 ns | 0.035 ns |  29.99 ns |         - |
| **Normal**     | **True**        | **MultiStar/Krauss**     |  **11.58 ns** | **0.008 ns** | **0.011 ns** |  **11.58 ns** |         **-** |
| Suppressed | True        | MultiStar/Krauss     |  11.31 ns | 0.043 ns | 0.061 ns |  11.28 ns |         - |
| **Normal**     | **True**        | **Multi(...)cards [23]** | **157.85 ns** | **3.745 ns** | **5.606 ns** | **155.33 ns** |         **-** |
| Suppressed | True        | Multi(...)cards [23] | 152.50 ns | 0.815 ns | 1.194 ns | 151.76 ns |         - |
| **Normal**     | **True**        | **Simple/GitWildmatch**  |  **32.05 ns** | **0.082 ns** | **0.121 ns** |  **32.04 ns** |         **-** |
| Suppressed | True        | Simple/GitWildmatch  |  30.59 ns | 0.093 ns | 0.130 ns |  30.59 ns |         - |
| **Normal**     | **True**        | **Simple/Krauss**        |  **11.63 ns** | **0.006 ns** | **0.009 ns** |  **11.63 ns** |         **-** |
| Suppressed | True        | Simple/Krauss        |  11.32 ns | 0.003 ns | 0.005 ns |  11.32 ns |         - |
| **Normal**     | **True**        | **Simple/ZemaWildcards** |  **82.66 ns** | **0.218 ns** | **0.320 ns** |  **82.70 ns** |         **-** |
| Suppressed | True        | Simple/ZemaWildcards |  81.81 ns | 0.362 ns | 0.519 ns |  81.92 ns |         - |
