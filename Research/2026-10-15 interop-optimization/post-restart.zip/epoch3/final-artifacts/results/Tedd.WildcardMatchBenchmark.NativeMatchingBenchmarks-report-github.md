```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.9711/25H2/2025Update/HudsonValley2)
AMD Ryzen 9 5950X 3.40GHz, 1 CPU, 32 logical and 16 physical cores
.NET SDK 11.0.100-rc.2.26504.105
  [Host]     : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3
  Job-ZMHJYT : .NET 10.0.13 (10.0.13, 10.0.1326.50504), X64 RyuJIT x86-64-v3

Affinity=01000000000000000000000000000000  EnvironmentVariables=DOTNET_TieredCompilation=0  IterationCount=10  
IterationTime=100ms  LaunchCount=3  WarmupCount=3  

```
| Method | ShareInputs | Case                 | Mean          | Error      | StdDev     | Median        | Allocated |
|------- |------------ |--------------------- |--------------:|-----------:|-----------:|--------------:|----------:|
| **Match**  | **False**       | **Literal/GitWildmatch** |     **26.301 ns** |  **0.3059 ns** |  **0.4388 ns** |     **26.136 ns** |         **-** |
| **Match**  | **False**       | **Literal/Krauss**       |      **9.326 ns** |  **0.0026 ns** |  **0.0037 ns** |      **9.326 ns** |         **-** |
| **Match**  | **False**       | **Literal/Pcre2Jit**     |     **15.958 ns** |  **0.0050 ns** |  **0.0075 ns** |     **15.958 ns** |         **-** |
| **Match**  | **False**       | **Liter(...)cards [21]** |     **78.913 ns** |  **0.3308 ns** |  **0.4744 ns** |     **78.960 ns** |         **-** |
| **Match**  | **False**       | **LongT(...)match [21]** |    **841.546 ns** |  **0.6290 ns** |  **0.9022 ns** |    **841.537 ns** |         **-** |
| **Match**  | **False**       | **LongText/Krauss**      |    **236.197 ns** |  **0.3871 ns** |  **0.5674 ns** |    **236.243 ns** |         **-** |
| **Match**  | **False**       | **LongText/Pcre2Jit**    |  **1,466.169 ns** |  **8.0246 ns** | **12.0108 ns** |  **1,464.234 ns** |         **-** |
| **Match**  | **False**       | **LongT(...)cards [22]** | **22,056.069 ns** | **20.7745 ns** | **29.1230 ns** | **22,067.297 ns** |         **-** |
| **Match**  | **False**       | **Multi(...)match [22]** |     **28.879 ns** |  **0.2777 ns** |  **0.4157 ns** |     **29.098 ns** |         **-** |
| **Match**  | **False**       | **MultiStar/Krauss**     |      **9.553 ns** |  **0.0274 ns** |  **0.0401 ns** |      **9.540 ns** |         **-** |
| **Match**  | **False**       | **MultiStar/Pcre2Jit**   |     **22.436 ns** |  **0.0437 ns** |  **0.0612 ns** |     **22.409 ns** |         **-** |
| **Match**  | **False**       | **Multi(...)cards [23]** |    **152.749 ns** |  **0.3201 ns** |  **0.4692 ns** |    **152.822 ns** |         **-** |
| **Match**  | **False**       | **Simple/GitWildmatch**  |     **29.115 ns** |  **0.2323 ns** |  **0.3478 ns** |     **28.982 ns** |         **-** |
| **Match**  | **False**       | **Simple/Krauss**        |      **9.552 ns** |  **0.0031 ns** |  **0.0044 ns** |      **9.552 ns** |         **-** |
| **Match**  | **False**       | **Simple/Pcre2Jit**      |     **16.177 ns** |  **0.0049 ns** |  **0.0071 ns** |     **16.178 ns** |         **-** |
| **Match**  | **False**       | **Simple/ZemaWildcards** |     **83.117 ns** |  **2.4007 ns** |  **3.5933 ns** |     **80.941 ns** |         **-** |
| **Match**  | **True**        | **Literal/GitWildmatch** |     **26.045 ns** |  **0.0131 ns** |  **0.0196 ns** |     **26.046 ns** |         **-** |
| **Match**  | **True**        | **Literal/Krauss**       |      **9.329 ns** |  **0.0034 ns** |  **0.0051 ns** |      **9.327 ns** |         **-** |
| **Match**  | **True**        | **Literal/Pcre2Jit**     |     **15.805 ns** |  **0.0052 ns** |  **0.0071 ns** |     **15.806 ns** |         **-** |
| **Match**  | **True**        | **Liter(...)cards [21]** |     **79.974 ns** |  **0.7132 ns** |  **1.0675 ns** |     **79.757 ns** |         **-** |
| **Match**  | **True**        | **LongT(...)match [21]** |    **841.456 ns** |  **0.7739 ns** |  **1.1344 ns** |    **841.439 ns** |         **-** |
| **Match**  | **True**        | **LongText/Krauss**      |    **234.123 ns** |  **0.6329 ns** |  **0.9473 ns** |    **233.908 ns** |         **-** |
| **Match**  | **True**        | **LongText/Pcre2Jit**    |  **1,490.823 ns** | **12.2666 ns** | **17.9803 ns** |  **1,484.797 ns** |         **-** |
| **Match**  | **True**        | **LongT(...)cards [22]** | **22,033.875 ns** | **22.3044 ns** | **30.5305 ns** | **22,046.777 ns** |         **-** |
| **Match**  | **True**        | **Multi(...)match [22]** |     **28.873 ns** |  **0.2857 ns** |  **0.4276 ns** |     **29.138 ns** |         **-** |
| **Match**  | **True**        | **MultiStar/Krauss**     |      **9.850 ns** |  **0.2567 ns** |  **0.3682 ns** |      **9.661 ns** |         **-** |
| **Match**  | **True**        | **MultiStar/Pcre2Jit**   |     **22.455 ns** |  **0.0345 ns** |  **0.0517 ns** |     **22.444 ns** |         **-** |
| **Match**  | **True**        | **Multi(...)cards [23]** |    **152.333 ns** |  **0.2167 ns** |  **0.3243 ns** |    **152.167 ns** |         **-** |
| **Match**  | **True**        | **Simple/GitWildmatch**  |     **29.112 ns** |  **0.2559 ns** |  **0.3830 ns** |     **28.960 ns** |         **-** |
| **Match**  | **True**        | **Simple/Krauss**        |      **9.553 ns** |  **0.0032 ns** |  **0.0044 ns** |      **9.554 ns** |         **-** |
| **Match**  | **True**        | **Simple/Pcre2Jit**      |     **16.178 ns** |  **0.0039 ns** |  **0.0056 ns** |     **16.178 ns** |         **-** |
| **Match**  | **True**        | **Simple/ZemaWildcards** |     **80.944 ns** |  **0.3733 ns** |  **0.5472 ns** |     **80.991 ns** |         **-** |
