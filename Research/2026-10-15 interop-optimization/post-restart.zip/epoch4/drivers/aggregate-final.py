import pathlib,json,re,shutil
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch4');O=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch\Research\2026-10-15 interop-optimization');(O/'results').mkdir(exist_ok=True)
if json.loads((R.parent/'jobs/119.done').read_text()).get('exit_code')!=0:raise RuntimeError('Final benchmark incomplete')
rows=[]
for group in ['Matching','NativeMatching','Interop']:
 j=json.loads((R/'final-artifacts/results'/f'Tedd.WildcardMatchBenchmark.{group}Benchmarks-report-full.json').read_text())
 for x in j['Benchmarks']:
  case=re.search(r'Case: ([^,)]+)',x['FullName']).group(1);shape,library=case.split('/');st=x['Statistics'];mode='managed' if group=='Matching' else 'batch' if group=='NativeMatching' else x['Method'].lower();mode += '' if group=='Matching' else '_shared' if re.search(r'ShareInputs:\s*True\b',x['FullName'],re.I) else '_cloned'
  rows.append({'workload':shape,'library':library,'mode':mode,'mean_ns':st['Mean'],'error_99_9_ns':st['ConfidenceInterval']['Margin'],'retained_iteration_samples':st['OriginalValues'],'memory':x.get('Memory')})
(O/'matching-summary.json').write_text(json.dumps(rows,indent=2))
shapes=['Literal','Simple','MultiStar','LongText'];best=[]
for shape in shapes:
 our=next(x for x in rows if x['workload']==shape and x['library']=='TeddDirectReused');c=min((x for x in rows if x['workload']==shape and x['library'] not in ['TeddDirectReused','TeddDirectStatic']),key=lambda x:x['mean_ns']);best.append({'workload':shape,'tedd_ns':our['mean_ns'],'tedd_error_ns':our['error_99_9_ns'],'competitor':c['library'],'mode':c['mode'],'competitor_ns':c['mean_ns'],'competitor_error_ns':c['error_99_9_ns'],'cost_reduction_percent':100*(1-our['mean_ns']/c['mean_ns']),'meets_20_percent_mean_target':our['mean_ns']<=.8*c['mean_ns']})
(O/'best-comparison.json').write_text(json.dumps(best,indent=2));print(json.dumps(best,indent=2),flush=True)
lines=['# Complete matching comparison','','Mean ± BenchmarkDotNet 99.9% confidence-interval half-width, nanoseconds per match. Each cell retains BenchmarkDotNet’s original outlier policy; unfiltered iteration output is in benchmark.txt. These intervals concern iteration measurements, not independent machines.','','| Implementation and call mode | Literal | Simple | MultiStar | LongText |','| --- | ---: | ---: | ---: | ---: |']
keys=list(dict.fromkeys((x['library'],x['mode']) for x in rows))
for library,mode in keys:
 cells=[]
 for shape in shapes:
  x=next((x for x in rows if x['library']==library and x['mode']==mode and x['workload']==shape),None);cells.append(f"{x['mean_ns']:.3f} ± {x['error_99_9_ns']:.3f}" if x else '—')
 lines.append('| '+library+' ('+mode+') | '+' | '.join(cells)+' |')
lines+=['','Native byte buffers and managed UTF-16 inputs are prepared before timing. Batch mode uses one normal transition per 256 matches; normal/suppressed modes cross once per input into the identical native export. All modes include their loop and dispatch costs. Suppression is qualified only for the fixed three short fixtures and Krauss/Git/Zema. PCRE2 and long calls retain normal transitions.','','The reused Tedd matcher retains pattern preparation. Static Tedd timings include classification on every call. Native wildcard implementations interpret their patterns per match; PCRE2 retains JIT compilation. Construction is reported separately and is excluded from the table.']
(O/'results-table.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
for p in (R/'final-artifacts/results').iterdir():
 if p.is_file():shutil.copy2(p,O/'results'/p.name)
for src,dst in [('evidence/final-benchmark.txt','benchmark.txt'),('evidence/final-tests.txt','tests.txt'),('evidence/final-nointrinsics-tests.txt','scalar-tests.txt'),('evidence/final-build.txt','build.txt'),('evidence/final-validation-packages.json','validation.json'),('evidence/final-validation-native.json','native-validation.json'),('evidence/source-freeze.json','source-freeze.json'),('evidence/delivery-source-hashes.json','delivery-source-hashes.json'),('evidence/final-jit.asm','final-jit.asm'),('evidence/final-interop-jit.asm','final-interop-jit.asm'),('evidence/confirmation-summary.json','confirmation-summary.json'),('evidence/confirmation-plan-index.json','confirmation-plans.json')]:
 p=R/src
 if p.exists():shutil.copy2(p,O/dst)
for name in ['sources.json','source-hashes.json','compiler-flags.txt']:
 p=R/'native/native-build'/name
 if p.exists():shutil.copy2(p,O/('native-'+name))
print('Full results retained',flush=True)
