import pathlib,shutil,subprocess,json,hashlib,os
R=pathlib.Path(r'D:\Workspaces\AI\wildcard-interop-optimization\epoch4');REPO=pathlib.Path(r'D:\SourceCode\Tedd.WildcardMatch');dst=R/'final';dst.mkdir(exist_ok=True)
shutil.copytree(REPO/'src',dst/'src',dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','obj'))
for n in ['global.json','LICENSE','README.md']:shutil.copy2(REPO/n,dst/n)
(dst/'native-build').mkdir(exist_ok=True);shutil.copy2(R/'native/native-build/wildcard_native.dll',dst/'native-build/wildcard_native.dll')
files=list((REPO/'src/Tedd.WildcardMatch').glob('*.cs'))+list((REPO/'src/Tedd.WildcardMatch.Benchmark').glob('*.cs'))+list((REPO/'src/Tedd.WildcardMatch.Benchmark/Native').glob('*'))
manifest={'starting_revision':'7574a36','files':{str(p.relative_to(REPO)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()},'native_dll_sha256':hashlib.sha256((dst/'native-build/wildcard_native.dll').read_bytes()).hexdigest()}
(R/'evidence/source-freeze.json').write_text(json.dumps(manifest,indent=2))
def run(args,name,env=None):
 p=subprocess.run(args,cwd=dst,env=env,capture_output=True,text=True);(R/'evidence'/name).write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError('Failed '+name)
 print(name,'passed',flush=True)
D=r'C:\Program Files\dotnet\dotnet.exe'
run([D,'build','src/Tedd.WildcardMatch.sln','-c','Release'],'final-build.txt')
run([D,'test','src/Tedd.WildcardMatch.Tests','-c','Release','--no-build','--logger','console;verbosity=minimal'],'final-tests.txt')
env=os.environ.copy();env['DOTNET_EnableHWIntrinsic']='0'
run([D,'test','src/Tedd.WildcardMatch.Tests','-c','Release','--no-build','--framework','net10.0','--filter','FullyQualifiedName~ShortStarBoundaryTest|FullyQualifiedName~SegmentAnchorVerificationTest','--logger','console;verbosity=minimal'],'final-nointrinsics-tests.txt',env)
env=os.environ.copy();env['WILDCARD_NATIVE_LIBRARY']=str(dst/'native-build/wildcard_native.dll')
for mode in ['packages','native']:
 run([D,'run','--project','src/Tedd.WildcardMatch.Benchmark','-c','Release','--no-build','--','--validate-'+mode,str(R/'evidence'/('final-validation-'+mode+'.json'))],'final-validation-'+mode+'.txt',env)
print('Frozen source and complete correctness gates passed',flush=True)
